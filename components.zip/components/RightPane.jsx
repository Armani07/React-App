import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Checkbox from 'material-ui/Checkbox';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import { addToColumnList, saveColumn, removeFromColumnList, alterColumnName, alterVersion, completed, uncompleted } from '../redux/actions/columnActions.jsx';
import { goToColumn, updateSort, changeCompletedBack, completedMinus, completedPlus, previousColumn, popPane,snackBarMessage, nextColumn, goBack, StoreChangedColumn, storeComments, storeCii, storeNullable, storeQuestions, storeDefinition, storeMetric, storeDataType, storeCompleted, storeNewColumnName, storeDataSize, } from '../redux/actions/appActions.jsx';
import FlatButton from 'material-ui/FlatButton';
import ChevronLeft from 'material-ui-icons/ChevronLeft';
import ChevronRight from 'material-ui-icons/ChevronRight';
import AutoComplete from 'material-ui/AutoComplete';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';

//all known datatypes for oracle databases. will be selected by drop down menu
const dataTypes = [
    <MenuItem key={"BFILE"} value={"BFILE"} primaryText="BFILE" />,
    <MenuItem key={"CHAR"} value={"CHAR"} primaryText="CHAR" />,
    <MenuItem key={"CLOB"} value={"CLOB"} primaryText="CLOB" />,
    <MenuItem key={"DATE"} value={"DATE"} primaryText="DATE" />,
    <MenuItem key={"DOUBLE"} value={"DOUBLE"} primaryText="DOUBLE" />,
    <MenuItem key={"FLOAT"} value={"FLOAT"} primaryText="FLOAT" />,
    <MenuItem key={"LONG"} value={"LONG"} primaryText="LONG" />,
    <MenuItem key={"LONG RAW"} value={"LONG RAW"} primaryText="LONG RAW" />,
    <MenuItem key={"NCHAR"} value={"NCHAR"} primaryText="NCHAR" />,
    <MenuItem key={"NCLOB"} value={"NCLOB"} primaryText="NCLOB" />,
    <MenuItem key={"NUMBER"} value={'NUMBER'} primaryText="NUMBER" />,
    <MenuItem key={"NVARCHAR2"} value={"NVARCHAR2"} primaryText="NVARCHAR2" />,
    <MenuItem key={"RAW"} value={"RAW"} primaryText="RAW" />,
    <MenuItem key={"ROWID"} value={"ROWID"} primaryText="ROWID" />,
    <MenuItem key={"TIMESTAMP"} value={"TIMESTAMP"} primaryText="TIMESTAMP" />,
    <MenuItem key={"UROWID"} value={"UROWID"} primaryText="UROWID" />,
    <MenuItem key={"VARCHAR2"} value={"VARCHAR2"} primaryText="VARCHAR2" />
];

//selectable dropdown items for the metric menu
const metric = [
    <MenuItem key={1} value={"ACII"} primaryText="ACII" />,
    <MenuItem key={2} value={"PCII"} primaryText="PCII" />,
];

const styles = {
    block: {
        maxWidth: 250,
        paddingTop: '10px'
    },
    checkbox: {
        marginBottom: 16,
    },
};
export class RightPane extends React.Component {
    constructor(props) {
        super(props);
        this.handleDataTypeChange = this.handleDataTypeChange.bind(this);
        this.updateComments = this.updateComments.bind(this);
        this.handleColumnNameChange = this.handleColumnNameChange.bind(this);
        this.updateNullable = this.updateNullable.bind(this);
        this.updateQuestions = this.updateQuestions.bind(this);
        this.updateDataSize = this.updateDataSize.bind(this);
        this.handleRight = this.handleRight.bind(this);
        this.handleLeft = this.handleLeft.bind(this);
    }
    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false
        }
    }
    static clickBack(props) {
        props.saveColumn(props.appState.storedColumn);
        props.changeCompletedBack()
        props.snackBarMessage('Column Saved')
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    /*when a user changes the column name in the column name text field handleColumnNameChange will update the column name in the Stored Column array*/
    handleColumnNameChange(event, columnName) {
        this.props.storeNewColumnName(columnName);
    }
    /*When the user changes the metric in the dataType menuItem, handleDataTypeChange will update storedColumn with the new dataType*/
    handleDataTypeChange(event, index, dataType) {
        this.props.storeDataType(dataType);
    }
    //When the users changes the metric of the metric menuItem, handleMetricChange will update the storedColumn with the new metric. The user can only change the metric if the Customer Identifiable is checkmarked
    handleMetricChange(event, index, metric) {
        this.props.storeMetric(metric);
    }
    //When the user checks or unchecks the Customer Identifiable checkbox, handleCheck will update the storedColumn with the new cii state. if true the user will be able to select a metric in the metric menuItem
    handleCheck(event, checked) {
        this.setState({ open: checked });
        this.props.storeCii(checked);
        if (!checked) {
            this.props.storeMetric(null);
        }
    };
    //handleCompleteToggle will be called when the completed/uncompleted button is clicked, this will update the state in storedColumn. When Completed a checkmark will be present in the table for the column.
    handleCompleteToggle() {
        var newComp = this.props.appState.storedColumn.completed
        if (!newComp) {
            this.setState({ completed: 'Completed' })
            this.props.storeCompleted(true)
            this.props.completedPlus()
        } else {
            this.setState({ completed: 'Uncompleted' })
            this.props.storeCompleted(false)
            this.props.completedMinus()
        }
    };
    //When a user works in the comments text field, updateComments will update the state of storedColumn
    updateComments = (newValue) => {
        this.props.storeComments(newValue)
    };
    //when the definition is changed in the definition text field, updateDefinition will update the state of storedColumn
    updateDefinition = (event, newValue) => {
        this.props.storeDefinition(newValue)
    };
    //when the questions is altered in the question text field, updateQuestions will update the state of storedColumn
    updateQuestions = (newValue) => {
        this.props.storeQuestions(newValue)
    };
    //updateNullable is called when the nullable checkbox is changed, updateNullable will change the state of storedColumn
    updateNullable = (event, newValue) => {
        this.props.storeNullable(newValue)
    };
    //when the DataSize is altered, updateDataSize will change the state of StoredColumn
    updateDataSize = (event, newValue) => {
        this.props.storeDataSize(newValue)
    }

    handleRight = () => {
        this.props.saveColumn(this.props.appState.storedColumn);
        this.props.updateSort(this.props.columnReducer.columnList)
        this.props.nextColumn();
    }

    handleLeft = () => {
        this.props.saveColumn(this.props.appState.storedColumn);
        this.props.updateSort(this.props.columnReducer.columnList)
        this.props.previousColumn();
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.appState.currentSetting.completeReturn && nextProps.appState.completedBack) {
            nextProps.changeCompletedBack()
            nextProps.saveColumn(nextProps.appState.storedColumn);
            nextProps.snackBarMessage('Column Saved')
            nextProps.popPane()
        }
    }
    render() {
        let dis = null;
        if (this.props.appState.storedColumn.cii) {
            dis = (false);
        } else {
            dis = (true);
        }
        return (
            <div id='wrapper'>
                <ul className='list'>
                    <div id='rightParent'>
                        <ChevronLeft
                            className="lobe mouseCursor"
                            id='leftButton'
                            onTouchTap={this.handleLeft} />
                        <div id='mainRightDiv'>
                            <div style={{ fontSize: '25px' }}>Column</div>
                            <li style={{ paddingTop: '25px' }}>
                                <TextField
                                    /*This text field will contain the column name. The Default Value will be given by the users when the column is created. Column name will be editable by the user.*/
                                    floatingLabelText="Column Name"
                                    value={this.props.appState.storedColumn.columnName ? this.props.appState.storedColumn.columnName : ''}
                                    onChange={this.handleColumnNameChange.bind(this)}
                                    inputStyle={{ textAlign: 'left' }}>
                                </TextField>
                            </li>
                            <li className='listItem workPaneFields'>
                                <SelectField
                                    /*A drop down menu box where user will select the columns data type. the value MAY be given by the user during a multi column add.  If none is given, there should be no default value selected*/
                                    value={this.props.appState.storedColumn.dataType ? this.props.appState.storedColumn.dataType : ''}
                                    onChange={this.handleDataTypeChange.bind(this)}
                                    floatingLabelText="Data Type"
                                    style={{ textAlign: 'left'}}>
                                    {dataTypes}
                                </SelectField>
                            </li>
                            <li className='listItem workPaneFields'>
                                <TextField
                                    /*this text field will contain the data size. The default value MAY be given by the user in multi column add.  if no default value is given then there will be no text within the field when the user enters the RightPane*/
                                    floatingLabelText='Data Size'
                                    value={this.props.appState.storedColumn.dataSize ? this.props.appState.storedColumn.dataSize : ''}
                                    onChange={this.updateDataSize.bind(this)}
                                    inputStyle={{ textAlign: 'left' }}>
                                </TextField> 
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='nullability'
                                        /*the nullability checkbox. The Default value MAY be given by the user during a multi column add. If the box is checked the column may have nullable entries(template should print yes) if the box is not checked the column cannot have any nullable entries(and should print no in file)*/
                                        label="Nullability"
                                       // style={styles.checkbox}
                                        style= {{ textAlign: 'left' }}
                                        onCheck={this.updateNullable.bind(this)}
                                        checked={this.props.appState.storedColumn.nullable ? this.props.appState.storedColumn.nullable : false} />
                                </div>
                            </li>
                            <li className='listItem workPaneFields'>
                                <TextField
                                    /*This text field will contain the Definition. when the user first enters the column it will be blank. If the definition field is blank when printed to an excel file the definition field will contain a '?'*/
                                    floatingLabelText="Definition"
                                    value={this.props.appState.storedColumn.definition ? this.props.appState.storedColumn.definition : ''}
                                    onChange={this.updateDefinition}
                                    multiLine={true}
                                    inputStyle={{ textAlign: 'left' }}
                                    style={{ textAlign: 'left'}}
                                    rows={1} />
                            </li>
                            <li>
                                <div style={styles.block} className='customerIdent'>
                                    <Checkbox
                                        /*the Customer Identifiable checkbox. if the box is checked the data is customer Identifiable and the user will have access to the metric select field. when the box is selected when printed an 'X' will appear in the field, if not checked the field will be empty */
                                        label="Customer Identifiable"
                                        onCheck={this.handleCheck.bind(this)}
                                        style= {{ textAlign: 'left' }}
                                        checked={this.props.appState.storedColumn.cii ? this.props.appState.storedColumn.cii : false} />
                                </div>
                            </li>
                            <li>
                                <SelectField
                                    /*Select field for the metrics. Only selectable if Customer Identifiable is true*/
                                    value={this.props.appState.storedColumn.metric ? this.props.appState.storedColumn.metric : ""}
                                    onChange={this.handleMetricChange.bind(this)}
                                    floatingLabelText="Metric"
                                    disabled={dis}
                                    style={{ textAlign: 'left'}}>

                                    {metric}
                                </SelectField>
                            </li>
                            <div style={{ fontSize: '25px' }}>Notes</div>
                            <li className='commentsQuestions'>

                                <AutoComplete
                                    hintText="Comments"
                                    anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
                                    targetOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    //anAutoPosition={true}
                                    dataSource={this.props.appState.currentSetting.commonPhrasesTheArray}
                                    onUpdateInput={this.updateComments}
                                    menuStyle={{ width: '400px', maxHeight: "300px", overflowY: 'auto' }}
                                    listStyle={{ width: '400px' }}
                                    popoverProps={{ style: { marginLeft: '-70px' } }}
                                    searchText={this.props.appState.storedColumn.comments ? this.props.appState.storedColumn.comments : ''}
                                />
                            </li>
                            <li className='commentsQuestions'>

                                <AutoComplete
                                    hintText="Questions"
                                    anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
                                    targetOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    dataSource={this.props.appState.currentSetting.commonPhrasesTheArray}
                                    onUpdateInput={this.updateQuestions.bind(this)}
                                    menuStyle={{ width: '400px', maxHeight: "300px", overflowY: 'auto' }}
                                    listStyle={{ width: '400px' }}
                                    popoverProps={{ style: { marginLeft: '-70px' } }}
                                    searchText={this.props.appState.storedColumn.questions ? this.props.appState.storedColumn.questions : ''}
                                />
                            </li>
                            <div>
                                <RaisedButton
                                    id='completeButton'
                                    /*The completed/uncompleted button, by changing to completed a checkmark will appear in the outermost table, when uncomplete there will not be a checkmark*/
                                    label={this.props.appState.storedColumn.completed ? 'Completed' : 'Uncompleted'}
                                    backgroundColor={(this.props.appState.storedColumn.completed)?'#147aff':'#ff1e1e'}
                                    labelColor='#FFFFFF'
                                    onTouchTap={this.handleCompleteToggle.bind(this)} />
                            </div>
                        </div>

                        <ChevronRight
                            className="lobe mouseCursor"
                            id='rightButton'
                            onTouchTap={this.handleRight} />
                    </div>
                </ul>
            </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    addToColumnList,
    alterColumnName,
    alterVersion,
    removeFromColumnList,
    goToColumn,
    completed,
    uncompleted,
    saveColumn,
    storeComments,
    storeCii,
    storeNullable,
    storeQuestions,
    storeDefinition,
    storeMetric,
    storeDataType,
    storeCompleted,
    storeNewColumnName,
    storeDataSize,
    nextColumn,
    updateSort,
    previousColumn,
    completedPlus,
    completedMinus,
    popPane,
    changeCompletedBack,
    snackBarMessage
};

const RightPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(RightPane);

export default RightPaneContainer;