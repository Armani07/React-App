import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import DataTables from 'material-ui-datatables';
import { addToColumnList, removeFromColumnList, alterColumnName, alterVersion } from '../redux/actions/columnActions.jsx';
import { goToColumn, goBack, openAddValidation, snackBarMessage, openRemoveQADialog, updateRemoveList, appView, closeDialogNewApp, openDialogNewApp, currentColumn, } from '../redux/actions/appActions.jsx';
import { addToQaList, updateQATable, qaHasUpdated, completedSort } from '../redux/actions/qaActions.jsx';
import DataPane from './DataPane.jsx';
import MetricsPane from './MetricsPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';
var ipcRenderer = electron.ipcRenderer;
const TABLE_COLUMNS = [
    {
        key: 'appName',
        label: 'Application',
        sortable: true
    },
    {
        key: 'acronym',
        label: 'Acronym',
        sortable: true
    },
    {
        key: 'completedCheck',
        label: 'Completed',
        sortable: true
    }
];
var ipcRenderer = electron.ipcRenderer;
class ValidationPane extends React.Component {
    constructor(prop) {
        super(prop);
        this.state = { page: 1, rowSize: this.props.appState.currentSetting.perPageSetting, rowSizeList: [10, 25, 50, 100, 200], sort: 'asc', filterText: '', removeColumnList: [], removeList: [], sortColumn: 'columnName' }
        this.handleSelectedEvents = this.handleSelectedEvents.bind(this)
        this.handleCellDoubleClick = this.handleCellDoubleClick.bind(this)
        this.handleRowSizeChange = this.handleRowSizeChange.bind(this)
        this.handleOnSortOrderChange = this.handleOnSortOrderChange.bind(this)
        this.handleOnFilterValueChange = this.handleOnFilterValueChange.bind(this)
        this.handleNextPageClick = this.handleNextPageClick.bind(this)
        this.handlePreviousPageClick = this.handlePreviousPageClick.bind(this)
    }
    static paneProps(props) {
        return {
            newTableDisabled: false,
            openDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
            removeDisabled: false,
            addDisabled: false,
            saveDisabled: false,
            dartDisabled: false,
            sqlDisabled: false,
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        props.openAddValidation()
    }
    static clickRemove(props) {
        if (props.appState.listOfRemovals.length >= 1) {
            props.openRemoveQADialog()
        }
    }
    static clickAddNewFile(props) {
        props.openDialogNewApp();
    }
    static clickOpen(props) {
        props.disablePage();
        props.saved();
        ipcRenderer.send('qaOpen', props.appState.currentSetting.savePath);
    }
    static clickSave(props) {
        props.disablePage(); 
        props.saved();
        ipcRenderer.send('saveValidation', props.qaState.columnList, props.qaState.workingSet, props.appState.currentSetting.savePath, props.appState.currentSetting.saveName, props.appState.storedColumn.acronym);
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    componentWillMount() {
        this.props.updateQATable(this.state.sort, this.state.sortColumn, this.props.qaState.columnList, this.state.filterText, this.state.rowSize, (this.props.qaState.page) ? this.props.qaState.page : 1)
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.qaState.columnUpdated) {
            nextProps.updateQATable(this.state.sort, this.state.sortColumn, nextProps.qaState.columnList, this.state.filterText, this.state.rowSize, (nextProps.qaState.page) ? nextProps.qaState.page : 1)
            nextProps.qaHasUpdated()
        }
    }
    handleSelectedEvents(event) {
        var updatedColumns = [];
        var pageColumnList = this.props.qaState.columnList;
        event.forEach(function (item, index) {
            updatedColumns.push(pageColumnList[item]);
        })
        this.props.updateRemoveList(event, updatedColumns);
        this.setState({ removeList: event, removeColumnList: updatedColumns });
    }
    handleCellDoubleClick(row, column, event) {
        this.props.currentColumn(event);
        this.props.goToColumn(event.columnName);
        this.props.appView(DataPane, 'DataPane')
    }
    handleRowSizeChange(newSize) {
        this.setState({ rowSize: this.state.rowSizeList[newSize] });
        this.setState({ page: 1 });
        this.props.updateQATable(this.state.sort, this.state.sortColumn, this.props.qaState.columnList, this.state.filterText, this.state.rowSizeList[newSize], 1)
    }
    handleNextPageClick() {
        this.props.updateQATable(this.state.sort, this.state.sortColumn, this.props.qaState.columnList, this.state.filterText, this.state.rowSize, this.props.qaState.page + 1);
        this.setState({ page: this.state.page + 1, removeList: [], removeColumnList: [] })
        //  this.props.updateRemoveList([], []);
    }
    handlePreviousPageClick(event) {
        this.props.updateQATable(this.state.sort, this.state.sortColumn, this.props.qaState.columnList, this.state.filterText, this.state.rowSize, this.props.qaState.page - 1);
        this.setState({ page: this.state.page - 1, removeList: [], removeColumnList: [] })
        // this.props.updateRemoveList([], []);
    }
    handleOnSortOrderChange(event, sort) {
        this.props.updateQATable(sort, event, this.props.qaState.columnList, this.state.filterText, this.state.rowSize, this.props.qaState.page);
        this.setState({ sort: sort, sortColumn: event });
    }
    handleOnFilterValueChange(filterText) {
        this.props.updateQATable(this.state.sort, this.state.sortColumn, this.props.qaState.columnList, filterText, this.state.rowSize, this.props.qaState.page)
        this.setState({ filterText: filterText })
    }
    render() {
        return (
            <div>
                <DataTables
                    height={'auto'}
                    selectable={true}
                    showRowHover={true}
                    columns={TABLE_COLUMNS}
                    data={this.props.qaState.sortingColumnList}
                    showCheckboxes={true}
                    onCellClick={this.handleCellClick}
                    onCellDoubleClick={this.handleCellDoubleClick}
                    onSortOrderChange={this.handleOnSortOrderChange}
                    page={this.props.qaState.page}
                    count={this.props.qaState.columnList.length}
                    onRowSelection={this.handleSelectedEvents}
                    multiSelectable={true}
                    selectedRows={this.props.appState.listOfRemovals}
                    rowSize={this.state.rowSize}
                    rowSizeList={this.state.rowSizeList}
                    onRowSizeChange={this.handleRowSizeChange}
                    previousButtonDisabled={false}
                    nextButtonDisabled={1 < ((this.props.qaState.columnList.length / (this.props.qaState.page * this.state.rowSize))) ? false : true}
                    initialSort={{ column: this.props.appState.sortColumn, order: (this.props.appState.sortOrder === 1) ? 'asc' : 'desc' }}
                    showHeaderToolbar={true}
                    onNextPageClick={this.handleNextPageClick}
                    onPreviousPageClick={this.handlePreviousPageClick}
                    title={this.props.qaState.workingSet}
                    onFilterValueChange={this.handleOnFilterValueChange}
                    stripedRows={this.props.appState.currentSetting.stripedColUser}
                    headerToolbarMode={this.props.appState.currentSetting.searchFilterUser ? 'filter' : 'default'}
                    showHeaderToolbarFilterIcon={true}
                    filterValue={this.state.filterText}
                />
                <f2>{this.state.page}</f2>
            </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer,
    qaState: state.qaState
});
const mapDispatchToProps = {
    addToQaList,
    alterColumnName,
    alterVersion,
    goToColumn,
    openRemoveQADialog,
    updateRemoveList,
    currentColumn,
    updateQATable,
    qaHasUpdated,
    completedSort,
    snackBarMessage,
    appView,
    openDialogNewApp,
    closeDialogNewApp,
    openAddValidation
};
const ValidationPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(ValidationPane);
export default ValidationPaneContainer; 
