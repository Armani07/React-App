import React from 'react';
import { connect } from 'react-redux';
import FlatButton from 'material-ui/FlatButton';
import electron from 'electron';
import RaisedButton from 'material-ui/RaisedButton';
import { openSupportPane } from '../redux/actions/appActions.jsx'
import { List, ListItem } from 'material-ui/List';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import Save from 'material-ui-icons/Save';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
import TextField from 'material-ui/TextField';
import { goToColumn, goBack, closeDialogNewFile, newTrelloCard, openDialogNewFile, getTrelloKey, chooseCards, getBoards, getLists, getCards, getMove, getMakeCard, cardDropDownRefreshed, moveCard, makeCard, storeSupportType, snackBarMessage} from '../redux/actions/appActions.jsx';
import Trello from 'node-trello';
import MenuItem from 'material-ui/MenuItem';
import SelectField from 'material-ui/SelectField';
import HelpPane from './HelpPane.jsx';
import SettingsPane from './SettingsPane.jsx';

const supportTypes = [
    <MenuItem key={"Issue"} value={"Issue"} primaryText="Issue" />,
    <MenuItem key={"Suggestion"} value={"Suggestion"} primaryText="Suggestion" />
];
var ipcRenderer = electron.ipcRenderer;
var t;
export class SupportPane extends React.Component {
    constructor(props) {
        super(props);
        this.handleSupportTypeChange = this.handleSupportTypeChange.bind(this);

        this.state = { textValue: '', selectedOption: 'Issues', selectedHintText: "Describe the problem you are having", supportType: "Issue", errorValue: ""}
        ipcRenderer.on('trelloSend', function (event, arg) {
            props.getTrelloKey(arg);
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", arg);
        });
    }
    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        props.popPane()
    }
    static clickHelp(props) {
        props.popPane()
    }
    handlePost = (event, index, id) => {
        if (this.props.appState.token) { 
            if(this.state.selectedOption === 'Issues' && this.state.textValue){
                this.makeTrelloCardIssues();
                this.setState({errorValue: ''}) //Erase Required Field
            }
            else if(this.state.selectedOption === 'Suggestions' && this.state.textValue){
                this.makeTrelloCardSuggestions();
                this.setState({errorValue: ''}) //Erase Required Field
            }
            else {
                this.setState({errorValue: 'Required Field'})
                setTimeout(() => { textField.focus() }, 100); //Focus on Text Field
            }
        }
        else {
            this.props.snackBarMessage("Please log into Trello before submitting a ticket.");
        }
        this.props.newTrelloCard((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);
        this.state.textValue = '';
    }

    handleSupportTypeChange(event, index, supportType) {
        this.setState({supportType: supportType});
        this.setState({errorValue: ''}) //Erase Required Field
        if (supportType === 'Issue')
            this.setState({ selectedOption: 'Issues', selectedHintText: 'Describe issue' })
        if (supportType === 'Suggestion')
            this.setState({ selectedOption: 'Suggestions', selectedHintText: 'Give us a suggestion' })
    }
    handleTextChange(event, newValue){
        this.setState({textValue: newValue});
        this.setState({errorValue: ''}) //Erase Required Field
    }

    makeTrelloCardSuggestions() {
        t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", this.props.appState.token)
        t.post('/1/cards?idList=599c3a7f4d40c2e85010a397&desc=' + this.state.textValue + '&pos=bottom', (err) => {
            if (err) { this.props.snackBarMessage("There was an error submitting to Trello. Please make sure you are logged into Trello."); throw err; }
            else { this.props.snackBarMessage("Your suggestion was submitted sucessfully!"); }
        });
    }
    makeTrelloCardIssues() {
        t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", this.props.appState.token)
        t.post('/1/cards?idList=5a0089c4194e013288bec437&desc=' + this.state.textValue + '&pos=bottom', (err) => {
            if (err) { this.props.snackBarMessage("There was an error submitting to Trello. Please make sure you are logged into Trello."); throw err; }
            else { this.props.snackBarMessage("Your issue was submitted sucessfully!"); }
        });
    }
    render() {
        return (
            <div>
                <ul className="list">
                    <li>
                        <h2>Support Ticket</h2>
                    </li>
                    <li >
                        <SelectField
                            /*A drop down menu box where user will select the columns data type. the value MAY be given by the user during a multi column add.  If none is given, there should be no default value selected*/
                            value={this.state.supportType}
                            onChange={this.handleSupportTypeChange.bind(this)}
                            floatingLabelText="Issue/Suggestion"
                            style={{textAlign:'left'}}>
                            {supportTypes}
                        </SelectField>
                    </li>
                    <li className='List'>
                        <TextField id="textField"
                            floatingLabelText={this.state.selectedOption}
                            inputStyle={{ textAlign: 'center' }}
                            hintText={this.state.selectedHintText}
                            onChange={this.handleTextChange.bind(this)}
                            value = {this.state.textValue}
                            errorText = {this.state.errorValue}
                            multiLine={true}
                            style={{textAlign:'left'}}/>
                    </li>
                    <li
                        style = {{paddingTop: '20px'}}
                    >
                        <RaisedButton
                            backgroundColor="#147aff"
                            label='SUBMIT'
                            labelColor='#FFFFFF'
                            onTouchTap={this.handlePost}
                            primary={false}
                        />
                    </li>
                </ul>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});

const mapDispatchToProps = {
    openSupportPane,
    getTrelloKey,
    openDialogNewFile,
    closeDialogNewFile,
    chooseCards,
    cardDropDownRefreshed,
    makeCard,
    newTrelloCard,
    storeSupportType,
    snackBarMessage,
}

const SupportPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(SupportPane);

export default SupportPaneContainer;