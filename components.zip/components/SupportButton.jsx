import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import SupportPane from './SupportPane.jsx';
import electron from 'electron';
import React, { Component } from 'react';
import DataTables from 'material-ui-datatables';
import { goToColumn, appView, goBack, updateRemoveList, closeDialog, openDialog, currentColumn, updateTable, completedSort, goBackSupport, openSupportPane, popPane } from '../redux/actions/appActions.jsx';
import SupportPaneContainer from './SupportPane.jsx'
import TextField from 'material-ui/TextField';
class SupportButton extends React.Component {
  constructor(props) {
    super(props);
    this.handleSupport = this.handleSupport.bind(this);
  }
  handleSupport() {
    this.props.popPane()
    this.props.appView(SupportPane, "SupportPane")
  };
  render() {
    var pane = this.props.appState.paneArray[this.props.appState.paneArray.length - 1];
    if (pane && pane.paneName === 'HelpPane') {
      return (

        <div className='support' style={{
          position: 'fixed',
          top: '0',
          right: '0'
        }}>
          <RaisedButton
            backgroundColor="#147aff"
            label='Support'
            labelColor='#FFFFFF'
            onTouchTap={this.handleSupport.bind(this)}
          />
        </div>
      );
    }
    else {
      return (null)
    }
  }
}
const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState
});
const mapDispatchToProps = {
  goBackSupport,
  openSupportPane,
  appView,
  popPane
};

const SupportButtonContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(SupportButton);

export default SupportButtonContainer;