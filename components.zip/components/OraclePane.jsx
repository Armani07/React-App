import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import DataTables from 'material-ui-datatables';
import { addToColumnList, removeFromColumnList, alterColumnName, alterVersion, columnHasUpdated } from '../redux/actions/columnActions.jsx';
import { goToColumn, goBack, closeRemoveOracleialog, openRemoveOracleDialog, snackBarMessage,copyDialog, updateRemoveList, appView, closeDialogNewOracle, openDialogNewOracle, currentColumn, updateTable, completedSort, addOracleDialogOpen } from '../redux/actions/appActions.jsx';
import { removeFromOracleList, addToOracleList, updateOracleTable, oracleHasUpdated } from '../redux/actions/oracleActions.jsx';
import RightPane from './RightPane.jsx';
import MetricsPane from './MetricsPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';
import DuplicateFilterPane from'./DuplicateFilterPane.jsx';
var ipcRenderer = electron.ipcRenderer;

const TABLE_COLUMNS = [
    {
        key: 'tableName',
        label: 'Table Name',
        sortable: true
    },
    {
        key: 'columnName',
        label: 'Column Name',
        sortable: true
    },
    {
        key: 'dataType',
        label: 'Datatype',
        sortable: true
    },
    {
        key: 'objectType',
        label: 'Object Type',
        sortable: true
    },
    {
        key: 'status',
        label: 'Status',
        sortable: true
    },
    {
        key: 'compliant',
        label: 'Compliant',
        sortable: true
    },
    {
        key: 'loadDate',
        label: 'Load Date',
        sortable: true
    }
];

var ipcRenderer = electron.ipcRenderer;
class OraclePane extends React.Component {
    constructor(prop) {
        super(prop);
        this.state = { page: 1, rowSize: this.props.appState.currentSetting.perPageSetting, rowSizeList: [10, 25, 50, 100, 200], sort: 'asc', filterText: '', removeColumnList: [], removeList: [], sortColumn: 'columnName' }
        this.handleSelectedEvents = this.handleSelectedEvents.bind(this)
        this.handleCellDoubleClick = this.handleCellDoubleClick.bind(this)
        this.handleRowSizeChange = this.handleRowSizeChange.bind(this)
        this.handleOnSortOrderChange = this.handleOnSortOrderChange.bind(this)
        this.handleOnFilterValueChange = this.handleOnFilterValueChange.bind(this)
        this.handlePreviousPageClick = this.handlePreviousPageClick.bind(this)
        this.handleNextPageClick = this.handleNextPageClick.bind(this)
    }
    static paneProps(props) {
        return {
            newTableDisabled: false,
            openDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
            removeDisabled: false,
            addDisabled: false,
            saveDisabled: false,
            dartDisabled: false,
            tbdDisabled: false,
            sqlDisabled: false,
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickTBD(props){
        props.appView(DuplicateFilterPane, 'DuplicateFilterPane')
      }
    static clickAdd(props) {
        props.addOracleDialogOpen();
    }
    static clickRemove(props) {
        if (props.appState.listOfRemovals.length >= 1) {
            props.openRemoveOracleDialog()
        }
    }
    static clickAddNewFile(props) {
        props.openDialogNewOracle();
    }
    static clickOpen(props) {
        props.disablePage();
        props.saved();
        ipcRenderer.send('oracleOpen', props.appState.currentSetting.savePath);
    }
    static clickSave(props) {
        props.disablePage();
        props.saved();
        ipcRenderer.send('saveOracle', props.oracleState.columnList, props.oracleState.schemaName, props.appState.currentSetting.savePath, props.appState.currentSetting.saveName);
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    // componentWillMount() {
    //     this.props.updateOracleTable(this.state.sort,this.state.sortColumn,this.props.oracleState.columnList, this.props.appState.currentSetting.perPageSetting);
    // }
    componentWillReceiveProps(nextProps) {
        if (nextProps.oracleState.columnUpdated) {
            nextProps.oracleHasUpdated();
            nextProps.updateOracleTable(this.state.sort, this.state.sortColumn, nextProps.oracleState.columnList, this.state.filterText, this.state.rowSize, this.state.page)
        }
    }
    handleNextPageClick(event) {
        this.props.updateOracleTable(this.state.sort, this.state.sortColumn, this.props.oracleState.columnList, this.state.filterText, this.state.rowSize, this.state.page + 1);
        this.setState({ page: this.state.page + 1, removeList: [], removeColumnList: [] })
        this.props.updateRemoveList([], []);
    }
    handlePreviousPageClick(event) {
        this.props.updateOracleTable(this.state.sort, this.state.sortColumn, this.props.oracleState.columnList, this.state.filterText, this.state.rowSize, this.state.page - 1);
        this.setState({ page: this.state.page - 1, removeList: [], removeColumnList: [] })
        this.props.updateRemoveList([], []);
    }
    handleSelectedEvents(event) {
        var updatedColumns = [];
        var pageColumnList = this.props.oracleState.sortingColumnList;
        event.forEach(function (item, index) {
            updatedColumns.push(pageColumnList[item]);
        })
        this.props.updateRemoveList(event, updatedColumns);
        this.setState({ removeList: event, removeColumnList: updatedColumns });
    }
    handleCellDoubleClick(row, column, event) {
        this.props.copyDialog("Select " + event.columnName + " from " + this.props.oracleState.schemaName + "." +  event.tableName + ";")
    }
    handleRowSizeChange(newSize) {
        this.setState({ rowSize: this.state.rowSizeList[newSize] });
        this.setState({ page: 1 });
        this.props.updateOracleTable(this.state.sort, this.state.sortColumn, this.props.oracleState.columnList, this.state.filterText, this.state.rowSizeList[newSize], 1);
    }
    handleOnSortOrderChange(event, sort) {
        this.props.updateOracleTable(sort, event, this.props.oracleState.columnList, this.state.filterText, this.state.rowSize, this.state.page)
        this.setState({ sort: sort, sortColumn: event });
    }
    handleOnFilterValueChange(filterText) {
        this.props.updateOracleTable(this.state.sort, this.state.sortColumn, this.props.oracleState.columnList, filterText, this.state.rowSize, 1)
        this.setState({ filterText: filterText })
    }
    render() {
        return (
            <div>
            <DataTables
                height={'auto'}
                selectable={true}
                showRowHover={true}
                columns={TABLE_COLUMNS}
                data={this.props.oracleState.sortingColumnList}
                showCheckboxes={true}
                onCellClick={this.handleCellClick}
                onCellDoubleClick={this.handleCellDoubleClick}
                onSortOrderChange={this.handleOnSortOrderChange}
                page={this.state.page}
                count={this.props.oracleState.columnList.length}
                onRowSelection={this.handleSelectedEvents}
                multiSelectable={true}
                selectedRows={this.props.appState.listOfRemovals}
                rowSize={this.state.rowSize}
                rowSizeList={this.state.rowSizeList}
                onNextPageClick={this.handleNextPageClick}
                onPreviousPageClick={this.handlePreviousPageClick}
                onRowSizeChange={this.handleRowSizeChange}
                nextButtonDisabled={false}
                initialSort={{ column: this.props.oracleState.sortColumn, order: (this.props.oracleState.sortOrder === 1) ? 'asc' : 'desc' }}
                showHeaderToolbar={true}
                title={this.props.oracleState.schemaName}
                onFilterValueChange={this.handleOnFilterValueChange}
                stripedRows={this.props.appState.currentSetting.stripedColUser}
                headerToolbarMode={this.props.appState.currentSetting.searchFilterUser ? 'filter' : 'default'}
                showHeaderToolbarFilterIcon={true}
                filterValue={this.props.appState.filterText}
            />
            <f2>{this.state.page}</f2>
                </div> 
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer,
    oracleState: state.oracleState
});

const mapDispatchToProps = {
    openRemoveOracleDialog,
    addToOracleList,
    alterColumnName,
    alterVersion,
    removeFromOracleList,
    goToColumn,
    updateRemoveList,
    currentColumn,
    updateTable,
    columnHasUpdated,
    completedSort,
    snackBarMessage,
    appView,
    oracleHasUpdated,
    addOracleDialogOpen,
    openDialogNewOracle,
    closeDialogNewOracle,
    updateOracleTable,
    copyDialog
};

const OraclePaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(OraclePane);

export default OraclePaneContainer; 
