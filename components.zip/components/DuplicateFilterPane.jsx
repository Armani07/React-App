import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { goToColumn, goBack, closeDialog, openDialog, currentColumn } from '../redux/actions/appActions.jsx';
import RaisedButton from 'material-ui/RaisedButton';
var ipcRenderer = electron.ipcRenderer;

class DuplicateFilterPane extends React.Component {

    constructor(props) {
        super(props);
        this.state = { textValue: '', text: '' }
        this.updateValue = this.updateValue.bind(this)
        this.makeReport = this.makeReport.bind(this)
        this.handleClear = this.handleClear.bind(this)
    }
    static paneProps() {
        return {
            backDisabled: false,
            dartDisabled: false,
            sqlDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
        }
    }
    makeReport() {
        var text = this.state.textValue.trim()
        var data = text.replace(/\n/g, '_').split('_');
        let result = [];
        var count = 1;
        var varParse = false
        var varParse2 = false
        var i = 0
        var j = 0
        while (varParse === false) {
            if (data.length < i) {
                varParse = true;
            }
            if (data.length > i) {
                varParse2 = false
            }
            while (varParse2 === false) {
                if (data[i] === data[j]) {
                    count++;
                }
                if (data.length === j + 1) {
                    result.push({ name: data[i], count: count });
                    varParse2 = true
                    j = 0;
                    count = 0;
                }
                j++
            }
            data = data.filter(word => data[i] !== word)
            i++;
        }
        var varSomeText = result.sort((a, b) => {
            var aSort, bSort;
            aSort = a.count;
            bSort = b.count;
            if (aSort < bSort) {
                return 1 * 1;
            } else if (aSort > bSort) {
                return 1 * -1;
            }
            return 0;
        })

        var finalText = ''
        for (var n = 0; result.length > n; n++) {
            finalText = (finalText + "Variable: " + varSomeText[n].name + " Count: " + varSomeText[n].count + '\n' + "t.column_name LIKE '%" + varSomeText[n].name + "%' OR" + "\n" + "\n")
        }
        this.setState({ text: finalText })
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    handleClear() {
        this.setState({ textValue: '', text: '' })
    }
    updateValue = (event, newValue) => {
        this.setState({ textValue: newValue });
    };

    render() {
        return (
            <div id='wrapper'>
                
                <ul className='list6'>
                    <li><h2 className='titleText'>Data</h2></li>
                    <li>
                        <TextField
                            className='textbox'
                            hintText="Paste Data Here"
                            style = {{paddingTop: '50px'}}
                            multiLine={true}
                            rows={5}
                            fullWidth={true}
                            rowsMax={10}
                            onChange={this.updateValue}
                            value={this.state.textValue} 
                            fullWidth={true}
                            hintStyle = {{textAlign: 'Right'}}
                        /> 
                        <br />
                    </li>
                    <li>
                    <div>
                       <div id='btnDuplicateFilterPaneSubmit'>
                       <RaisedButton
                            label="Submit"
                            backgroundColor = '#147aff'
                            labelColor='#FFFFFF'
                            onTouchTap={this.makeReport.bind(this)}
                        />
                        </div>
                            <div id='btnDuplicateFilterPaneClear'>
                        <RaisedButton
                            id='clearTBD'
                            label="Clear"
                            backgroundColor='#ff1e1e'
                            labelColor='#FFFFFF'
                            onTouchTap={this.handleClear}
                        />
                        </div>
                    </div>            
                    </li>
                    <li><h2 className='titleText2'>Report Text</h2></li>
                    <li>
                        <TextField
                            hintText="Report Text"
                            multiLine={true}
                            rows={5}
                            fullWidth={true}
                            rowsMax={10}
                            value={this.state.text}
                        /> 
                        <br />
                    </li>
                </ul>
            </div>
        )
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {

};

const DuplicateFilterPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)
    (DuplicateFilterPane);

export default DuplicateFilterPaneContainer;