import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Checkbox from 'material-ui/Checkbox';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { disablePage, openDialogColumn, closeAddValidation, closeDialogColumn, removeOracleDialogOpen, addOracleDialogRemove } from '../redux/actions/appActions.jsx';
import { addToQaList } from '../redux/actions/qaActions.jsx';
class DialogAddValidation extends React.Component {
    constructor(props) {
        super(props);
        this.state = { textValue: '' };
        this.state = { open: true };
        this.handleClose = this.handleClose.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.parse = this.parse.bind(this);
    }
    updateValue = (event, newValue) => {
        this.setState({ textValue: newValue });
    };
    handleOpen = () => {
        this.props.openDialogColumn();
    };
    handleClose = () => {
        this.props.closeAddValidation();
        this.setState({ open: false });
    };
    handleClick = () => {
        if (this.state.textValue !== undefined) {
            this.parse(this.state.textValue);
        }
        this.props.closeAddValidation();
    }
    parse = (text) => {
        var holdingArray = text.split('\n') //Seperates each line of text
        var splitAppName = "";
     for (var k = 0; k !== holdingArray.length; k++) { // loops through each line of text 
            splitAppName = holdingArray[k].split('\t') // seperates text at each tab
            if (holdingArray[k].trim().length > 0) {   // removes any empty rows 
                this.props.addToQaList({ 
                    appName: splitAppName[0], // sets appName
                    acronym: splitAppName[1], // sets aconrym
                    //defaults for other fields in pane
                    q1: false,
                    q2Answer: '',
                    q3: false,
                    q4: false,
                    q5: false,
                    q6: false,
                    q7Answer: '',
                    q8: false,
                    question: '',
                    comments: '',
                    loadDate: '',
                })
            }
        }
    }
    render() {
        const actions = [

            <RaisedButton
                id='create'
                label="Create"
                backgroundColor='#147aff'
                labelColor='#FFFFFF'
                keyboardFocused={true}
                onTouchTap={this.handleClick}
            />,
            <RaisedButton
                label="Cancel"
                backgroundColor='#ff1e1e'
                labelColor='#FFFFFF'
                keyboardFocused={false}
                onTouchTap={this.handleClose}
            />
        ]
        const focusInputField = input => {
            if (input) {
                setTimeout(() => { input.focus() }, 100);
            }
        };

        return (
            <div>
                <Dialog
                    id='colName'
                    ref='dia'
                    title="Insert application names"
                    actions={actions}
                    modal={true}
                    open={this.props.appState.addValidationOpen}
                    onRequestClose={this.handleClose}>
                    You must fill in the field before continuing<br />
                    <br />

                    <TextField
                        id='dialogText'
                        ref={focusInputField}
                        onKeyPress={this.onKeyPress}
                        name="Information"
                        rowsMax={1}
                        fullWidth={true}
                        type="con"
                        hintText="List of Information"
                        onChange={this.updateValue}
                        multiLine={true} />
                </Dialog>
            </div >
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer,
    oracleState: state.oracleState
});

const mapDispatchToProps = {
    openDialogColumn,
    closeDialogColumn,
    disablePage,
    removeOracleDialogOpen,
    addOracleDialogRemove,
    closeAddValidation,
    addToQaList
};

const DialogAddValidationContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)
    (DialogAddValidation);

export default DialogAddValidationContainer;
