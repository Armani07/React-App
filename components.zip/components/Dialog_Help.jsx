import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import { closeDialogHelp } from '../redux/actions/appActions.jsx'
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import Save from 'material-ui-icons/Save';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';

const customContentStyle = {
  width: '100%',
  maxWidth: 'none',
};

class DialogBoxHelp extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
    this.onKeyPress = this.onKeyPress.bind(this);
  }
  //when cancel is selected on the dialog box, handleClose will close the Dialog box and set the local state open to false
  handleClose = () => {
    this.props.closeDialogHelp();
    this.setState({ open: false });
  };
  //if enter is pressed it will preform the same action as the submit button
  onKeyPress(event) {
    if (event.charCode === 13) {
      //on keyboard press of enter (enter's charcode value is 13)
      event.preventDefault();
      if (this.state.textValue) {
        this.props.addToColumnList(this.state.textValue);
        this.props.closeDialog();
      }
    }
  }

  render() {
    //Submit button. Should be unselectable if nothing is entered in the text box. User should be able to press enter as well
    const actions = [
      <FlatButton
        label="OK"
        primary={true}
        onTouchTap={this.handleClose} />,
    ];

    return (
      <div>
        <Dialog
          /*The dialog box*/
          title="VDA Help"
          actions={actions}
          modal={false}
          open={this.props.appState.helpDialog}
          contentStyle={customContentStyle}
          onRequestClose={this.handleClose}>
          
        <ul className='listing'>
          <li className='helpText'>
            <ArrowBack />
              When inside of a column the back button will bring you to the table view.<br />
              The back button will be disabled unless you are inside of a column. <br />
          </li>
          <li className='helpText'>
            <Add />
              Add button has two options (Multi and Single):<br />
              Multi will allow you to paste multiple columns (Only column name, datatype and nullability) to the table directly from the database. <br />
              Single will only accept a column name and create a single column in the table. <br />
              Add is disabled unless in the table view.
          </li>
          <li className='helpText'>
            <Remove />
              Remove will allow you to delete several selected columns within the same pane of the table. Remove will be disabled unless a column is checkmarked.<br />
          </li>
          <li className='helpText'>
            <InsertDriveFile />
              The New File will create a new table with name given by user. Creating a new file will remove all previous work done so be sure you have saved before using. The New File will be disabled within a column <br />
          </li>
          <li className='helpText'>
            <Folder />
              No functionality yet. Please look forward to it.<br />
          </li>
          <li className='helpText'>
            <Save />
              Save button will allow you to save your work into an excel file. You can only save from the table view. <br />
          </li>
        </ul>
        v1u6
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  closeDialogHelp
};

const DialogBoxHelpContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (DialogBoxHelp);

export default DialogBoxHelpContainer;