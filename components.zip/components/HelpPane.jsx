import React from 'react';
import { connect } from 'react-redux';
import FlatButton from 'material-ui/FlatButton';
import electron from 'electron';
import RaisedButton from 'material-ui/RaisedButton';
import { openHelpPane } from '../redux/actions/appActions.jsx'
import { List, ListItem } from 'material-ui/List';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import SupportPane from './SupportPane.jsx';
import Save from 'material-ui-icons/Save';
import Folder from 'material-ui-icons/Folder';
import FindInPage from 'material-ui-icons/FindInPage';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Receipt from 'material-ui-icons/Receipt';
import NotInterested from 'material-ui-icons/NotInterested';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import SettingsPane from './SettingsPane.jsx';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
import SupportButtonContainer from './SupportButton.jsx';
var versionNumber = 'v1u12';
export class HelpPane extends React.Component {

    constructor(props) {
        super(props);
    }
    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        props.popPane();
    }
    static clickHelp(props) {
        return (null)
    }
    render() {
        return (
            <div id='wrapper3'>
                <ul className='list3'>
                    <li>
                        <h2>Help</h2>
                    </li>
                       <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='createTableHelp'
                            title="Menu Settings"
                            actAsExpander={true}
                            showExpandableButton={true}
                            titleStyle={{ marginRight: '10px' }}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='createTableHelpText'
                                className='list2'>     
                                <li>                          
                                    <ArrowBack id='arrow' />
                                    When inside of a different page in the app, the back button will always bring you back to your previous page. If you are trying to go back while in the settings or help page, the Back button will bring you back to the home page.<br />
                                </li>
                                <li>
                                    <Add id='add' />
                                    Add will always add rows inside a table:<br />                               
                                    </li>
                                <li>
                                    <Remove id='remove' />
                                    Remove will always allow the user to delete rows inside a table.<br />
                                </li>
                                <li>
                                    <InsertDriveFile id='insertDriveFile' />
                                     New File will always allow the user to create a new table inside the workspace. The new workspace is known as the table view. <br />
                                </li>
                                <li>
                                    <Folder id='folder' />
                                    Open will always allow the user to open an existing table.<br />
                                </li>
                                <li>
                                    <Save id='save' />
                                    Save will always save the current table being worked on. <br />
                                </li>
                                <li>
                                    <MergeType id='merge' />
                                     Merge will always allow you to merge several metrics sheets together.
                                    </li>
                                <li>
                                    <Receipt id='dart' />
                                     DART will always allow users to access a template to submit DARs.
                                    </li>
                                <li>
                                    <FindInPage id='SQGenerator' />
                                    This will always takes you to the SQL Generator page.
                                    </li>  
                                <li>
                                    <Settings id='setting' />
                                    Settings will always takes you to the Settings page.
                                    </li>            
                            </ul>
                        </CardText>
                    </Card>
                    <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='createTableHelp'
                            title="Visiual Oracle Data Scrubbing"
                            actAsExpander={true}
                            showExpandableButton={true}
                            titleStyle={{ marginRight: '10px' }}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='createTableHelpText'
                                className='list2'>
                                <li>
                                    <strong>This workspace will be used for identifying customer information.</strong>                                    
                                 </li>
                                 <br />
                                <li>
                                    <Add id='add' />
                                   <strong>Adding rows to a table</strong>- The Add button will allow you to paste multiple or single rows (column name, datatype and nullability) to the table directly from the database.
                                   However you can only manually type one row, but you may copy more than one column into the dialog.
                                    Add is disabled unless in table view.
                                    </li>  
                                <li><strong>Creating a New Table</strong>-In order to create a new table you need to click on the New Table button (<InsertDriveFile />) and that will take you to the
                                    screen to create a new table. From there you can log into Trello to add the table you are creating to your group's Trello board.
                                    Type in the new name or select a card to start a new table. Press Submit and you are ready to start adding columns. To add columns
                                    select the Add button (<Add />) and copy and paste the columns from Oracle.
                                </li>                       
                                <li>                                
                                    <h3>Column workspace</h3>
                                </li>                                
                                 <li>
                                    <strong>Column Name</strong> - If the column name needs to be changed at anytime,
                                    the user can edit it in this field.
                                </li>
                                <li>
                                    <strong>Data Type</strong> - In this field the user must identify the type of data
                                    that they are viewing by selecting from one of the fields form the list.
                                </li>
                                <li>
                                    <strong>Data Size</strong> - The  user can put the amount of space that the current
                                    column takes up.
                                </li>
                                <li>
                                    <strong>Nullability</strong> - The user can check whether the column is null or not.
                                    Null means its empty.
                                </li>
                                <li>
                                    <strong>Definition</strong> - Defaulted to a question mark, but the main purpose of this
                                    field is to describe what type of data is being exposed.
                                </li>
                                <li>
                                    <strong>Metric</strong> -If the user has checked the Customer Identifiable Information box
                                    then they must then select whether it's ACII(Actual Customer Identifiable  Information) or
                                    PCII(Potentially Customer Identifiable Information)
                                </li>
                                <li>
                                    <strong>Notes Section</strong> -In this section if the user has anything they would like to
                                    mention, they can enter them in the comment section. If the user has any questions about the
                                    data they can enter them in the question field.
                                </li>                                                                       
                            </ul>
                        </CardText>
                    </Card>
                     <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='oracleAutomationHelp'
                            title="Oracle Automation"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='oracleAutomationHelpText'
                                className='list2'>
                                <li>
                                    <strong>This works space is used to create schemas.</strong>                                  
                                </li>
                                <br/>
                                 <li>
                                    <InsertDriveFile id='insertDriveFile' />
                                    <strong>Creating a New Schema Table</strong>. To create a new schema the user must press the New Table button. 
                                    They will then be presented with a dialog that asks for the name of the table.
                                    Once the name of the table has been entered, the user will be taken to the table view. <br />
                                </li> 
                                 <li>
                                    <Add id='add' />
                                   <strong> Adding Rows into the Schema Table</strong>The add functionality will not work unless you enter a value in all 6 rows. 
                                    The user can do this by entering their desired string and then putting a space between each one they create until there are 6 total strings.
                                    The user can also paste single or multiple rows if they choose. <br />
                                    </li>                        
                                <li>
                                 <strong>Copying the Row</strong>- To copy the column you are creating in the schema, double click on the row and a dialog will appear allowing you to edit the generated script. when the submit button is clicked the script will save to your clipboard and a notification will appear.
                                 </li> 
                                 <li>
                                     <NotInterested id='insertDriveFile'/>
                                     <strong>Duplicate Filter Pane</strong>- The Duplicate Filter Pane has two text fields. The top text field is for pasting data into with the format "textA_textB_textC" and "\n".  The bottom text field is for displaying the variable, count, and script of each unique word.  The information generated sorts by the count of the occurrences of a word.  The submit button will generate text in the bottom text field.  The clear button will clear both text fields. 

                                     </li>  
                                 <li>                                
                                    <h3>Column Descriptions</h3>
                                </li>  
                                 <li>
                                 <strong>Table Name</strong> - This field lists the table name.
                                </li>
                                <li>
                                    <strong>Column Name</strong> - This field lists the column name. 
                                </li>
                                <li>
                                    <strong>Datatype</strong> - This field lists the different types of data the user is working on.
                                </li>
                                <li>
                                    <strong>Object Type</strong> - This field shows the type of object that the user is on.
                                </li>
                                <li>
                                    <strong>Status</strong> - This field is for the user to give the status for the schema.
                                </li>
                                <li>
                                    <strong>Compliant</strong> - This field is for the user to enter the compliant for the Schema
                                </li>
                                 <li>
                                    <strong>Load Date</strong> - This field shows the date that the schema was viewed.
                                </li>                                                                                                                            
                            </ul>
                        </CardText>
                    </Card>
                   <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='applicationValidationHelp'
                            title="Application Validation"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='applicationValidationHelpText'
                                className='list2'>
                                <li>
                                   <strong> The user will use this workspace to submit applications that are sent from CenturyLink to be tested for authorized users.</strong>
                                    <li>
                                        <br/>
                                    <Add id='add' />
                                    <strong>Adding Application Rows</strong> They will be introduced to a new dialog for adding applications to the table. 
                                    The user may enter more than one row and paste multiple rows in if they choose.<br />
                                    </li>
                                <li>
                                    <InsertDriveFile id='insertDriveFile' />
                                   <strong>Creating a New Table</strong> To a create a new table,  click the Create New Table button. You will then be presented with a dialog to enter the name of the the table. Once the table name is entered you will be brought to table view. <br />
                                </li>
                                <li>                                
                                    <h3>Column workspace</h3>
                                    </li>
                                    <li>
                                    <strong>Questions</strong> - This is where the user will submit any questions they have about the application they are working on.
                                </li> 
                                  <strong>Comments</strong> - This is where the user will submit any comments or anything concerning the application they are working on.                       
                                </li>
                            </ul>
                        </CardText>
                    </Card>
                    <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='mergeHelp'
                            title="How to Merge"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='mergeHelpText'
                                className='list2'>       
                                <li>
                                    First you need to make sure that all of the metrics sheets you are about to merge have been opened
                                    and saved correctly. Then you need to click on the merge button (<MergeType />) to go to the merge pane.
                                    Then you would need to press the add button (<Add />) and add as many metrics sheets as necessary.
                                    Then you would press the save button (<Save />) and save it to a location of your choosing.
                                </li>
                            </ul>
                        </CardText>
                    </Card>      
                     <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='dartHelp'
                            title="How to Submit DARs"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='DartHelpText'
                                className='list2'>       
                                <li>
                                    First you have to click on the DART button (<Receipt/>) to go to the DART pane.
                                    You will need to have the Corporate Unit Identification(CUID) ready to fill in the appropriate field.
                                    Then you would check the box in the field for a Model or Mirror ID if applicable. 
                                    If the checkbox is checked, then type the Mirror or Model ID, whichever one is given, inside the field under the checkbox.
                                    The last field you will need to fill in will be for the name of the database. Once all the appropriate fields are filled out, click the Generate button. 
                                    The Generate button will generate instructions on how to submit your DAR request.
                                </li>
                            </ul>
                        </CardText>
                    </Card>    
                      <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='SQLHelp'
                            title="SQL Generator"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='SQLHelpText'
                                className='list2'>       
                                <li>
                                    After entering into the SQL Generator Pane, the user will be met with two checkboxes, four textboxes, and a "Generate" button. For the first checkbox, if the user selects the checkbox to "Select all columns", it will allow a SQL statement to be printed that will run every column. If the user does not want every column to run then they will have to manually fill in the column they are running the SQL command for. The second Checkbox is if the user wants to run a select procedure with the "Distinct" command in SQL.<br/>
                                    <strong>Column Name</strong>-This field is where the user will specify what column to select.<br/>
                                    <strong>Owner</strong> -This field is where the user will insert the owner's name.<br/>
                                    <strong>Table Name</strong> -This field is where the user will indicate the table being looked at. <br/>
                                    <strong>Where Satetment</strong> -This field is where the user will insert where they want to select from.<br/>
                                    <strong>After filling in the texfields needed, the user will click "Generate" and a select procedure will display at the bottom that they can use for their current SQL task. </strong>                     
                                </li>
                            </ul>
                        </CardText>
                    </Card>                      
                    <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                        <CardTitle
                            id='settingsHelp'
                            title="Settings Help"
                            actAsExpander={true}
                            showExpandableButton={true}
                            style={{textAlign:'left'}}
                        />
                        <CardText expandable={true}>
                            <ul
                                id='settingsHelpText'
                                className='list2'>
                                <li>
                                    <h3>Reports</h3>
                                </li>
                                <li>
                                    <strong>Visiual Oracle Data Scrubbing</strong> - Allows you to select the workspace for identifying customer data.
                                </li>
                                 <li>
                                    <strong>Oracle Automation</strong> - Allows you to select the workspace for creating schema tables.
                                </li>
                                 <li>
                                    <strong>Application Validation</strong> - Allows you to select the workspace for authenticating users for applications sent from CenturyLink.
                                </li>
                                <li>
                                    <h3>Trello Settings</h3>
                                </li>
                                <li>
                                    <strong>Trello Boards</strong> - Allows you to select the Trello board you wish to work in.
                                </li>
                                <li>
                                    <strong>Trello Lists</strong> - Allows you to select the Trello list you wish to work out of.
                                </li>
                                <li>
                                    <strong>Move Card To</strong> - Allows you to select the column that the Trello card will move to.If the user does not want to move th ecard they are working on, select the field that is null.
                                </li>
                                <li>
                                    <strong>Trello Login</strong> - Allows you to log into Trello.
                                </li>
                                <li>
                                    <h3>Column Table Settings</h3>
                                </li>
                                <li>
                                    <strong>Columns Per Table Page</strong> - Allows you to select the number of columns you view on a page.
                                </li>
                                <li>
                                    <strong>Screen Size</strong> - Allows you to select the size the screen loads as. (Full screen, Half screen vertical, or Half screen horizontal)
                                </li>
                                <li>
                                    <strong>Search Filter on Creation</strong> - Allows you to search through the table for columns.
                                </li>
                                <li>
                                    <strong>Striped Column Rows</strong> - Makes every other row striped on the column pages.
                                </li>
                                <li>
                                    <strong>Auto Uppercase Table and Column Names</strong> - Allows you to choose to automatically save the table with uppercase title and uppercase column names.
                                </li>
                                <li>
                                    <strong>Automatic Table Name as Save File</strong> - Automatically save the table as the table name and does not display dialog box.
                                </li>
                                <li>
                                    <strong>Disable Warning for Incomplete Columns</strong> - Allows you to disable the warning if you have incomplete columns.
                                </li>
                                <li>
                                    <strong>Disable Warning for Metric Merge</strong> - Allows you to disable the warning in the metrics pane that warns you that you have entered two tables with the same name.
                                </li>
                                <li>
                                    <h3>File Settings</h3>
                                </li>
                                <li>
                                    <strong>Default Open Location</strong> - Allows you to select a default location to open tables from.
                                </li>
                                <li>
                                    <strong>Default Save Location</strong> - Allows you to select a default location to save tables to.
                                </li>
                                <li>
                                    <h3>Phrases</h3>
                                </li>
                                <li>
                                    <strong>Enter Phrases Here</strong> - Allows you to enter common phrases that you would use in filling out columns.
                                </li>
                                <li>
                                    <strong>Phrases Table</strong> - Shows the common phrases you have entered.
                                </li>
                                <li>
                                    <strong>Remove</strong> - Allows you to remove phrases that you have entered from the phrases table.
                                </li>
                                <li>
                                    <strong>Import Phrases</strong> - Allows you import an excel sheet with common phrases.
                                </li>
                                <li>
                                    <strong>Export Phrases</strong> - Allows you export an excel sheet with common phrases.
                                </li>
                            </ul>
                        </CardText>
                    </Card>
                </ul>
                <div>
                    {versionNumber}
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});

const mapDispatchToProps = {
    openHelpPane,
}

const HelpPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(HelpPane);

export default HelpPaneContainer;