import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import MetricsPane from './MetricsPane.jsx';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { removeFromQaList } from '../redux/actions/qaActions.jsx';
import { goToColumn, goBack, openRemoveQADialog, closeRemoveQADialog, updateRemoveList } from '../redux/actions/appActions.jsx';
import { updateMetricRemove, removeFromMetricsList } from '../redux/actions/metricActions.jsx'

const customContentStyle = {
  width: '50%',
  maxWidth: 'none',
};
class RemoveQADialogBox extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.updateValue = this.updateValue.bind(this);
    this.createColumn = this.createColumn.bind(this);
  }

  handleOpen = () => {
    this.props.openRemoveQADialog();
  };
  handleClose = () => {
    this.props.closeRemoveQADialog();
  };
  remove = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.removeFromQaList(this.props.appState.updatedColumns);
      this.props.updateRemoveList([], []);
      this.props.closeRemoveQADialog();
    } else {
      this.props.removeFromMetricsList(this.props.metricReducer.metricsList)
      this.props.closeRemoveQADialog();
    }
  };
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };
  createColumn = () => {
    this.props.addToColumnList(this.state.textValue);
    this.props.closeDialog();
  };
  doNo = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.updateRemoveList([]);
      this.props.closeRemoveQADialog();
    } else {
      this.props.updateMetricRemove([]);
      this.props.closeRemoveQADialog();
    }
  };

  render() {
    const actions = [
      <RaisedButton
        id = 'yes'
        label="Yes"
        backgroundColor = '#147aff'
        labelColor='#FFFFFF'
        onTouchTap={this.remove}
      />,
      <RaisedButton
        label="No"
        backgroundColor='#ff1e1e'
        labelColor='#FFFFFF'
        onTouchTap={this.doNo}
      />
    ];

    return (
      <div>
        <Dialog
          ref='dia'
          title="Are you sure you would like to remove the selected rows?"
          actions={actions}
          modal={false}
          open={this.props.appState.removeQADialog}
          onRequestClose={this.handleClose}
          contentStyle={customContentStyle}>
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer,
  qaState: state.qaState
});

const mapDispatchToProps = {
  openRemoveQADialog,
  closeRemoveQADialog,
  removeFromQaList,
  updateRemoveList,
  updateMetricRemove,
  removeFromMetricsList
};

const RemoveQADialogBoxContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (RemoveQADialogBox);

export default RemoveQADialogBoxContainer;