
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import MetricsPane from './MetricsPane.jsx';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { removeFromColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, closeRemoveDialog, openRemoveDialog, updateRemoveList } from '../redux/actions/appActions.jsx';
import { updateMetricRemove, removeFromMetricsList } from '../redux/actions/metricActions.jsx'

const customContentStyle = {
  width: '50%',
  maxWidth: 'none',
};
class RemoveDialogBox extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.updateValue = this.updateValue.bind(this);
    this.createColumn = this.createColumn.bind(this);
  }

  handleOpen = () => {
    this.props.openRemoveDialog();
  };
  handleClose = () => {
    this.props.closeRemoveDialog();
  };
  remove = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.removeFromColumnList(this.props.appState.updatedColumns);
      this.props.updateRemoveList([], []);
      this.props.closeRemoveDialog();
    } else {
      this.props.removeFromMetricsList(this.props.metricReducer.metricsList)
      this.props.closeRemoveDialog();
    }
  };
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };
  createColumn = () => {
    this.props.addToColumnList(this.state.textValue);
    this.props.closeDialog();
  };
  doNo = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.updateRemoveList([]);
      this.props.closeRemoveDialog();
    } else {
      this.props.updateMetricRemove([]);
      this.props.closeRemoveDialog();
    }
  };

  render() {
    const actions = [
      <RaisedButton
        id = 'yes'
        label="Yes"
        backgroundColor = '#147aff'
        labelColor='#FFFFFF'
        onTouchTap={this.remove}
      />,
      <RaisedButton
        label="No"
        backgroundColor='#ff1e1e'
        labelColor='#FFFFFF'
        onTouchTap={this.doNo}
      />
    ];

    return (
      <div>
        <Dialog
          ref='dia'
          title="Are you sure you would like to remove the selected rows?"
          actions={actions}
          modal={false}
          open={this.props.appState.removeDialog}
          onRequestClose={this.handleClose}
          contentStyle={customContentStyle}>
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openRemoveDialog,
  closeRemoveDialog,
  removeFromColumnList,
  updateRemoveList,
  updateMetricRemove,
  removeFromMetricsList
};

const RemoveDialogBoxContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (RemoveDialogBox);

export default RemoveDialogBoxContainer;