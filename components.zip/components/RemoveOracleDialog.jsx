
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import MetricsPane from './MetricsPane.jsx';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { removeFromOracleList } from '../redux/actions/oracleActions.jsx';
import { goToColumn, goBack, closeRemoveOracleialog, openRemoveOracleDialog, closeRemoveOracleDialog, updateRemoveList } from '../redux/actions/appActions.jsx';
import { updateMetricRemove, removeFromMetricsList } from '../redux/actions/metricActions.jsx'

const customContentStyle = {
  width: '50%',
  maxWidth: 'none',
};
class RemoveOracleDialogBox extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.updateValue = this.updateValue.bind(this);
    this.createColumn = this.createColumn.bind(this);
  }

  handleOpen = () => {
    this.props.openRemoveOracleDialog();
  };
  handleClose = () => {
    this.props.closeRemoveOracleDialog();
  };
  remove = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.removeFromOracleList(this.props.appState.updatedColumns);
      this.props.updateRemoveList([], []);
      this.props.closeRemoveOracleDialog();
    } else {
      this.props.removeFromMetricsList(this.props.metricReducer.metricsList)
      this.props.closeRemoveOracleDialog();
    }
  };
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };
  createColumn = () => {
    this.props.addToColumnList(this.state.textValue);
    this.props.closeDialog();
  };
  doNo = () => {
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName !== 'MetricsPane') {
      this.props.updateRemoveList([]);
      this.props.closeRemoveOracleDialog();
    } else {
      this.props.updateMetricRemove([]);
      this.props.closeRemoveOracleDialog();
    }
  };

  render() {
    const actions = [
      <RaisedButton
        id = 'yes'
        label="Yes"
        backgroundColor = '#147aff'
        labelColor='#FFFFFF'
        onTouchTap={this.remove}
      />,
      <RaisedButton
        label="No"
        backgroundColor='#ff1e1e'
        labelColor='#FFFFFF'
        onTouchTap={this.doNo}
      />
    ];

    return (
      <div>
        <Dialog
          ref='dia'
          title="Are you sure you would like to remove the selected rows?"
          actions={actions}
          modal={false}
          open={this.props.appState.removeOracleDialog}
          onRequestClose={this.handleClose}
          contentStyle={customContentStyle}>
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer,
  oracleState: state.oracleState
});

const mapDispatchToProps = {
  openRemoveOracleDialog,
  closeRemoveOracleDialog,
  removeFromOracleList,
  updateRemoveList,
  updateMetricRemove,
  removeFromMetricsList
};

const RemoveOracleDialogBoxContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (RemoveOracleDialogBox);

export default RemoveOracleDialogBoxContainer;