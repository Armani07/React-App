import React, { Component } from 'react';
import RightPane from './RightPane.jsx';
import LeftPane from './LeftPane.jsx';
import { connect } from 'react-redux'
import { addToColumnList, removeFromColumnList, alterColumnName, alterVersion } from '../redux/actions/columnActions.jsx';
import { goToColumn, goBack, hideSaveNotice, appView } from '../redux/actions/appActions.jsx';
import HomeComp from './HomeComp.jsx';
import Snackbar from 'material-ui/Snackbar';
import SettingsPane from './SettingsPane.jsx';
import MetricsPane from './MetricsPane.jsx';
import DartPane from './DartPane.jsx';
import HelpPane from './HelpPane.jsx';
import SQLGeneratorPane from './SQL_Generator_Pane.jsx';
import SupportPane from './SupportPane.jsx';
import PaneWrapper from './paneWrapper.jsx';
import OraclePane from './OraclePane.jsx';
import BeginningOracleComp from './BeginningOracleComp.jsx';
import ValidationPane from './ValidationPane.jsx';
import BeginningQAComp from './BeginningQAComp.jsx';
import DataPane from './DataPane.jsx';
import DarRequestPane from './DarRequestPane.jsx';
import DuplicateFilterPane from './DuplicateFilterPane.jsx';

class MainCont extends React.Component {
  constructor(props) {
    super(props);
    this.handleRequestClose = this.handleRequestClose.bind(this)
    this.choosePane = this.choosePane.bind(this)
    props.appView(HomeComp, 'HomeComp')

  }
  handleRequestClose() {
    this.props.hideSaveNotice()
  }
  choosePane() {
    if (this.props.appState.paneArray.length > 0) {
      switch (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].paneName) {
        case'DuplicateFilterPane':
        return(
          <PaneWrapper>
          <DuplicateFilterPane/>
          </PaneWrapper>
        )
        case'BeginningOracleComp':
          return(
            <PaneWrapper>
            <BeginningOracleComp/>
            </PaneWrapper>
          )
        case'BeginningQAComp':
          return(
            <PaneWrapper>
            <BeginningQAComp/>
            </PaneWrapper>
          )
        case 'DarRequestPane':
          return (
            <PaneWrapper>
            <DarRequestPane/>
            </PaneWrapper>
          )
        case'DataPane':
          return(
            <PaneWrapper>
            <DataPane/>
            </PaneWrapper>
          )
        case'OraclePane':
          return(
            <PaneWrapper>
            <OraclePane/>
            </PaneWrapper>
          )
        case 'RightPane':
          return (
            <PaneWrapper>
              <RightPane />
            </PaneWrapper>)
        case 'LeftPane':
          return (
            <PaneWrapper>
              <LeftPane />
            </PaneWrapper>)
        case 'HelpPane':
          return (
            <PaneWrapper>
              <HelpPane />
            </PaneWrapper>)
        case 'SupportPane':
          return (
            <PaneWrapper>
              <SupportPane />
            </PaneWrapper>)
              case 'SQLGeneratorPane':
          return (
            <PaneWrapper>
              <SQLGeneratorPane />
            </PaneWrapper>)
        case 'HomeComp':
          return (
            <PaneWrapper>
              <HomeComp />
            </PaneWrapper>
          )
        case 'MetricsPane':
          return (
            <PaneWrapper>
              <MetricsPane />
            </PaneWrapper>)
        case 'DartPane':
          return (
            <PaneWrapper>
              <DartPane />
            </PaneWrapper>
          )
        case 'SettingsPane':
          return (
            <PaneWrapper>
              <SettingsPane />
            </PaneWrapper>)
        case 'ValidationPane':
            return (
              <PaneWrapper>
                <ValidationPane />
              </PaneWrapper>)
        default:
          return (null)
      }
    }
    else {
      return (null)
    }
  }

  render() {
    return (
      <div>
        {this.choosePane()}
      </div>
    )
  }
}


const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  addToColumnList,
  alterColumnName,
  alterVersion,
  removeFromColumnList,
  goToColumn,
  hideSaveNotice,
  appView
};

const MainContContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(MainCont);

export default MainContContainer