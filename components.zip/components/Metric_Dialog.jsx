import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import Checkbox from 'material-ui/Checkbox';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToMetricsList } from '../redux/actions/metricActions.jsx'
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, closeDialog, openDialog, metricClose, disablePage, saved, storeWarningModal2} from '../redux/actions/appActions.jsx';

var ipcRenderer = electron.ipcRenderer;
class MetricBox extends React.Component {

    constructor(props) {
        super(props);
        this.state = { textValue: '' }
        this.state = { open: true };
        this.createColumn = this.createColumn.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.onKeyPress = this.onKeyPress.bind(this);
    }
    //when cancel is selected on the dialog box, handleClose will close the Dialog box and set the local state open to false
    handleClose = () => {
        this.props.metricClose();
        this.setState({ open: false });
    };
    createColumn = () => {
        this.props.metricClose();
        this.props.disablePage();
        this.props.saved();
        ipcRenderer.send('metricsFiles', this.props.appState.currentSetting.savePath);
    }
    updateWarningModal2 = (event, newValue) => {
        this.props.storeWarningModal2(newValue === undefined ? true : newValue);
  }
    //if enter is pressed it will preform the same action as the submit button
    onKeyPress(event) {
        if (event.charCode === 13) {
            //on keyboard press of enter (enter's charcode value is 13)
            event.preventDefault();
            if (this.state.textValue) {
                //his.props.addToColumnList(this.state.textValue);
                this.props.closeDialog();
                // this.setState({ textValue: null });
            }
        }
    }

    render() {
        //Submit button. Should be unselectable if nothing is entered in the text box. User should be able to press enter as well
        const actions = [
            <RaisedButton
                label="Submit"
                backgroundColor = '#147aff'
                labelColor='#FFFFFF'
                keyboardFocused={true}
                onTouchTap={this.createColumn}/>,
            //cancel button. User should be able to select at all times. No column should be created and the dialog box should close if selected
            <RaisedButton
                label="Cancel"
                backgroundColor='#ff1e1e'
                labelColor='#FFFFFF'
                onTouchTap={this.handleClose} />,
        ];
        //focusInputField will make sure theat the Dialog text box will already be selected. (The user wont have to click into the text field, should be able to type as soon as the dialog box opens)
        const focusInputField = input => {
            if (input) {
                setTimeout(() => { input.focus() }, 100);
            }
        };
        return (
            <div>
                <Dialog
                    /*The dialog box*/
                    ref='dia'
                    title="Add Metrics"
                    actions={actions}
                    modal={false}
                    open={this.props.appState.metricDialog}
                    onRequestClose={this.handleClose}>

                    You cannot use encrypted documents, please make sure to not use encrypted documents.
                        <br />
                    <Checkbox
                        label='Do not show again'
                        checked={this.props.appState.currentSetting.disableWarning2}
                        onCheck={this.updateWarningModal2.bind(this)}
                    />
                </Dialog>
            </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    openDialog,
    closeDialog,
    addToColumnList,
    addToMetricsList,
    metricClose,
    disablePage,
    saved,
    storeWarningModal2
};

const MetricBoxContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)
    (MetricBox);

export default MetricBoxContainer;