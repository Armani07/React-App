import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import { connect } from 'react-redux'
import electron from 'electron';
import LeftPane from './LeftPane.jsx';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList, newTableName } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, closeDialogNewFile, openErrorModal, appView, openDialogNewFile, getTrelloKey, chooseCards, getBoards, getLists, getCards, cardDropDownRefreshed, getMove, moveCard, clearCard, falseTrelloRefresh } from '../redux/actions/appActions.jsx';
import Trello from 'node-trello';
import Refresh from 'material-ui-icons/Refresh';
const logger = require('../../logger.js');
const winston = require('winston');
var ipcRenderer = electron.ipcRenderer;
var t;
class DialogBoxNewFile extends React.Component {
  constructor(props) {
    super(props);
    this.state = { errorTrello: false, errorTrelloMove: false, textValue: '', list: [], lists: [], cards: [], boards: false, tList: false, tCards: false, moveList: false, boardSelectedId: '' }
    this.onKeyPress = this.onKeyPress.bind(this);
    this.onTextChange = this.onTextChange.bind(this);
    ipcRenderer.on('trelloSend', function (event, arg) {
      props.getTrelloKey(arg);
      t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", arg);
    });
    this.refreshTrello()
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.appState.trelloRefresh) {
      nextProps.falseTrelloRefresh();
      this.refreshTrello()
    }
  }
  handleOpen = () => {
    // logger.log('Info','Modal Opened')
    this.props.openDialogNewFile();
  };
  handleClose = () => {
    this.props.closeDialogNewFile();
  };
  handleNewName = (event, index, id) => {
    if (this.state.trello && !this.state.errorTrelloMove && this.state.cardId != 'blank') {
      this.moveTrelloCard(this.state.cardId);
    }
    var pane = this.props.appState.paneArray[this.props.appState.paneArray.length - 1]
    if (pane.paneName === 'HomeComp') {
      this.props.appView(LeftPane, 'LeftPane')
    }
    this.props.newTableName((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);
    this.props.clearCard(this.props.appState.card ? this.props.appState.card.props.value : null);
    this.state.textValue = '';
    this.handleClose();
  }
  handleTrelloLogin() {
    ipcRenderer.send('trelloLogin')
  }
  makeCardDropDown(arg) {

    // logger.log('Info', 'Trello Stuff')
    if(this.props.appState.token && this.props.appState.currentSetting.board != 'blank') {
    t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", this.props.appState.token);
    t.get('/1/list/' + arg + '/cards', (err, meta) => {
      if (err) { 
        this.setState({errorTrello: true})
        this.props.openErrorModal("Trello ID Error Dialog_New_File: makeCardDropDown")
        throw err
      }
      var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
      for (var i = 0; i < meta.length; i++) {
        testArr.push(<MenuItem key={meta[i].id} value={meta[i].id} primaryText={meta[i].name} />)
      }
      this.props.cardDropDownRefreshed()
      this.setState({ cards: testArr, })
      return testArr;
    });
    } else {
      var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
      this.setState({ cards: testArr, })
    }
  }
  moveTrelloCard(arg) {
    t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", this.props.appState.token);
    var userID = "";
    t.get('/1/members/me', (err, meta) => {
       if (err) { 
        this.setState({errorTrelloMove: true})
        this.props.openErrorModal("Trello ID Error Dialog_New_File:moveTrelloCard-get members")
        throw err
      }
      userID = meta.id;
      t.get('/1/cards/' + arg + '/members', (erro, nmeta) => {
        if (err){
          this.setState({errorTrelloMove: true})
        this.props.openErrorModal("Trello ID Error Dialog_New_File: moveTrelloCard-get cards")
        throw err
        } 
        for (var x in nmeta) {
          userID = userID + "," + nmeta[x].id
        }
        t.put('/1/cards/' + arg + '?idList=' + this.props.appState.currentSetting.move + '&pos=top&idMembers=' + userID, (err) => {
          if (err) { 
            this.setState({errorTrelloMove: true})
        this.props.openErrorModal("Trello ID Error Dialog_New_File:moveTrelloCard-move cards")
        throw err}
        });
      })
    })
  }
  handleCards(event, index, id) {
    this.props.chooseCards(this.state.cards[index])
    this.setState({ textValue: this.state.cards[index].props.primaryText, trello: true, cardId: this.state.cards[index].props.value });
  }
  handleMove(event, index, id, newValue) {
    this.props.moveCard(id)
  };
  onTextChange = (event, newValue) => {
    this.setState({ textValue: newValue, trello: false });
  };
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue })
  }
  refreshTrello() {
    if (this.props.appState.token && !this.state.errorTrello)
      this.makeCardDropDown(this.props.appState.currentSetting.list)
  }
  onKeyPress(event) {
    if (event.charCode === 13) {
      event.preventDefault();
      if (this.state.textValue) {
        var pane = this.props.appState.paneArray[this.props.appState.paneArray.length - 1]
        if (pane.paneName === 'HomeComp') {
          this.props.appView(LeftPane, 'LeftPane')
        }
        this.props.newTableName((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);
        this.handleClose();
        this.setState({ textValue: '' });
      }
    }
  }
  render() {

    const actions = [
      <RaisedButton

        id='submit'
        backgroundColor ='#147aff'
        label="Submit"
        labelColor='#FFFFFF'
        keyboardFocused={true}
        onTouchTap={this.handleNewName}
        disabled={(this.state.textValue.length > 0) ? false : true}
        onKeyPress={this.onKeyPress}
      />,
      <RaisedButton
      backgroundColor ='#ff1e1e'
      label="Cancel"
      labelColor= 'FFFFFF'
      onTouchTap={this.handleClose}
      />,
    ];

    const focusInputField = input => {
      if (input) {
        setTimeout(() => { input.focus() }, 100);
      }
    };
    if (this.props.appState.token === '' || this.props.appState.token === null) {
      return (
        <div>
          <Dialog
            ref='dialog'
            title="New Table Name"
            actions={actions}
            modal={false}
            open={this.props.appState.newFileDialog}
            onRequestClose={this.handleClose}
          >
            WARNING: All work not saved will be lost. <br />
            Are you sure you want to create a new table? <br />
            Enter the name of the new table:
          <div>
              <TextField
                ref={focusInputField}
                onChange={this.onTextChange}
                name="Table Name"
                type="con"
                hintText="Max Characters: 30"
                multiLine={true}
                maxLength="30"
                onKeyPress={this.onKeyPress}
              />
            </div>
            <br />
            <RaisedButton
              id='trelloLogin1'
              backgroundColor="#147aff"
              label='Trello Login'
              labelColor='#FFFFFF'
              onTouchTap={this.handleTrelloLogin.bind(this)} />
          </Dialog>
        </div>
      );
    }
    else {
      return (
        <FlatButton
          label="Submit"
          primary={true}
          keyboardFocused={true}
          onTouchTap={this.handleNewName}
          disabled={(this.state.textValue.length > 0) ? false : true}
          onKeyPress={this.onKeyPress}
        /> ,
        <FlatButton
          label="Cancel"
          primary={true}
          onTouchTap={this.handleClose}
        /> ,
        <div>
          <Dialog
            ref='dialog'
            title="New Table Name"
            actions={actions}
            modal={false}
            open={this.props.appState.newFileDialog}
            onRequestClose={this.handleClose}
          >
            WARNING: All work not saved will be lost. <br />
            Are you sure you want to create a new table? <br />
            Enter the name of the new table:
          <TextField
              ref={focusInputField}
              onChange={this.onTextChange}
              name="Table Name"
              type="con"
              hintText="Max Characters: 30"
              multiLine={true}
              maxLength="30"
              onKeyPress={this.onKeyPress}
            />
            <SelectField id='selectTrelloCards'
              floatingLabelText='Trello Cards'
              value={this.props.appState.card ? this.props.appState.card.props.value : "blank"}
              onChange={this.handleCards.bind(this)}>
              {this.state.cards}
            </SelectField>
            <br />
            <div
              id='trelloRefresh'>
              <RaisedButton
                className='refresh'
                onTouchTap={this.refreshTrello.bind(this)}>
                <Refresh className='refreshList' />
              </RaisedButton>
            </div>
          </Dialog>
        </div>
      );
    }
  }
}
const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});
const mapDispatchToProps = {
  appView,
  getTrelloKey,
  openDialogNewFile,
  closeDialogNewFile,
  newTableName,
  chooseCards,
  cardDropDownRefreshed,
  moveCard,
  clearCard,
  falseTrelloRefresh,
  openErrorModal
};
const DialogBoxNewFileContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (DialogBoxNewFile);
export default DialogBoxNewFileContainer;