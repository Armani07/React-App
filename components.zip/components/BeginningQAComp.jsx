import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';

var ipcRenderer = electron.ipcRenderer;
class BeginningQAComp extends React.Component {

    constructor(props) {
        super(props);
    }
    static paneProps() {
        return {
            newTableDisabled: false,
            openDisabled: false,
            dartDisabled: false,
            sqlDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
        }
    }
    static clickBack(props) {
        return (null)
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        props.openDialogNewApp();
    }
    static clickOpen(props) {
        props.disablePage();
        props.saved();
        ipcRenderer.send('qaOpen', props.appState.currentSetting.savePath);
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    render() { return (<div id='wrapper3'>
                      <ul className='list'>                 
                        <h2>Validation Pane</h2>        
                    </ul>
                    </div>) }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    
};

const BeginningQACompContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)
    (BeginningQAComp);

export default BeginningQACompContainer;