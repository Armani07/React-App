import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import { connect } from 'react-redux'
import RaisedButton from 'material-ui/RaisedButton';
import { popPane } from '../redux/actions/appActions.jsx';
import { closeSettingsPrompt, workspaceType, overwriteNewSettings, goBack, goBackNoSave, snackBarMessage } from '../redux/actions/appActions.jsx';

export class SettingsPrompt extends React.Component {
  constructor(props) {
    super(props);
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
    this.paneName = this.paneName.bind(this);
  }
  state = {
    open: false,
  };
  paneName(workTypes) {
    switch (workTypes) {
      case 'HomeComp':
        return HomeComp;
      case 'BeginningOracleComp':
        return BeginningOracleComp;
      case 'BeginningQAComp':
        return BeginningQAComp;
      default:
        return HomeComp
    }
  };
  handleYes = () => {
    if (this.props.appState.newSetting.workspace.paneName != this.props.appState.currentSetting.workspace.paneName) {
      if (this.props.appState.newSetting.workspace.pane != null) {
        this.props.workspaceType(this.props.appState.newSetting.workspace)
      }
      else {
        this.props.workspaceType(this.props.appState.newSetting.workspace, this.paneName(this.props.appState.newSetting.workspace.paneName))
      }
    }
    this.props.overwriteNewSettings();
    this.props.closeSettingsPrompt();
    this.props.popPane()
    this.props.snackBarMessage('Settings Saved')
  };
  handleNo = () => {
    this.props.closeSettingsPrompt();
    this.props.popPane()
  }
  handleClose = () => {
    this.props.closeSettingsPrompt()
  };

  render() {
    const actions = [
   <div id='settingsNotSaveYes'>
      <RaisedButton
        backgroundColor = '#147aff'
        label="Yes"
        labelColor = '#FFFFFF'
        keyboardFocused={true}
        onClick={this.handleYes.bind(this)}
      />
   </div>, 
   <div id='settingsNotSaveNo'>
      <RaisedButton
        backgroundColor = '#ff1e1e'
        label='No'
        labelColor = '#FFFFFF'
        keyboardFocused={false}
        onClick={this.handleNo}
      />
   </div>,
   <div id='settingsNotSaveCancel'>
      <RaisedButton
        backgroundColor ='#ff1e1e'
        label="Cancel"
        labelColor = '#FFFFFF'
        onClick={this.handleClose}
      />
   </div>,
    ];

    return (
      <div>
        <Dialog
          title="Settings Not Saved"
          actions={actions}
          modal={false}
          open={this.props.appState.settingsDialog}
          onRequestClose={this.handleClose}
        >
          Do you wish to save all changes?
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  closeSettingsPrompt,
  overwriteNewSettings,
  goBack,
  goBackNoSave,
  popPane,
  snackBarMessage,
  workspaceType
};

const SettingsPromptContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (SettingsPrompt);

export default SettingsPromptContainer;