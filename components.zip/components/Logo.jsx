import React from 'react';
import { connect } from 'react-redux';
import { disablePage } from '../redux/actions/appActions.jsx';
import combinedReducers from '../redux/combinedReducers.jsx';

class Logo extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
   
    if (this.props.appState.token) {
      return (

        <div className='logo' style={{
          position: 'fixed',
          top: '0',
          right: '0'
          
        }}>
        <img src= "./trello-mark-blue.png" height="50" width="50"/></div>       
      );
    }
    else{
      return(
        <div>
          </div>
      )
    }
  }
}

const mapStateToProps = (state, ownProps) => ({
  appState: state.appState
});

const mapDispatchToProps = {};

const LogoContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(Logo);

export default LogoContainer;