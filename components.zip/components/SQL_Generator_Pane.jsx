import React from 'react';
import { connect } from 'react-redux';
import electron from 'electron';
import RaisedButton from 'material-ui/RaisedButton';
import { openDartPane } from '../redux/actions/appActions.jsx'
import { List, ListItem } from 'material-ui/List';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import Save from 'material-ui-icons/Save';
import Checkbox from 'material-ui/Checkbox';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
import TextField from 'material-ui/TextField';
import { goToColumn, goBack, closeDialogNewFile, storeCUID, storeMirrorId, storeDatabaseName, appView, newTrelloCard, openDialogNewFile, getTrelloKey, chooseCards, getBoards, getLists, getCards, getMove, getMakeCard, cardDropDownRefreshed, moveCard, makeCard, storeSupportType, snackBarTrello, popPane, openSQLGeneratorPane, storeStatementText, copyDialog } from '../redux/actions/appActions.jsx';
import MenuItem from 'material-ui/MenuItem';
import SelectField from 'material-ui/SelectField';
import HelpPane from './HelpPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import DarRequestPane from './DarRequestPane.jsx';
var ipcRenderer = electron.ipcRenderer;
const styles = {
    block: {
        maxWidth: 500,
        paddingTop: '10px'
    },
    checkbox: {
        marginBottom: 16,
        textAlign: 'left'
    },
    customWidth: {
        width: 150,
    },
};
export class SQLGeneratorPane extends React.Component {
    constructor(props) {
        super(props);
        this.state = { textValue1: '', columnsSelected: false, distinctSelected: false, textValue2: '', textValue3: '', textValue4: '', textValue5: '' }
        this.handleRequest = this.handleRequest.bind(this);
        this.handleTextChange1 = this.handleTextChange1.bind(this);
        this.handleTextChange2 = this.handleTextChange2.bind(this);
        this.handleTextChange3 = this.handleTextChange3.bind(this);
        this.handleTextChange4 = this.handleTextChange4.bind(this);
    }
    handleRequest() {
        this.props.appView(SQLGeneratorPane, "SQLGeneratorPane")
    };
    handleTextChange1(event, newValue) {
        this.setState({ textValue1: newValue, });
        this.setState({ errorValue1: '' }) //Erase Required Field
    }
    handleTextChange2(event, newValue) {
        this.setState({ textValue2: newValue, });
        this.setState({ errorValue2: '' }) //Erase Required Field
    }
    handleTextChange3(event, newValue) {
        this.setState({ textValue3: newValue, });
        this.setState({ errorValue3: '' }) //Erase Required Field
    }
    handleTextChange4(event, newValue) {
        this.setState({ textValue4: newValue, });
    }
    handleGenerate = (event, index, id) => {
        var text1 = ''
        var text2 = ''
        var text3 = ''
        var text4 = ''
        //checks to make sure textboxes are filled in, and send errors if they are not
        if (this.state.textValue1 === '' && this.state.columnsSelected === false) {
            this.setState({ errorValue1: 'Required Field' })
        }
        if (this.state.textValue2 === '') {
            this.setState({ errorValue2: 'Required Field' })
        }
        if (this.state.textValue3 === '') {
            this.setState({ errorValue3: 'Required Field' })
        }
        /*these statements take the infromation that is input into the pane and formats them so
        they can be added into the display*/
        if (this.state.columnsSelected === false && this.state.textValue1 !== '') {
            text1 = this.state.textValue1 + " from "
        }
        else if (this.state.columnsSelected === true) {
            text1 = "* from "
        }
        if (this.state.distinctSelected === true) {
            text2 = "Distinct "
        }
        if (this.state.textValue2 && this.state.textValue3) {
            text3 = this.state.textValue2 + "." + this.state.textValue3
        }
        if (this.state.textValue4) {
            text4 = " Where " + this.state.textValue4
        }
        if ((this.state.textValue1 || this.state.columnsSelected) && this.state.textValue2 && this.state.textValue3) {
            var finalText = ("Select " + text2 + text1 + text3 + text4 + ";")
            this.setState({ textValue5: finalText })
            ipcRenderer.send('copyToClipboard', finalText, 'Procedure copied to clipboard');
        }
    }
    handleColumnsSelected() {
        if (this.state.columnsSelected) {
            this.setState({ columnsSelected: false })
        }
        else if (!this.state.columnsSelected) {
            this.setState({ columnsSelected: true })
        }
    }
    handleDistinctSelected() {
        if (this.state.distinctSelected) {
            this.setState({ distinctSelected: false })
        }
        else if (!this.state.distinctSelected) {
            this.setState({ distinctSelected: true })
        }
    }
    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    static clickSQL(props) {
        return (null)
    }
    render() {
        return (
            <div>
                <ul className='list'>
                    <li>
                        <h2>SQL Generator</h2>
                    </li>
                    <li>
                        <div >
                            <Checkbox id='selectSQL'
                                label="Select all columns"
                                labelPosition='left'
                                style={styles.checkbox}
                                checked={this.state.columnsSelected}
                                onCheck={this.handleColumnsSelected.bind(this)}
                            />
                        </div>
                    </li>
                    <li>
                        <div >
                            <Checkbox id='distinct'
                                label="Select distinct"
                                labelPosition='left'
                                style={styles.checkbox}
                                checked={this.state.distinctSelected}
                                onCheck={this.handleDistinctSelected.bind(this)}
                            />
                        </div>
                    </li>
                    <li >
                        <TextField id='txtColumnName'
                            floatingLabelText={this.state.columnsSelected ? '' : "Column Name"}
                            disabled={this.state.columnsSelected ? true : false}
                            onChange={this.handleTextChange1.bind(this)}
                            value={this.state.textValue1}
                            errorText={this.state.errorValue1}
                            fullWidth={true} >
                        </TextField>
                    </li>
                    <li >
                        <TextField id='txtOwner'
                            floatingLabelText="Owner"
                            onChange={this.handleTextChange2.bind(this)}
                            value={this.state.textValue2}
                            errorText={this.state.errorValue2}
                            fullWidth={true} >
                        </TextField>
                    </li>
                    <li >
                        <TextField id='txtNameOfTable'
                            floatingLabelText="Table Name"
                            onChange={this.handleTextChange3.bind(this)}
                            value={this.state.textValue3}
                            errorText={this.state.errorValue3}
                            fullWidth={true} >
                        </TextField>
                    </li>
                    <li >
                        <TextField id='txtWhereStatement'
                            floatingLabelText="Where Statement"
                            onChange={this.handleTextChange4.bind(this)}
                            value={this.state.textValue4}
                            fullWidth={true} >
                        </TextField>
                    </li>
                    <br />
                    <li>
                        <RaisedButton
                            id='SQLGenerate'
                            label='Generate'
                            backgroundColor="#147aff"
                            labelColor='#FFFFFF'
                            onTouchTap={this.handleGenerate.bind(this)}
                        />
                    </li>
                    <br />
                    <li><h2>Procedure</h2></li>
                    <li >
                        <TextField id='procedureTxt'
                            value={this.state.textValue5}
                            multiLine={true}
                            fullWidth={true}
                            rows={5}
                            rowsMax={10}>
                        </TextField>
                    </li>
                </ul>
            </div>
        )
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});
const mapDispatchToProps = {
    openSQLGeneratorPane,
    openDartPane,
    openDialogNewFile,
    closeDialogNewFile,
    storeSupportType,
    popPane,
    appView,
    storeDatabaseName,
    storeCUID,
    storeMirrorId,
    storeStatementText,
    copyDialog
}
const SQLGeneratorPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(SQLGeneratorPane);
export default SQLGeneratorPaneContainer;