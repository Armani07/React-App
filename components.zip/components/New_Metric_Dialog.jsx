import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import Checkbox from 'material-ui/Checkbox';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToMetricsList } from '../redux/actions/metricActions.jsx'
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, closeDialog, openDialog, disablePage, saved, storeWarningModal2, openNewMetricDialog, closeNewMetricDialog } from '../redux/actions/appActions.jsx';

var ipcRenderer = electron.ipcRenderer;
class NewMetricDialog extends React.Component {

    constructor(props) {
        super(props);
        this.state = { textValue: '' }
        this.state = { open: true };
        this.handleOpen = this.handleOpen.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.onKeyPress = this.onKeyPress.bind(this);
    }
    //when cancel is selected on the dialog box, handleClose will close the Dialog box and set the local state open to false

    handleOpen = () => {
        this.props.openNewMetricDialog();
    };
    handleClose = () => {
        this.props.closeNewMetricDialog();
        this.setState({ open: false });
    };

    //if enter is pressed it will preform the same action as the submit button
    onKeyPress(event) {
        if (event.charCode === 13) {
            //on keyboard press of enter (enter's charcode value is 13)
            event.preventDefault();
            if (this.state.textValue) {
                this.props.closeDialog();
            }
        }
    }
    render() {
        const actions = [
            //okay button closes modal
            <FlatButton
                label="OKAY"
                primary={true}
                onTouchTap={this.handleClose} />,
        ];
        //focusInputField will make sure theat the Dialog text box will already be selected. (The user wont have to click into the text field, should be able to type as soon as the dialog box opens)
        const focusInputField = input => {
            if (input) {
                setTimeout(() => { input.focus() }, 100);
            }
        };
        return (
            <div>
                <Dialog
                    /*The dialog box*/
                    ref='dia'
                    title="Add Metrics"
                    actions={actions}
                    modal={false}
                    open={(this.props.metricReducer.metricError === true) && (this.props.appState.newMetricDialog)}
                    onRequestClose={this.handleClose}
                    autoScrollBodyContent={true}>
                    The Following Files Have Already Been Added.
                   <br />
                    {this.props.metricReducer.duplicate}
                    <br />
                </Dialog>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    openDialog,
    closeDialog,
    addToColumnList,
    addToMetricsList,
    openNewMetricDialog,
    closeNewMetricDialog,
    disablePage,
    saved,
    storeWarningModal2
};

const NewMetricDialogContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)
    (NewMetricDialog);

export default NewMetricDialogContainer;