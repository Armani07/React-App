import React from 'react';
import MenuComp from './MenuComp.jsx';
import MainCont from './MainContent.jsx';
import Logo from'./Logo.jsx';
import Support from './SupportButton.jsx'
import DisableComp from './DisableComp.jsx';
import logger from '../../logger.js';


export default class DemoComp extends React.Component {

  render() {
    return (
      //<div style='position:fixed;bottom:0;left:0;background:lightgray;width:100%;'></div>
      <div>
        <DisableComp />
        <Logo/>
        <Support/>
        <MenuComp />
        <MainCont />
      </div>
    );
  }
}