import React from 'react';
import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import electron from 'electron';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import LeftPane from './LeftPane.jsx';
import Save from 'material-ui-icons/Save';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import { grey400, grey900 } from 'material-ui/styles/colors';
import { connect } from 'react-redux';
import { addToColumnList, removeFromColumnList, alterColumnName, columnsLoad, alterVersion, saveColumn, columnHasUpdated } from '../redux/actions/columnActions.jsx'
import { goToColumn, openAddValidation, clearDar, openDialogNewApp, openSameFileDialog, popSettingPane, loadWorkSpace, closeSameFileDialog, getTrelloKey, popPane, addOracleDialogOpen, changeCompletedBack, goBack, goBackMetrics, goBackSupport, filesHaveUpdated, openErrorModal, saved, loadDefault, loadUser, openSettingsDialog, closeDialog, openDialog, updateRemoveList, goBackHelp, openRemoveDialog, openDialogNewFile, closeDialogSave, openDialogSave, openSettingsPane, openHelpPane,openSQLGeneratorPane, disablePage, overwriteNewSettings, settingsLoad, goBackNoSave, closeDialogColumn, openDialogColumn, snackBarMessage, openMetricsPane, metricDialog, openNewMetricDialog, closeNewMetricDialog, appView, propsRefreshed, trelloRefresh, snackBarTrello, openDialogNewOracle, openRemoveOracleDialog, openRemoveQADialog } from '../redux/actions/appActions.jsx';
import { metricsReset, addToMetricsList } from '../redux/actions/metricActions.jsx';
import { oracleLoad } from '../redux/actions/oracleActions.jsx';
import { qaLoad, saveQa } from '../redux/actions/qaActions.jsx';
import combinedReducers from '../redux/combinedReducers.jsx';
import SettingsPromptContainer from './Dialog_settings_Prompt.jsx';
import DialogBoxContainer from './Dialog_Multi.jsx';
import RemoveDialogBoxContainer from './RemoveDialog.jsx';
import RemoveOracleDialogBoxContainer from './RemoveOracleDialog.jsx';
import DialogBoxNewFileContainer from './Dialog_New_File.jsx';
import SameFileDialogContainer from './Same_File_Dialog.jsx';
import CopyOracleDialogContainer from './CopyOracleDialog.jsx';
import DialogBoxColumnContainer from './Dialog_Column.jsx';
import DialogSaveContainer from './Dialog_Save.jsx';
import BeginningOracleComp from './BeginningOracleComp.jsx';
import BeginningQAComp from './BeginningQAComp.jsx';
import DefaultSettingsContainer from './Dialog_Default_Settings.jsx';
import MetricBoxContainer from './Metric_Dialog.jsx';
import NewMetricDialogContainer from './New_Metric_Dialog.jsx';
import ErrorModalContainer from './ErrorModal.jsx';
import HelpPaneContainer from './HelpPane.jsx';
import DialogNewOracleContainer from './Dialog_New_Oracle.jsx';
import DialogNewAppContainer from './Dialog_New_App.jsx';
import OracleAddDialogContainer from './OracleAddDialog.jsx';
import DialogAddValidationContainer from './Dialog_Add_Validation.jsx';
import RemoveQADialogBoxContainer from './RemoveQADialog.jsx';
import Popover from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import Help from 'material-ui-icons/Help';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Receipt from 'material-ui-icons/Receipt';
import NotInterested from 'material-ui-icons/NotInterested';
import FindInPage from 'material-ui-icons/FindInPage';
import RightPane from './RightPane.jsx';
import MetricsPane from './MetricsPane.jsx';
import DartPane from './DartPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';
import HomeComp from './HomeComp.jsx';
import OraclePane from './OraclePane.jsx';
import ValidationPane from './ValidationPane.jsx';
import SQLGeneratorPane from './SQL_Generator_Pane.jsx';

var ipcRenderer = electron.ipcRenderer;
class MenuComp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false, openPop: false, currentProps: {},
      defaultProps: {
        backDisabled: true, saveDisabled: true,
        openDisabled: true, helpDisabled: true, settingsDisabled: true, addDisabled: true,
        removeDisabled: true, mergeDisabled: true, newTableDisabled: true, dartDisabled: true, tbdDisabled: true, sqlDisabled:true,
      }
    };
    ipcRenderer.on('returnFileData', (event, arg, arg2, value) => {
      this.setState({ testProp: arg });
    });
    ipcRenderer.on("Error", function (event, arg, error) {
      props.saved();
      props.disablePage();
      props.openErrorModal(error);
      props.snackBarMessage(arg)
      //(arg === "Saving Error") ? props.snackBarMessage(arg) : true;
    });
    ipcRenderer.on('saved', function (event, arg) {
      props.saved();
      props.disablePage();
      (arg === "Table Saved") ? props.snackBarMessage(arg) : true;
    });
    ipcRenderer.send('initialSettings', this.props.appState.defaultSetting)
    ipcRenderer.on('writingUserSettings', function (event, arg) {
      props.loadUser(arg)
      if (arg.workspace.paneName === 'BeginningOracleComp') {
        props.loadWorkSpace({ pane: BeginningOracleComp, paneName: "BeginningOracleComp" })
        props.appView(BeginningOracleComp, 'BeginningOracleComp')
      }
      else if (arg.workspace.paneName === 'BeginningQAComp') {
        props.loadWorkSpace({ pane: BeginningQAComp, paneName: "BeginningQAComp" })
        props.appView(BeginningQAComp, 'BeginningQAComp')
      }
      else {
        props.appView(HomeComp, 'HomeComp')
        props.loadWorkSpace({ pane: HomeComp, paneName: "HomeComp" })
      }
    });
    ipcRenderer.on('trelloSend', function (event, arg) {
      props.getTrelloKey(arg);
    });
    ipcRenderer.on('copyMessage', function (event, arg) {
      props.snackBarMessage(arg);
    });
    ipcRenderer.on('OracleOpenReply', function (event, arg, arg2, arg3) {
      props.disablePage();
      props.saved();
      props.appView(OraclePane, 'OraclePane');
      props.oracleLoad(arg, arg2, arg3);
    });
    ipcRenderer.on('QAOpenReply', function (event, arg, arg2, arg3) {
      props.disablePage();
      props.saved();
      props.qaLoad(arg, arg2, arg3);
      props.appView(ValidationPane, 'ValidationPane');
    });
    ipcRenderer.on('synchronous-reply', function (event, arg, arg2, arg3) {
      props.disablePage();
      props.saved();
      props.columnsLoad(arg, arg2, arg3);
      props.appView(LeftPane, 'LeftPane');
    });
    ipcRenderer.on('mergeOpenFilesReturn', function (event, arg) {
      props.addToMetricsList(arg);
      props.openNewMetricDialog(arg);
    });
    ipcRenderer.on('existing file', function (event, arg) {
      props.saved();
      props.disablePage();
      props.openSameFileDialog(arg);
    });
  }
  clickBack() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickBack(this.props);
  }
  openADialog() {
    ipcRenderer.send('sync', this.props.columnReducer.columnList, this.props.columnReducer.tableName);
  }
  clickAdd() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickAdd(this.props)
  }
  clickRemove() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickRemove(this.props);
  }
  clickAddNewFile() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickAddNewFile(this.props);
  }
  clickOpen() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickOpen(this.props);
  }
  clickSave() {
    this.setState({
      openPop: false,
    });
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickSave(this.props);
  }
  clickMerge() {
    this.props.appView(MetricsPane, 'MetricsPane');
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickMerge(this.props);
  }
  clickDart() {
    this.props.appView(DartPane, 'DartPane');
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickDart(this.props);
  }
  clickSettings() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickSettings(this.props);
    this.props.appView(SettingsPane, 'SettingsPane');
    this.props.settingsLoad();
  }
  clickHelp() {
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickHelp(this.props);
    this.props.appView(HelpPane, 'HelpPane');
  }
  clickTBD(){
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickTBD(this.props);
  }
  clickSQL(){
    console.log('HEREEE')
    this.props.appView(SQLGeneratorPane, 'SQLGeneratorPane')
    this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane.clickSQL(this.props);
  }
  handleTouchTapPop = (event) => {
    // This prevents ghost click.
    event.preventDefault();
    if (this.props.appState.paneArray[this.props.appState.paneArray.length - 1].pane === MetricsPane) {
      this.clickAdd();  //The metrics Pane Add
    }
    else {
      this.setState({
        openPop: true,
        anchorEl: event.currentTarget,
      });
    };
  }
  componentWillMount() {
  }
  componentWillReceiveProps(nextProps) {
    if(nextProps.appState.paneArray[nextProps.appState.paneArray.length - 1].pane.paneProps=== undefined){
    }
    else{
    var paneProp = nextProps.appState.paneArray[nextProps.appState.paneArray.length - 1].pane.paneProps(nextProps)
    if (nextProps.appState.refreshProps) {
      for (var key in this.state.defaultProps) {
        if (!paneProp.hasOwnProperty(key)) {
          paneProp[key] = this.state.defaultProps[key]
        }
      }
      this.setState({ currentProps: paneProp })
      nextProps.propsRefreshed()
    }
  }
}

  handleRequestClosePop = () => {
    this.setState({
      openPop: false,
    });
  };
  render() {
    return (
      <div>
        <Drawer open={true} width={60}>
          <MenuItem title="Go Back"
            disabled={this.state.currentProps.backDisabled}
            onTouchTap={this.clickBack.bind(this)}>
            <ArrowBack className='menu' color={(this.state.currentProps.backDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <div>
            <MenuItem title='Add Column(s)'
              disabled={this.state.currentProps.addDisabled}
              onTouchTap={this.clickAdd.bind(this)}>
              <Add className='menu' color={(this.state.currentProps.addDisabled === true) ? grey400 : grey900} />
            </MenuItem>
          </div>
          <MenuItem title='Remove Column(s)'
            disabled={this.state.currentProps.removeDisabled}
            onTouchTap={this.clickRemove.bind(this)}>
            <Remove className='menu' color={(this.state.currentProps.removeDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Create New Table'
            disabled={this.state.currentProps.newTableDisabled}
            onTouchTap={this.clickAddNewFile.bind(this)}>
            <InsertDriveFile className='menu' color={(this.state.currentProps.newTableDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Open Table'
            disabled={this.state.currentProps.openDisabled}
            onTouchTap={this.clickOpen.bind(this)}>
            <Folder className='menu' color={(this.state.currentProps.openDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Save Table'
            disabled={this.state.currentProps.saveDisabled}
            onTouchTap={this.clickSave.bind(this)}>
            <Save className='menu' color={(this.state.currentProps.saveDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Merge Metric Sheets'
            disabled={this.state.currentProps.mergeDisabled}
            onTouchTap={this.clickMerge.bind(this)}>
            <MergeType className='menu' color={(this.state.currentProps.mergeDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Open DART'
            disabled={this.state.currentProps.dartDisabled}
            onTouchTap={this.clickDart.bind(this)}>
            <Receipt className='menu' color={(this.state.currentProps.dartDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Open Duplicate Filter'
            disabled={this.state.currentProps.tbdDisabled}
            onTouchTap={this.clickTBD.bind(this)}>
            <NotInterested className='menu' color={(this.state.currentProps.tbdDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <MenuItem title='Open SQL Generator'
           disabled={this.state.currentProps.sqlDisabled}
            onTouchTap={this.clickSQL.bind(this)}>
            <FindInPage className='menu' color={(this.state.currentProps.sqlDisabled === true) ? grey400 : grey900} />
          </MenuItem>
          <div id='Test' className='helpMe'>
            <MenuItem title='Settings'
              disabled={this.state.currentProps.settingsDisabled}
              onTouchTap={this.clickSettings.bind(this)}>
              <Settings color={(this.state.currentProps.settingsDisabled === true) ? grey400 : grey900}
                className='menu'
              />
            </MenuItem>
            <MenuItem title='Help'
              disabled={this.state.currentProps.helpDisabled}
              className='helpMe'
              onTouchTap={this.clickHelp.bind(this)}>
              <Help color={(this.state.currentProps.helpDisabled === true) ? grey400 : grey900} className='menu' />
            </MenuItem>
          </div>
        </Drawer>
        <CopyOracleDialogContainer/>
        <DefaultSettingsContainer />
        <SettingsPromptContainer />
        <RemoveDialogBoxContainer />
        <DialogBoxColumnContainer />
        <DialogBoxNewFileContainer />
        <DialogSaveContainer />
        <DialogBoxContainer />
        <MetricBoxContainer />
        <NewMetricDialogContainer />
        <SameFileDialogContainer />
        <ErrorModalContainer />
        <DialogNewOracleContainer />
        <ErrorModalContainer />
        <OracleAddDialogContainer />
        <RemoveOracleDialogBoxContainer />
        <DialogNewAppContainer />
       <DialogAddValidationContainer/>
       <RemoveQADialogBoxContainer />
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer,
  oracleState: state.oracleState,
  qaState: state.qaState
});

const mapDispatchToProps = {
  openErrorModal,
  addToColumnList,
  alterColumnName,
  alterVersion,
  removeFromColumnList,
  goToColumn,
  oracleLoad,
  qaLoad,
  clearDar,
  goBack,
  openDialogNewApp,
  goBackMetrics,
  openSettingsDialog,
  openDialog,
  updateRemoveList,
  openRemoveDialog,
  openRemoveOracleDialog,
  saveColumn,
  openDialogNewFile,
  openDialogColumn,
  openDialogSave,
  openSettingsPane,
  openSQLGeneratorPane,
  openHelpPane,
  disablePage,
  columnsLoad,
  saved,
  overwriteNewSettings,
  loadDefault,
  loadUser,
  settingsLoad,
  goBackNoSave,
  goBackHelp,
  getTrelloKey,
  snackBarMessage,
  openMetricsPane,
  metricsReset,
  addToMetricsList,
  metricDialog,
  openNewMetricDialog,
  closeNewMetricDialog,
  goBackSupport,
  filesHaveUpdated,
  trelloRefresh,
  appView,
  saveQa,
  popPane,
  propsRefreshed,
  columnHasUpdated,
  changeCompletedBack,
  openSameFileDialog,
  closeSameFileDialog,
  openDialogNewOracle,
  addOracleDialogOpen,
  loadWorkSpace,
  openRemoveQADialog,
  popSettingPane,
  openAddValidation,
};

const MenuCompContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(MenuComp);

export default MenuCompContainer;