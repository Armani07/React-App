import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Checkbox from 'material-ui/Checkbox';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { disablePage, openDialogColumn, closeDialogColumn, removeOracleDialogOpen, addOracleDialogRemove } from '../redux/actions/appActions.jsx';
import { addToOracleList, } from '../redux/actions/oracleActions.jsx';
class OracleAddDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = { textValue: '' };
        this.state = { open: true };
        this.handleClose = this.handleClose.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.parse = this.parse.bind(this);
    }
    updateValue = (event, newValue) => {
        this.setState({ textValue: newValue });
    };
    handleOpen = () => {
        this.props.openDialogColumn();
    };
    handleClose = () => {
        this.props.addOracleDialogRemove();
        this.setState({ open: false });
    };
    handleClick = () => {
        if (this.state.textValue !== undefined) {
            this.parse(this.state.textValue);
        }
        this.props.addOracleDialogRemove();
    }
    parse = (text) => {
        var array = []
        var holdingArray = text.split('\n')
        var splitDataType = "";
        for (var k = 0; k !== holdingArray.length; k++) {
            splitDataType = holdingArray[k].split('\t')
            if (splitDataType.length <= 1)
                splitDataType = splitDataType[0].split(' ');
            if (splitDataType.length === 6) {
                this.props.addToOracleList({
                    tableName: splitDataType[0],
                    columnName: splitDataType[1],
                    dataType: splitDataType[2],
                    objectType: splitDataType[3],
                    status: splitDataType[4],
                    compliant: splitDataType[5],
                    id: 0
                })
            }
            else if (splitDataType.length === 7) {
                this.props.addToOracleList({
                    tableName: splitDataType[0],
                    columnName: splitDataType[1],
                    dataType: splitDataType[2],
                    objectType: splitDataType[3],
                    status: splitDataType[4],
                    compliant: splitDataType[5],
                    loadDate: splitDataType[6],
                    id: 0
                })
            }
        }
    }
    render() {
        const actions = [
            <RaisedButton
                id="create"
                backgroundColor = '#147aff'
                label="Submit"
                labelColor='#FFFFFF'
                keyboardFocused={true}
                onTouchTap={this.handleClick}
            />,
            <RaisedButton
                backgroundColor='#ff1e1e'
                label="Cancel"
                labelColor='#FFFFFF'
                keyboardFocused={false}
                onTouchTap={this.handleClose}
            />
        ]
        const focusInputField = input => {
            if (input) {
                setTimeout(() => { input.focus() }, 100);
            }
        };
        return (
            <div id = 'oracleAddDialog'>
                 <div className="dialog"></div>
                <Dialog
                    id='colName'
                    ref='dia'
                    title="Insert Columns"
                    actions={actions}
                    modal={true}                  
                    open={this.props.appState.oracleDialogOpen}
                    onRequestClose={this.handleClose}>
                    You must fill in the field before continuing<br />
                    <TextField                  
                        ref={focusInputField}
                        onKeyPress={this.onKeyPress}
                        name="Information"
                        rowsMax={1}
                        fullWidth={true}
                        type="con"
                        hintText="List of Information"
                        onChange={this.updateValue}
                        multiLine={true} />
                </Dialog>
            </div >
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer,
    oracleState: state.oracleState
});
const mapDispatchToProps = {
    openDialogColumn,
    closeDialogColumn,
    disablePage,
    removeOracleDialogOpen,
    addToOracleList,
    addOracleDialogRemove
};
const OracleAddDialogContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)
    (OracleAddDialog);
export default OracleAddDialogContainer;
