import React from 'react';
import { connect } from 'react-redux';
import electron from 'electron';
import DataTables from 'material-ui-datatables';
import { appView } from '../redux/actions/appActions.jsx';
import { metricsReset, metricHasUpdated, updateMetricRemoveList } from '../redux/actions/metricActions.jsx';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';
var ipcRenderer = electron.ipcRenderer;
const TABLE_COLUMNS = [
    {
        key: 'metricName',
        label: 'Metrics'
    }
];

export class MetricsPane extends React.Component {
    constructor(props) {
        super(props);
        this.state = { page: 1, rowSize: this.props.appState.currentSetting.perPageSetting, rowSizeList: [10, 25, 50, 100, 200] };
    }
    static paneProps(props) {
        return {
            backDisabled: false,
            addDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
            removeDisabled: false,
            saveDisabled: false
        }
    }
    static clickBack(props) {
        props.popPane();
        props.metricsReset();
    }
    static clickAdd(props) {
        if ((!props.appState.currentSetting.disableWarning2)) {
            props.metricDialog();
        } 
        else {
            ipcRenderer.send('metricsFiles', props.appState.currentSetting.savePath);
            props.disablePage();
            props.saved();
        }
    }
    static clickRemove(props) {
        if (props.metricReducer.metricsRemoveList.length >= 1) {
            props.openRemoveDialog() //Here is the metrics Remove function, will change when Backend is finished
        }
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        ipcRenderer.send('saveMetrics', props.metricReducer.metricsList, props.appState.currentSetting.savePath)
        props.disablePage();
        props.saved();
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    handleSelectedEvents(event) {
        var removeMetrics = [];
        var metricList = this.props.metricReducer.metricsList;
        event.forEach(function (item, index) {
            removeMetrics.push(metricList[item]);
        })
        this.props.updateMetricRemoveList(event, removeMetrics)
    }
    render() {
        return (
            <div>
                <h3>Metrics Merge</h3>
                <DataTables
                    title={'Metric Sheets'}
                    height={'auto'}
                    selectable={true}
                    multiSelectable={true}
                    showRowHover={true}
                    columns={TABLE_COLUMNS}
                    data={this.props.metricReducer.metricsList}
                    showCheckboxes={true}
                    page={1}
                    count={this.props.metricReducer.metricsList.length}
                    stripedRows={this.props.appState.currentSetting.stripedColUser}
                    showHeaderToolbar={true}
                    selectedRows={this.props.metricReducer.metricsRemoveList}
                    onRowSelection={this.handleSelectedEvents.bind(this)}
                />
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    metricsReset,
    metricHasUpdated,
    updateMetricRemoveList,
    appView
};

const MetricsPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(MetricsPane);

export default MetricsPaneContainer;