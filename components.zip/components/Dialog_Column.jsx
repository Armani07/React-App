import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Checkbox from 'material-ui/Checkbox';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import {disablePage, openDialogColumn, closeDialogColumn } from '../redux/actions/appActions.jsx';
class DialogColumn extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' };
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleOpen = () => {
    this.props.openDialogColumn();
  };

  handleClose = () => {
    this.props.closeDialogColumn();
    this.setState({ open: false });
  };

  handleClick = () => {
    this.props.closeDialogColumn();
    this.props.disablePage();
  }

  render() {

    const actions = [
      <FlatButton
        label="OKAY"
        primary={true}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />
    ]

    return (

      <div>
        <Dialog
          id='colName'
          ref='dia'
          title="Insert Columns"
          actions={actions}
          modal={true}
          open={this.props.appState.dialogColumn}
          onRequestClose={this.handleClose}>

          YOU MUST ADD COLUMNS INSIDE THE TABLE BEFORE SAVING. 
          <br />
        <br />
        
        </Dialog>
      </div>

    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openDialogColumn,
  closeDialogColumn,
  disablePage
};

const DialogColumnContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)
  (DialogColumn);

export default DialogColumnContainer;
  