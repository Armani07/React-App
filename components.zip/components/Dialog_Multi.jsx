
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, closeDialog, openDialog, currentColumn } from '../redux/actions/appActions.jsx';

class DialogBox extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.updateValue = this.updateValue.bind(this);
    this.createColumn = this.createColumn.bind(this);
    this.parse = this.parse.bind(this);
    this.onKeyPress = this.onKeyPress.bind(this);
  }
  //when cancel is selected on the multi dialog box, handleClose will close the multi Dialog box
  handleClose = () => {
    this.props.closeDialog();
    this.setState({ open: false });
  };
  //when the user enters anything into the multi dialog text box, updateValue will set the textValue as the newValue given
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };
  /*when a user presses the submit button on the dialog box, createColumn update the state with new columns */
  createColumn = () => {
    this.parse((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);(this.state.textValue)
    this.props.closeDialog();
  }
  //if enter is pressed it will preform the same action as the submit button
  onKeyPress(event) {
    if (event.charCode === 13) {
      //on keyboard press of enter (enter's charcode value is 13)
      event.preventDefault();
      if (this.state.textValue) {
        this.parse((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);(this.state.textValue)
        this.props.closeDialog();
        this.setState({textValue: null});
      }
    }
  }
  parse = (text) => {
    var track = 0
    var array = []
    var parenth = false
    var string = ''
    var disa = 0;
    var openLocation = 0
    var closeLocation = 0
    var splitDataType = "";
    var splitDataSize = "";
    var mode = 1;
    var count = 0;
    var modek = 3;
    for (var k = 0; k !== text.split('\n').length; k++) {
      for (var i = 0; i < text.split('\n')[k].length; i++) {
        count++;
        if (text.split('\n')[k][i] !== ' ' && text.split('\n')[k][i] !== '\t' && parenth === false) {
          string += text.split('\n')[k][i]
          if ((text.split('\n')[k].length === string.length) && mode === 1) {
            array.push(string)
            string = '';
            modek = 1;
          }
          if (text.split('\n')[k][i] === '(') {
            parenth = true;
          }
          if ((text.split('\n')[k].length === count) && mode === 2 && track == 1) {
            array.push(string)
            string = '';
            track = 0;
            count = 0;
            mode = 1;
            modek = 2;
          }
          if ((string === 'Yes' || string === 'No') && track === 2) {
            array.push(string)
            string = ''
            track = 0;
          }
        }
        else if (parenth === true) {
          if (text.split('\n')[k][i] === ')') {
            string += text.split('\n')[k][i]
            parenth = false;
            if ((text.split('\n')[k].length === count) && mode === 2 && track == 1) {
              array.push(string)
              string = '';
              track = 0;
              count = 0;
              mode = 1;
              modek = 2;
            }
          }
          else {
            string += text.split('\n')[k][i]
          }
        }
        else if (parenth === false) {
          if (text.split('\n')[k][i] === ' ' || text.split('\n')[k][i] === '\t') {
            if ((text.split('\n')[k][i] === ' ' || text.split('\n')[k][i] === '\t') && track === 0) {
              array.push(string)
              string = ''
              disa++;
              track++
              mode++;
            }
            else if ((text.split('\n')[k][i] === ' ' || text.split('\n')[k][i] === '\t') && track === 1) {
              track++
              array.push(string)
              disa++
              string = ''
              mode++
            }
          }
        }
      }
    }
    if (modek === 1) {
      for (i = 0; i + 1 <= array.length; i++) {
        if (mode === 1) {
          this.props.addToColumnList(array[i]);
        }
      }
    }
    else if (modek === 2) {
      for (i = 1; i <= array.length; i += 2) {
        var re = new RegExp(/[()]/);
        splitDataType = array[i].split(re)
        this.props.addToColumnList(array[i - 1], splitDataType, );
      }
    }
    else if (modek === 3) {
      for (i = 2; i <= array.length; i = i + 3) {
        var re = new RegExp(/[()]/);
        splitDataType = array[i - 1].split(re)
        this.props.addToColumnList(array[i - 2], splitDataType, (array[i] === 'Yes') ? true : false);
      }
    }
  }

  render() {
    const actions = [
      <RaisedButton
        id = "submit"
        backgroundColor = '#147aff'
        label="Submit"
        labelColor='#FFFFFF'
        keyboardFocused={true}
        onTouchTap={this.createColumn}
        disabled={!(this.state.textValue)}/>,

      <RaisedButton
        backgroundColor = '#ff1e1e'
        label="Cancel"
        labelColor='#FFFFFF'
        onTouchTap={this.handleClose}/>,
    ];

    const focusInputField = input => {
      if (input) {
        setTimeout(() => { input.focus() }, 100);
      }
    };

    return (
      <div>
        <Dialog
          ref='dia'
          title="New column name"
          actions={actions}
          modal={false}
          open={this.props.appState.addDialog}
          onRequestClose={this.handleClose}>

          Add or paste columns:
          <br />
          <TextField
            ref={focusInputField}
            onKeyPress={this.onKeyPress}
            name="Column Name"
            type="con"
            hintText="Column Name"
            onChange={this.updateValue}
            multiLine={true}/>
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openDialog,
  closeDialog,
  addToColumnList,
  goToColumn,
  goBack,
  currentColumn
};

const DialogBoxContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (DialogBox);

export default DialogBoxContainer;