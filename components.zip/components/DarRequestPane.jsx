import React from 'react';
import { connect } from 'react-redux';
import FlatButton from 'material-ui/FlatButton';
import electron from 'electron';
import ContentCopy from 'material-ui-icons/ContentCopy';
import RaisedButton from 'material-ui/RaisedButton';
import { openRequestPane } from '../redux/actions/appActions.jsx'
import { List, ListItem } from 'material-ui/List';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import Save from 'material-ui-icons/Save';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
import TextField from 'material-ui/TextField';
import { goToColumn, goBack, clearDar, closeDialogNewFile, newTrelloCard, openDialogNewFile, getTrelloKey, chooseCards, getBoards, getLists, getCards, getMove, getMakeCard, cardDropDownRefreshed, moveCard, makeCard, storeSupportType, snackBarMessage } from '../redux/actions/appActions.jsx';
import Trello from 'node-trello';
import MenuItem from 'material-ui/MenuItem';
import SelectField from 'material-ui/SelectField';
import HelpPane from './HelpPane.jsx';
import SettingsPane from './SettingsPane.jsx';
var ipcRenderer = electron.ipcRenderer;

export class DarRequestPane extends React.Component {
    constructor(props) {
        super(props);
    }
    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false
        }
    }
    static clickBack(props) {
        props.popPane()
        props.clearDar()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        props.popPane()
    }
    static clickHelp(props) {
        props.popPane()
    }
    render() {
        return (
            <div>
                <h2>DAR Request</h2>
                <ul className="list5">
                    <li>
                        <strong>Request Type</strong>: Individual ID
                    </li>
                    <br />
                    <li>
                        <strong>Organization</strong>: IT-Other Organizations
                    </li>
                    <br />
                    <li>
                        <strong>Application ID / CUID</strong>: {this.props.appState.cuid}
                    </li>
                    <br />
                    <li>
                        <strong>Model ID / Mirror ID</strong>: {this.props.appState.mirrorId ? this.props.appState.mirrorId : 'N/A'}
                    </li>
                    <br />
                    <li>
                        <strong>Database Name</strong>: {this.props.appState.databaseName}
                    </li>
                    <br />
                    <li>
                        <strong>Type of Access</strong>: Read Access
                    </li>
                    <br />
                    <li>
                        <strong>Access Requested For</strong>: Production Database
                    </li>
                    <br />
                    <li>
                        <strong>Justification for Access Request</strong>: Fenway Group to provide analysis for Security.  Need read-only access to {this.props.appState.cuid} app {this.props.appState.databaseName} read-only database.
                    </li>
                    <br />
                    <li>
                        <strong>SLA</strong>: DO NOT CHECK
                    </li>
                    <br />
                    <li>
                        <strong>Requested Assets</strong>: Physical Network Inventory
                    </li>
                    <br />
                    <li>
                        <strong>Comments</strong>: Will need access to all tables. Will be preforming network security analysis.
                    </li>
                    <br />
                    <li>
                        <strong>Status</strong>: New
                    </li>
                    <br />
                    <li>
                        <strong>Status Date</strong>: Todays date
                    </li>
                </ul>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});

const mapDispatchToProps = {
    openRequestPane,
    getTrelloKey,
    openDialogNewFile,
    clearDar,
    closeDialogNewFile,
    chooseCards,
    cardDropDownRefreshed,
    makeCard,
    newTrelloCard,
    storeSupportType,
    snackBarMessage,
}

const DarRequestPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(DarRequestPane);

export default DarRequestPaneContainer;