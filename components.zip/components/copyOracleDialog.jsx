
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, goBack, openDialog, copyDialog, currentColumn, } from '../redux/actions/appActions.jsx';
var ipcRenderer = electron.ipcRenderer;
class CopyOracleDialog extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: this.props.event }
    this.updateValue = this.updateValue.bind(this);
    this.handleCopy = this.handleCopy.bind(this);
    this.onKeyPress = this.onKeyPress.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }
  //when cancel is selected on the multi dialog box, handleClose will close the multi Dialog box
  handleClose = () => {
    this.props.copyDialog();
    this.setState({ open: false });
  };
  //when the user enters anything into the multi dialog text box, updateValue will set the textValue as the newValue given
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };
  /*when a user presses the submit button on the dialog box, createColumn update the state with new columns */
  handleCopy = () => {
    ipcRenderer.send('copyToClipboard', this.props.appState.event, 'Row copied to clipboard');
    this.props.copyDialog();
  }
  //if enter is pressed it will preform the same action as the submit button
  onKeyPress(event) {
    if (event.charCode === 13) {
      //on keyboard press of enter (enter's charcode value is 13)
      event.preventDefault();
      if (this.props.appState.event) {
        ipcRenderer.send('copyToClipboard', this.props.appState.event, 'Row copied to clipboard');
        this.props.copyDialog();
        this.setState({ textValue: null });
      }
    }
  }

  render() {
    const actions = [
      <RaisedButton
        id="submitName"
        label="copy"
        backgroundColor='#147aff'
        labelColor='#FFFFFF'
        keyboardFocused={true}
        onTouchTap={this.handleCopy}
        disabled={!(this.props.appState.event)} />,

      <RaisedButton
        label="Cancel"
        backgroundColor='#ff1e1e'
        labelColor='#FFFFFF'
        onTouchTap={this.handleClose} />,
    ];

    const focusInputField = input => {
      if (input) {
        setTimeout(() => { input.focus() }, 100);
      }
    };

    return (
      <div>
        <Dialog
          ref='dia'
          title="verify Copy"
          actions={actions}
          modal={false}
          open={this.props.appState.dialogCopy}
          onRequestClose={this.handleClose}>

          <TextField
            ref={focusInputField}
            onKeyPress={this.onKeyPress}
            name="Column Name"
            type="con"
            hintText="Copy Text"
            onChange={this.updateValue}
            multiLine={true}
            fullWidth={true}
            value={this.props.appState.event} />
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openDialog,
  addToColumnList,
  goToColumn,
  goBack,
  currentColumn,
  copyDialog
};

const CopyOracleDialogContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (CopyOracleDialog);

export default CopyOracleDialogContainer;