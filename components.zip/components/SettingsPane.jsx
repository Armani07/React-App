import React from 'react';
import { connect } from 'react-redux';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Checkbox from 'material-ui/Checkbox';
import FlatButton from 'material-ui/FlatButton';
import electron from 'electron';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import { chooseBoard, moveCard, saved, disablePage, chooseList, loadWorkSpace, getTrelloKey, getBoards, changeOpen, addPhrase, changeSave, storeFilterUser, storePerPageUser, workspaceType, storeStripedUser, storeUppercase, storeScreenSize, storeSaveSetting, overwriteNewSettings, settingsReset, openDefaultDialog, updateRemoveListPhrases, removeFromPhrasesList, storeWarningSetting, storeWarningSetting2, reduxPhrasesImport, openSettingsDialog, completeReturn, snackBarMessage } from '../redux/actions/appActions.jsx';
import DataTables from 'material-ui-datatables';
import Trello from 'node-trello';
import { List, ListItem } from 'material-ui/List';
import ActionGrade from 'material-ui/svg-icons/action/grade';
import ContentInbox from 'material-ui/svg-icons/content/inbox';
import ContentDrafts from 'material-ui/svg-icons/content/drafts';
import ContentSend from 'material-ui/svg-icons/content/send';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import HelpPane from './HelpPane.jsx';
import logger from '../../logger.js';
import HomeComp from './HomeComp.jsx';
import BeginningOracleComp from './BeginningOracleComp.jsx';
import BeginningQAComp from './BeginningQAComp.jsx';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';

var t;
var storeId = '';
var boardArray = [];
var arrayOfBoards = [];
var storeArrayLength = null;

const TABLE_COLUMNS = [
    {
        key: 'commonPhrase',
        label: 'Phrases'
    }
];
const styles = {
    block: {
        maxWidth: 250,
        paddingTop: '10px'
    },
    checkbox: {
        marginBottom: 16,
        textAlign: 'left',
    },
};


const screenSize = [
    <MenuItem key={"Full Screen"} value={"Full Screen"} primaryText="Full Screen" />,
    <MenuItem key={"hsv"} value={"hsv"} primaryText="Half Screen Vertical" />,
    <MenuItem key={"hsh"} value={"hsh"} primaryText="Half Screen Horizontal" />
];
const pageSize = [
    <MenuItem key={"10"} value={10} primaryText="10" />,
    <MenuItem key={"25"} value={25} primaryText="25" />,
    <MenuItem key={"50"} value={50} primaryText="50" />,
    <MenuItem key={"100"} value={100} primaryText="100" />,
    <MenuItem key={"200"} value={200} primaryText="200" />
];
const workTypes = [
    <MenuItem key={"Visual Oracle Data Scrubbing"} value={"HomeComp"} primaryText="Visual Oracle Data Scrubbing" />,
    <MenuItem key={"Oracle Automation"} value={"BeginningOracleComp"} primaryText="Oracle Automation" />,
    <MenuItem key={"Application Validation"} value={"BeginningQAComp"} primaryText="Application Validation" />
]
var ipcRenderer = electron.ipcRenderer;
export class SettingsPane extends React.Component {
    constructor(props) {
        super(props);
        this.state = { location: '', value: '', removeList: [], removeColumnList: [], list: [], lists: [], move: [], boards: false, tList: false, moveList: false, boardSelectedId: '', open: false };
        this.handleNestedListToggle = this.handleNestedListToggle.bind(this)
        this.handleSelectedEvents = this.handleSelectedEvents.bind(this)
        this.updateFilterUser = this.updateFilterUser.bind(this)
        this.handlePerTablePageChange = this.handlePerTablePageChange.bind(this)
        this.handleWorkspace = this.handleWorkspace.bind(this)
        this.updateStripedUser = this.updateStripedUser.bind(this)
        this.updateUppercase = this.updateUppercase.bind(this)
        this.makeBoardDropDown = this.makeBoardDropDown.bind(this)
        this.makeListDropDown = this.makeListDropDown.bind(this)
        this.moveCardDropDown = this.moveCardDropDown.bind(this)
        this.paneName = this.paneName.bind(this)
        this.makeBoardDropDown(props);
        this.makeListDropDown(props.appState.currentSetting.board, props);
        this.moveCardDropDown(props.appState.currentSetting.board, props);

        ipcRenderer.on('settingOpenReturn', (event, arg) => {
            props.changeOpen(arg)
        });
        ipcRenderer.on('phrasesImportReply', (event, arg1, arg2) => {
            props.saved();
            props.disablePage();
            props.reduxPhrasesImport(arg1, arg2);
        });
        ipcRenderer.on('ok', (event, arg) => {
            props.changeSave(arg)
        });
        ipcRenderer.on('trelloSend', function (event, arg) {
            props.getTrelloKey(arg);
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", arg);
        });
    };
    static paneProps() {
        return {
            backDisabled: false,
            helpDisabled: false
        }
    };
    static clickBack(props) {
        if (props.appState.newSetting !== props.appState.currentSetting) {
            props.openSettingsDialog();
        }
        else {
            props.popPane(props.appState.newSetting.workspace, props.appState.paneArray);
        }
    };
    static clickAdd(props) {
        return (null)
    };
    static clickRemove(props) {
        return (null)
    };
    static clickAddNewFile(props) {
        return (null)
    };
    static clickOpen(props) {
        return (null)
    };
    static clickSave(props) {
        return (null)
    };
    static clickMerge(props) {
        return (null)
    };
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    };
    static clickHelp(props) {
        props.popPane();
    };
    erhm() {
        ipcRenderer.send('setSave', this.props.appState.currentSetting.savePath);
    }
    makeBoardDropDown(nextProps) {
        if (nextProps.appState.token) {
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", nextProps.appState.token);
            // URL arguments are passed in as an object.
            t.get('/1/members/me/boards', (err, meta) => {
                if (err) { throw err; }
                var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
                for (var i = 0; i < meta.length; i++) {
                    testArr.push(<MenuItem key={meta[i].id} value={meta[i].id} primaryText={meta[i].name} />)
                }
                this.setState({ list: testArr, boards: true })
                return testArr;
            });
        }
    }
    makeListDropDown(arg, nextProps) {
        if (nextProps.appState.token && arg != 'blank') {
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", nextProps.appState.token);
            t.get('/1/boards/' + arg + '/lists', (err, meta) => {
                if (err) throw err;
                var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
                for (var i = 0; i < meta.length; i++) {
                    testArr.push(<MenuItem key={meta[i].id} value={meta[i].id} primaryText={meta[i].name} />)
                }
                this.setState({ lists: testArr, tList: true })
                return testArr;
            });
        } else {
            var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
            this.setState({ lists: testArr, tList: true })
        }
    }
    moveCardDropDown(arg, nextProps) {
        if (nextProps.appState.token && arg != 'blank') {
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", nextProps.appState.token);
            t.get('/1/boards/' + arg + '/lists', (err, meta) => {
                if (err) throw err;
                var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
                for (var i = 0; i < meta.length; i++) {
                    testArr.push(<MenuItem key={meta[i].id} value={meta[i].id} primaryText={meta[i].name} />)
                }
                this.setState({ move: testArr, moveList: true })
                return testArr;
            });
        } else {
            var testArr = [<MenuItem key={'blank'} value={'blank'} primaryText={'---'} />];
            this.setState({ move: testArr, tList: true })
        }
    }
    sendOpen() {
        ipcRenderer.send('openSetting');
    };
    updateFilterUser = (event, newValue) => {
        this.props.storeFilterUser(newValue)
    };
    handlePerTablePageChange(event, index, tablePage) {
        this.props.storePerPageUser(tablePage)
    };
    handleWorkspace(event, index, workTypes) {
        if (workTypes === 'HomeComp') {
            this.props.loadWorkSpace({ pane: HomeComp, paneName: workTypes })
        }
        else if ('BeginningOracleComp' === workTypes) {
            this.props.loadWorkSpace({ pane: BeginningOracleComp, paneName: workTypes })
        }
        else if ('BeginningQAComp' === workTypes) {
            this.props.loadWorkSpace({ pane: BeginningQAComp, paneName: workTypes })
        }
    };
    paneName(workTypes) {
        switch (workTypes) {
            case 'HomeComp':
                return HomeComp;
            case 'BeginningOracleComp':
                return BeginningOracleComp;
            case 'BeginningQAComp':
                return BeginningQAComp;
            default:
                return HomeComp
        }
    };
    updateStripedUser = (event, newValue) => {
        this.props.storeStripedUser(newValue)
    };
    updateUppercase = (event, newValue) => {
        this.props.storeUppercase(newValue)
    };
    updateSaveName = (event, newValue) => {
        this.props.storeSaveSetting(newValue === undefined ? true : newValue);
    };
    updateWarningModal = (event, newValue) => {
        this.props.storeWarningSetting(newValue === undefined ? true : newValue);
    };
    updateWarningModal2 = (event, newValue) => {
        this.props.storeWarningSetting2(newValue === undefined ? true : newValue);
    };
    handleScreenSizeChange = (event, index, screenSize) => {
        this.props.storeScreenSize(screenSize)
    };
    handleSave() {
        if (this.props.appState.newSetting.workspace.paneName != this.props.appState.currentSetting.workspace.paneName) {
            if (this.props.appState.newSetting.workspace.pane != null) {
                this.props.workspaceType(this.props.appState.newSetting.workspace)
            }
            else {
                this.props.workspaceType(this.props.appState.newSetting.workspace, this.paneName(this.props.appState.newSetting.workspace.paneName))
            }
        }
        this.props.overwriteNewSettings(this.props.appState.newSetting)
        ipcRenderer.send('saveSettings', this.props.appState.newSetting);
        this.props.snackBarMessage('Settings Saved')

    };
    defaultDialog() {
        this.props.openDefaultDialog()
    };
    exportPhrases() {
        ipcRenderer.send('exportPhrases', this.props.appState.currentSetting.savePath, this.props.appState.newSetting.commonPhrasesTheArray)
        this.props.disablePage();
        this.props.saved();
    };
    handlePhrase() {
        this.props.addPhrase(this.state.value)
        this.setState({ value: '' })
    };
    updateCompleteReturn = (event, newValue) => {
        this.props.completeReturn((newValue === undefined) ? true : newValue);
    };
    handleBoard(event, index, id) {
        this.props.chooseBoard(id)
        this.makeListDropDown(id, this.props)
        this.moveCardDropDown(id, this.props)
    };
    handleList(event, index, id) {
        this.props.chooseList(id)
    };
    handleMove(event, index, id) {
        this.props.moveCard(id)
    };
    handleChange(event, newValue) {
        this.setState({ value: newValue })
    };
    handleSelectedEvents(event) {
        var updatedColumns = [];
        var pageColumnList = this.props.appState.newSetting.commonPhrases;
        event.forEach(function (item, index) {
            updatedColumns.push(pageColumnList[item]);
        })
        this.props.updateRemoveListPhrases(event, updatedColumns);
        this.setState({ removeList: event, removeColumnList: updatedColumns });
    };
    handleRemove() {
        this.props.removeFromPhrasesList(this.props.appState.updatedColumnsPhrases);
        this.props.updateRemoveListPhrases([], []);
    };
    handleTrelloLogin() {
        ipcRenderer.send('trelloLogin')
    };
    handleNestedListToggle(item) {
        this.setState({ open: item.state.open });
    };
    importPhrases() {
        ipcRenderer.send('phrasesMerged', this.props.appState.currentSetting.openPath, this.props.appState.newSetting.commonPhrasesTheArray, this.props.appState.newSetting.commonPhrases)
        this.props.disablePage();
        this.props.saved();
    };
    componentWillReceiveProps(nextProps) {
        if (nextProps.appState.token && !this.state.boards) {
            this.makeBoardDropDown(nextProps)
        }
        if (nextProps.appState.token && !this.state.tList) {
            this.makeListDropDown(nextProps.appState.newSetting.board, nextProps)
        }
        if (nextProps.appState.token && !this.state.moveList) {
            this.moveCardDropDown(nextProps.appState.newSetting.board, nextProps)
        }
    }

    render() {

        return (
            <div id='wrapper2'>
                <ul className='list'>
                    <div id='Parent2'>
                        <li>
                            <h2>User Settings</h2>
                        </li>
                        <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                            <CardTitle
                                id='appSettings'
                                title="Reports"
                                actAsExpander={true}
                                showExpandableButton={true}
                                style={{ textAlign: 'left' }}
                            />
                            <CardText expandable={true}>
                                <SelectField id='workspaceType'
                                    floatingLabelText='Workspace Type'
                                    value={this.props.appState.newSetting.workspace.paneName}
                                    onChange={this.handleWorkspace.bind(this)}
                                    style={{ textAlign: 'left' }}>
                                    {workTypes}
                                </SelectField>
                            </CardText>
                        </Card>
                        <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                            <CardTitle
                                id='appSettings'
                                title="Trello"
                                actAsExpander={true}
                                showExpandableButton={true}
                                style={{ textAlign: 'left' }}
                            />
                            <CardText expandable={true}>
                                <SelectField id='trelloBoardSelect'
                                    floatingLabelText='Trello Boards'
                                    value={this.props.appState.newSetting.board ? this.props.appState.newSetting.board : "blank"}
                                    onChange={this.handleBoard.bind(this)}
                                    style={{ textAlign: 'left' }}>
                                    {this.state.list}
                                </SelectField>
                                <br />
                                <SelectField id='trelloListSelect'
                                    floatingLabelText='Trello Lists'
                                    value={this.props.appState.newSetting.list ? this.props.appState.newSetting.list : "blank"}
                                    onChange={this.handleList.bind(this)}
                                    style={{ textAlign: 'left' }}>
                                    {this.state.lists}
                                </SelectField>
                                <br />
                                <div>
                                <SelectField id='trelloMoveToSelect'
                                    floatingLabelText='Move Card To'
                                    value={this.props.appState.newSetting.move ? this.props.appState.newSetting.move : "blank"}
                                    onChange={this.handleMove.bind(this)}
                                    style={{ textAlign: 'left' }}>
                                    {this.state.move}
                                </SelectField>
                                </div>
                                <br />
                                <div>
                                <RaisedButton
                                    id='trelloLogin'
                                    backgroundColor='#147aff'
                                    label='Trello Login'
                                    labelColor='#FFFFFF'
                                    onTouchTap={this.handleTrelloLogin.bind(this)}
                                />
                                </div>
                            </CardText>
                        </Card>
                        <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                            <CardTitle
                                id='columnSettings'
                                title="Column Table Settings"
                                actAsExpander={true}
                                showExpandableButton={true}
                                style={{ textAlign: 'left' }}
                            />
                            <CardText expandable={true}>
                                <SelectField
                                    id='columnsPerPage'
                                    floatingLabelText='Columns Per Table Page'
                                    value={this.props.appState.newSetting.perPageSetting ? this.props.appState.newSetting.perPageSetting : "10"}
                                    onChange={this.handlePerTablePageChange.bind(this)}
                                //style={{ textAlign: 'left'}}
                                >
                                    {pageSize}
                                </SelectField>
                                <br />
                                <SelectField
                                    id='screenSize'
                                    floatingLabelText="Screen Size"
                                    value={this.props.appState.newSetting.screenSizeSetting ? this.props.appState.newSetting.screenSizeSetting : 'Full Screen'}
                                    onChange={this.handleScreenSizeChange.bind(this)}
                                    style={{ textAlign: 'left' }}>
                                    {screenSize}
                                </SelectField>
                                <br />
                                <Checkbox
                                    id='searchFilter'
                                    style={styles.block}
                                    label='Search Filter on Creation'
                                    onCheck={this.updateFilterUser.bind(this)}
                                    checked={this.props.appState.newSetting.searchFilterUser ? this.props.appState.newSetting.searchFilterUser : false}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='stripedColumnRows'
                                    label='Striped Column Rows'
                                    onCheck={this.updateStripedUser.bind(this)}
                                    checked={this.props.appState.newSetting.stripedColUser ? this.props.appState.newSetting.stripedColUser : false}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='autoUppercase'
                                    label='Auto Uppercase Table and Column Names'
                                    checked={this.props.appState.newSetting.uppercase ? this.props.appState.newSetting.uppercase : false}
                                    onCheck={this.updateUppercase}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='autoSave'
                                    label='Automatic Table Name as Save File'
                                    checked={this.props.appState.newSetting.saveName}
                                    onCheck={this.updateSaveName.bind(this)}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='disableIncomplete'
                                    label='Disable Warning for Incomplete Columns'
                                    checked={this.props.appState.newSetting.disableWarning}
                                    onCheck={this.updateWarningModal.bind(this)}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='disableMetric'
                                    label='Disable Warning for Metric Merge'
                                    checked={this.props.appState.newSetting.disableWarning2}
                                    onCheck={this.updateWarningModal2.bind(this)}
                                    style={styles.checkbox}>
                                </Checkbox>
                                <br />
                                <Checkbox
                                    id='compeleteReturn'
                                    label='Enable Complete Button Return'
                                    checked={this.props.appState.newSetting.completeReturn}
                                    onCheck={this.updateCompleteReturn.bind(this)}
                                    style={styles.checkbox}
                                >
                                </Checkbox>
                            </CardText>
                        </Card>
                        <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                            <CardTitle
                                id='fileSettings'
                                title="File Settings"
                                actAsExpander={true}
                                showExpandableButton={true}
                                style={{ textAlign: 'left' }}
                            />
                            <CardText expandable={true}>
                                <TextField
                                    floatingLabelText='Default Open Location'
                                    value={(this.props.appState.newSetting.openPath) ? this.props.appState.newSetting.openPath : ''}>
                                </TextField>
                                <RaisedButton
                                    backgroundColor='#147aff'
                                    label='Browse'
                                    labelColor='#FFFFFF'
                                    onTouchTap={this.sendOpen.bind(this)}
                                />

                                <br />
                                <TextField
                                    floatingLabelText='Default Save Location'
                                    value={(this.props.appState.newSetting.savePath) ? this.props.appState.newSetting.savePath : ''}>
                                </TextField>
                                <RaisedButton
                                    backgroundColor='#147aff'
                                    label='Browse'
                                    labelColor='#FFFFFF'
                                    onTouchTap={this.erhm.bind(this)}
                                />
                            </CardText>
                        </Card>
                        <Card style={{ boxShadow: '0px 0px 0px #888888' }}>
                            <CardTitle
                                id='phrases'
                                title="Phrases"
                                actAsExpander={true}
                                showExpandableButton={true}
                                style={{ textAlign: 'left' }}
                            />
                            <CardText expandable={true}>
                                <TextField
                                    id='phrasesInsert'
                                    floatingLabelText='Enter Phrases Here'
                                    onChange={this.handleChange.bind(this)}
                                    value={this.state.value}
                                >
                                </TextField>
                            <div>    
                                <RaisedButton
                                    id='phrasesSubmit'
                                    label='Submit'
                                    backgroundColor="#147aff"
                                    labelColor='#FFFFFF'
                                    onTouchTap={this.handlePhrase.bind(this)}
                                />
                            </div>

                                <br />
                                <DataTables
                                    height={'auto'}
                                    selectable={true}
                                    showRowHover={true}
                                    columns={TABLE_COLUMNS}
                                    data={this.props.appState.newSetting.commonPhrases}
                                    showCheckboxes={true}
                                    onCellClick={this.handleCellClick}
                                    onRowSelection={this.handleSelectedEvents}
                                    multiSelectable={true}
                                    selectedRows={this.props.appState.listOfRemovalsPhrases}
                                />
                                <div id = 'settingsButton'>
                                    <RaisedButton
                                        id='phrasesRemove'
                                        backgroundColor="#ff1e1e"
                                        label='Remove'
                                        labelColor='#FFFFFF'
                                        onTouchTap={this.handleRemove.bind(this)}
                                    />
                                </div>
                                <div id = 'settingsButton'>
                                    <RaisedButton
                                        backgroundColor="#147aff"
                                        label='export'
                                        labelColor='#FFFFFF'
                                        onTouchTap={this.exportPhrases.bind(this)}
                                    />
                                </div>
                                <div>
                                    <RaisedButton
                                        backgroundColor="#147aff"
                                        label='Import'
                                        labelColor='#FFFFFF'
                                        onTouchTap={this.importPhrases.bind(this)}
                                    />
                                </div>

                            </CardText>
                        </Card>
                        <div className="mouseCursor">
                            <li>
                                <div id = 'settingsButton'>
                                    <RaisedButton
                                        id='saveButton'
                                        backgroundColor="#147aff"
                                        label='Save'
                                        labelColor='#FFFFFF'
                                        width= '153px'
                                        onTouchTap={this.handleSave.bind(this)} />
                                </div>
                                
                                <div>
                                    <RaisedButton
                                        backgroundColor="#ff1e1e"
                                        label='Reset to Default'
                                        labelColor='#FFFFFF'
                                        onTouchTap={this.defaultDialog.bind(this)} />
                                    <br />
                                </div>
                            </li>
                        </div>
                    </div>
                </ul>
            </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});
const mapDispatchToProps = {
    getTrelloKey,
    changeOpen,
    changeSave,
    storeFilterUser,
    storePerPageUser,
    storeStripedUser,
    workspaceType,
    storeScreenSize,
    overwriteNewSettings,
    storeUppercase,
    storeSaveSetting,
    settingsReset,
    openDefaultDialog,
    addPhrase,
    updateRemoveListPhrases,
    removeFromPhrasesList,
    storeWarningSetting,
    storeWarningSetting2,
    getBoards,
    chooseBoard,
    chooseList,
    disablePage,
    saved,
    moveCard,
    reduxPhrasesImport,
    openSettingsDialog,
    completeReturn,
    snackBarMessage,
    loadWorkSpace
};

const SettingsPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(SettingsPane);

export default SettingsPaneContainer;