import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import MenuItem from 'material-ui/MenuItem';
import { connect } from 'react-redux'
import electron from 'electron';
import OraclePane from './OraclePane.jsx';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToOracleList, newTableOracle } from '../redux/actions/oracleActions.jsx'
import { goToColumn, goBack, closeDialogNewOracle, openErrorModal, appView, openDialogNewOracle, } from '../redux/actions/appActions.jsx';
var ipcRenderer = electron.ipcRenderer;
var t;
class DialogNewOracle extends React.Component {
  constructor(props) {
    super(props);
    this.state = { textValue: '' }
    this.onKeyPress = this.onKeyPress.bind(this);
    this.onTextChange = this.onTextChange.bind(this);
  }
  handleOpen = () => {
    // logger.log('Info','Modal Opened')
    this.props.openDialogNewOracle();
  };
  handleNewSchema = () => {
    if (this.state.textValue) {
      var pane = this.props.appState.paneArray[this.props.appState.paneArray.length - 1]
      if (pane.paneName === 'BeginningOracleComp') {
        this.props.appView(OraclePane, 'OraclePane')
      }
      this.props.newTableOracle((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);
      // this.setState({ textValue: '' });
    }
    this.props.closeDialogNewOracle();
  }
  handleClose = () => {
    this.props.closeDialogNewOracle();
  };
  onTextChange = (event, newValue) => {
    this.setState({ textValue: newValue, });
  };
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue })
  }
  onKeyPress(event) {
    if (event.charCode === 13) {
      event.preventDefault();
      if (this.state.textValue) {
        var pane = this.props.appState.paneArray[this.props.appState.paneArray.length - 1]
        if (pane.paneName === 'BeginningOracleComp') {
          this.props.appView(OraclePane, 'OraclePane')
        }
        this.props.newTableOracle((this.props.appState.currentSetting.uppercase) ? this.state.textValue.toUpperCase() : this.state.textValue);
        this.handleClose();
        // this.setState({ textValue: '' });
      }
    }
  }
  render() {
    const actions = [
      <RaisedButton
        id='submit'
        backgroundColor='#147aff'
        label="Submit"
        labelColor='#FFFFFF'
        keyboardFocused={true}
        onTouchTap={this.handleNewSchema}
        disabled={(this.state.textValue.length > 0) ? false : true}
        onKeyPress={this.onKeyPress}
      />,
      <RaisedButton
        backgroundColor='#ff1e1e'
        label="Cancel"
        labelColor='FFFFFF'
        onTouchTap={this.handleClose}
      />,
    ];
    const focusInputField = input => {
      if (input) {
        setTimeout(() => { input.focus() }, 100);
      }
    };
   
      return (
        <div>
          <Dialog
            ref='dialog'
            title="New Schema Name"
            actions={actions}
            modal={false}
            open={this.props.appState.oraclePane}
            onRequestClose={this.handleClose}
          >
         New Schema Name: <br />
          <TextField
            ref={focusInputField}
            onChange={this.onTextChange}
            name="Table Name"
            type="con"
            hintText="Max Characters: 30"
            multiLine={true}
            maxLength="30"
            onKeyPress={this.onKeyPress}
          />
          <br />
        </Dialog>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer,
  oracleState: state.oracleState
});
const mapDispatchToProps = {
  appView,
  newTableOracle,
  openDialogNewOracle,
  closeDialogNewOracle,
  openErrorModal
};
const DialogNewOracleContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (DialogNewOracle);
export default DialogNewOracleContainer;