
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { goBack, openSameFileDialog, closeSameFileDialog, disablePage, saved } from '../redux/actions/appActions.jsx';
import { updateMetricRemove, removeFromMetricsList } from '../redux/actions/metricActions.jsx'

var ipcRenderer = electron.ipcRenderer;
class SameFileDialog extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' };
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleOpen = () => {
    this.props.openSameFileDialog();
  };
  handleClose = () => {
    this.props.closeSameFileDialog();
    this.setState({ open: false });
  };
  handleClick = () => {
    this.props.closeSameFileDialog();
    this.props.saved();
    this.props.disablePage();
    ipcRenderer.send('sync', this.props.columnReducer.columnList, this.props.columnReducer.tableName, this.props.appState.currentSetting.savePath, this.props.appState.currentSetting.saveName, true)
  }
  updateValue = (event, newValue) => {
    this.setState({ textValue: newValue });
  };

  render() {
    const actions = [
      <FlatButton
      id = 'yes'
        id="overwriteYes"
        label="Yes"
        primary={true}
        onTouchTap={this.handleClick}
      />,
      <FlatButton
        label="No"
        primary={true}
        onTouchTap={this.handleClose}
      />,
    ];

    return (
      <div>
        <Dialog
          ref='dia'
          title="Overwrite Dialog"
          actions={actions}
          open={this.props.appState.sameFileDialog}
          onRequestClose={this.handleClose}>
          Warning: This file already exists and continiung will overwrite the current file. Are you sure you want to continue? <br />
          <br />
        </Dialog>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openSameFileDialog,
  closeSameFileDialog,
  saved,
  disablePage,
  goBack
};

const SameFileDialogContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (SameFileDialog);

export default SameFileDialogContainer;