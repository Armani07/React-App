import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Checkbox from 'material-ui/Checkbox';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, saved, getTrelloKey, closeErrorModal, disablePage, goBack, closeDialog, openDialog, openDialogSave, closeDialogSave, storeWarningModal } from '../redux/actions/appActions.jsx';
import Trello from 'node-trello';
const logger = require('../../logger.js');
const winston = require('winston');


/**
 * Dialog with action buttons. The actions are passed in as an array of React objects,
 * in this example [FlatButtons](/#/components/flat-button).
 *
 * You can also close this dialog by clicking outside the dialog, or with the 'Esc' key.
 */

var ipcRenderer = electron.ipcRenderer;
var t;
class ErrorModal extends React.Component {

    constructor(props) {
        super(props);
        this.state = { textValue: '' };
        this.state = { open: true };
        this.handleClose = this.handleClose.bind(this);
        this.handleOpen = this.handleOpen.bind(this);
        this.handleClick = this.handleClick.bind(this);
        ipcRenderer.on('trelloSend', function (event, arg) {
            props.getTrelloKey(arg);
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", arg);
        });
    }
    handlePost = (event, index, id) => {
        if (this.props.appState.token) {
            t = new Trello("c316d1930a91b06fd7d8d7ee662c1bc4", this.props.appState.token)
            t.post('/1/cards?idList=5a0089c4194e013288bec437&desc=' + this.props.appState.errorMessage + '&pos=bottom'+'&name=Crash Report', (err) => {
            });
                this.props.closeErrorModal()
        }
    }

    handleOpen = () => {
        this.props.openDialogSave();
    };

    handleClose = () => {
        this.props.closeErrorModal();
    };

    handleClick = () => {
        if (this.props.appState.token === '' || this.props.appState.token === null) {
            ipcRenderer.send('trelloLogin')  
        }
        else{
            this.handlePost()
        }
    }
    updateWarningModal = (event, newValue) => {
        this.props.storeWarningModal(newValue === undefined ? true : newValue);
    }

    render() {

        const actions = [
            <FlatButton
                label={(this.props.appState.token === "") ? "Login" : "Send"}
                primary={true}
                keyboardFocused={true}
                onTouchTap={this.handleClick}
            />,
            <FlatButton
                label="Close"
                primary={true}
                keyboardFocused={true}
                onTouchTap={this.handleClose}
            />,
        ]

        return (
            <div>
                <Dialog
                    ref='dia'
                    title="Error"
                    actions={actions}
                    modal={true}
                    open={this.props.appState.errorModal}
                    onRequestClose={this.handleClose}>

                    There has been an error with the application. If you would like to send this report to the developers click the send button.<br />
                    If not, click the close button to continue normal operations.<br />

                </Dialog>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    openDialog,
    closeDialog,
    addToColumnList,
    closeDialogSave,
    openDialogSave,
    disablePage,
    saved,
    storeWarningModal,
    closeErrorModal,
    getTrelloKey
};

const ErrorModalContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)
    (ErrorModal);

export default ErrorModalContainer;
