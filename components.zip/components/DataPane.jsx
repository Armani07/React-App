import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Checkbox from 'material-ui/Checkbox';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import { connect } from 'react-redux'
import { saveQa } from '../redux/actions/qaActions.jsx';
import { goToColumn, updateQASort, changeCompletedBack, storeQAComments, storeQAQuestion, completedMinus, storeNewColumnName, completedPlus, storeCompleted, previousQAColumn, popPane, snackBarMessage, nextQAColumn, goBack, StoreChangedColumn, storeQaAcronym, storeUpdateQ1, storehandleq2, storeUpdateQ3, storeUpdateQ4, storeUpdateQ5, storeUpdateQ6, storehandleq7, storeUpdateQ8, } from '../redux/actions/appActions.jsx';
import FlatButton from 'material-ui/FlatButton';
import ChevronLeft from 'material-ui-icons/ChevronLeft';
import ChevronRight from 'material-ui-icons/ChevronRight';
import AutoComplete from 'material-ui/AutoComplete';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';

// Answeres for question 2 dropdown
const q2Answers = [
    <MenuItem key={"YES"} value={"YES"} primaryText="YES" />,
    <MenuItem key={"NO"} value={"NO"} primaryText="NO" />,
    <MenuItem key={"NO USERS"} value={"NO USERS"} primaryText="NO USERS" />,
]

// Answeres for question 7 dropdown
const q7Answers = [
    <MenuItem key={"YES"} value={"YES"} primaryText="YES" />,
    <MenuItem key={"NO"} value={"NO"} primaryText="NO" />,
    <MenuItem key={"NO RESPONSE"} value={"NO RESPONSE"} primaryText="NO RESPONSE" />,
]

const styles = {
    block: {
        maxWidth: 500,
        paddingTop: '10px'
    },
    checkbox: {
        marginBottom: 16,
        textAlign: 'left'
    },
    customWidth: {
        width: 150,
    },
};
export class DataPane extends React.Component {
    constructor(props) {
        super(props);
        this.handleColumnNameChange = this.handleColumnNameChange.bind(this);
        this.handleRight = this.handleRight.bind(this);
        this.handleLeft = this.handleLeft.bind(this);
        this.handleq2Change = this.handleq2Change.bind(this);
        this.handleq7Change = this.handleq7Change.bind(this);
    }

    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false
        }
    }
    static clickBack(props) {
        props.saveQa(props.appState.storedColumn);
        props.changeCompletedBack()
        props.snackBarMessage('Data Saved')
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }

    handleColumnNameChange(event, columnName) {
        this.props.storeNewColumnName(columnName);
    }

    handleCompleteToggle() {
        var newComp = this.props.appState.storedColumn.completed
        if (!newComp) {
            this.setState({ completed: 'Completed' })
            this.props.storeCompleted(true)
            this.props.completedPlus()
        } else {
            this.setState({ completed: 'Uncompleted' })
            this.props.storeCompleted(false)
            this.props.completedMinus()
        }
    };

    updateAcronym = (event, newValue) => {
        this.props.storeQaAcronym(newValue)
        //console.log(this.props.appState.storedColumn.acronym);
    };

    updateQ1 = (event, newValue) => {
        this.props.storeUpdateQ1(newValue)
    };

    handleq2Change(event, index, q2Answer) {
        this.props.storehandleq2(q2Answer);
    };

    updateQ3 = (event, newValue) => {
        this.props.storeUpdateQ3(newValue)
    };

    updateQ4 = (event, newValue) => {
        this.props.storeUpdateQ4(newValue)
    };

    updateQ5 = (event, newValue) => {
        this.props.storeUpdateQ5(newValue)
    };

    updateQ6 = (event, newValue) => {
        this.props.storeUpdateQ6(newValue)
    };

    handleq7Change(event, index, q7Answer) {
        this.props.storehandleq7(q7Answer);
    };

    updateQ8 = (event, newValue) => {
        this.props.storeUpdateQ8(newValue)
    };

    updateComments = (event, newValue) => {
        this.props.storeQAComments(newValue)
    };

    updateQuestion = (event, newValue) => {
        this.props.storeQAQuestion(newValue)
    };

    handleRight = () => {
        this.props.saveQa(this.props.appState.storedColumn);
        this.props.updateQASort(this.props.qaState.columnList)
        this.props.nextQAColumn();
    }

    handleLeft = () => {
        this.props.saveQa(this.props.appState.storedColumn);
        this.props.updateQASort(this.props.qaState.columnList)
        this.props.previousQAColumn();
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.appState.currentSetting.completeReturn && nextProps.appState.completedBack) {
            nextProps.changeCompletedBack()
            nextProps.saveQa(nextProps.appState.storedColumn);
            nextProps.snackBarMessage('Data Saved')
            nextProps.popPane()
        }
    }

    render() {
        let dis = null;
        if (this.props.appState.storedColumn.cii) {
            dis = (false);
        } else {
            dis = (true);
        }
        return (
            <div id='wrapper4'>
                <ul className='list7'>
                    <div id='rightParent3'>
                        <ChevronLeft
                            className="lobe mouseCursor"
                            id='leftButtonDataPane'
                            onTouchTap={this.handleLeft} />
                        <div id='dataPaneRightDiv'>
                            <li style={{ paddingTop: '35px' }}>
                                <TextField
                                    /*This text field will contain the column name. The Default Value will be given by the users when the column is created. Column name will be editable by the user.*/
                                    floatingLabelText="Application Name"
                                    value={this.props.appState.storedColumn.appName ? this.props.appState.storedColumn.appName : ''}
                                    onChange={this.handleColumnNameChange.bind(this)}
                                    inputStyle={{ textAlign: 'left' }}
                                    fullWidth={true}
                                >
                                </TextField>
                            </li>
                            <li >
                                <TextField
                                    floatingLabelText="Acronym"
                                    value={this.props.appState.storedColumn.acronym ? this.props.appState.storedColumn.acronym : ''}
                                    onChange={this.updateAcronym.bind(this)}
                                    inputStyle={{ textAlign: 'left' }}
                                    fullWidth={true} >
                                </TextField>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion1'
                                        label="When you click on the Link to Logical Access Control Doc, can you access the Logical Access Control document?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ1.bind(this)}
                                        checked={this.props.appState.storedColumn.q1 ? this.props.appState.storedColumn.q1 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            <li>
                                <div>
                                    <CardText expandable={true}>
                                        <div id='dataQuestionLabel2'> Does the document indicate how to request access?</div>
                                        <div id='dataQestionDrop2'>
                                            <SelectField id='dataQuestion2'
                                                value={this.props.appState.storedColumn.q2Answer ? this.props.appState.storedColumn.q2Answer : ''}
                                                style={styles.customWidth}
                                                onChange={this.handleq2Change.bind(this)}>
                                                {q2Answers}
                                            </SelectField>
                                        </div>
                                    </CardText>
                                </div>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion3'
                                        label="Does the document indicate if any approval is required and if so, whose?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ3.bind(this)}
                                        checked={this.props.appState.storedColumn.q3 ? this.props.appState.storedColumn.q3 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion4'
                                        label="Does the document indicate a periodic access review is performed?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ4.bind(this)}
                                        checked={this.props.appState.storedColumn.q4 ? this.props.appState.storedColumn.q4 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion5'
                                        label="Does the document indicate a process to remove access for terminated users?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ5.bind(this)}
                                        checked={this.props.appState.storedColumn.q5 ? this.props.appState.storedColumn.q5 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion6'
                                        label="Does the document indicate a process to review access for transferred employees?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ6.bind(this)}
                                        checked={this.props.appState.storedColumn.q6 ? this.props.appState.storedColumn.q6 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            <li>
                                <div >
                                    <CardText expandable={true}>
                                        <div id='dataQuestionLabel7'>Does the document contain a reference to data for European Union residents?</div>
                                        <div id='dataQestionDrop7'>
                                            <SelectField id='dataQuestion7'
                                                value={this.props.appState.storedColumn.q7Answer ? this.props.appState.storedColumn.q7Answer : ''}
                                                style={styles.customWidth}
                                                onChange={this.handleq7Change.bind(this)}>
                                                {q7Answers}
                                            </SelectField>
                                        </div>
                                    </CardText>
                                </div>
                            </li>
                            <li>
                                <div >
                                    <Checkbox id='dataQuestion8'
                                        label="Has the Logical Access Control Document been updated since February 9, 2017?"
                                        style={styles.checkbox}
                                        onCheck={this.updateQ8.bind(this)}
                                        checked={this.props.appState.storedColumn.q8 ? this.props.appState.storedColumn.q8 : false}
                                        labelPosition='left' />
                                </div>
                            </li>
                            {/* <li className='commentsQuestions'>
                                <TextField
                                    floatingLabelText="Questions"
                                    value={this.props.appState.storedColumn.question ? this.props.appState.storedColumn.question : ''}
                                    onChange={this.updateQuestion.bind(this)}
                                    multiLine={true}
                                    rows={1} 
                                    style={{textAlign:'left'}}/>
                            </li>
                            <li className='commentsQuestions'>
                                <TextField
                                    floatingLabelText="Comments"
                                    value={this.props.appState.storedColumn.comments ? this.props.appState.storedColumn.comments : ''}
                                    onChange={this.updateComments.bind(this)}
                                    multiLine={true}
                                    rows={1} 
                                    style={{textAlign:'left'}}/>
                            </li> */}
                            <div>
                                <RaisedButton
                                    id='completeButton'
                                    label={this.props.appState.storedColumn.completed ? 'Completed' : 'Uncompleted'}
                                    onTouchTap={this.handleCompleteToggle.bind(this)}
                                    backgroundColor={(this.props.appState.storedColumn.completed) ? '#147aff' : '#ff1e1e'}
                                    labelColor='#FFFFFF'
                                />
                            </div>
                        </div>
                        <ChevronRight
                            className="lobe mouseCursor"
                            id='rightButtonDataPane'
                            onTouchTap={this.handleRight} />
                    </div>
                </ul>
            </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => ({
    qaState: state.qaState,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    goToColumn,
    saveQa,
    storeQaAcronym,
    storeUpdateQ1,
    storehandleq2,
    storeUpdateQ3,
    storeUpdateQ4,
    storeUpdateQ5,
    storeUpdateQ6,
    storehandleq7,
    storeUpdateQ8,
    storeCompleted,
    storeQAComments,
    storeQAQuestion,
    storeNewColumnName,
    nextQAColumn,
    updateQASort,
    previousQAColumn,
    completedPlus,
    completedMinus,
    popPane,
    changeCompletedBack,
    snackBarMessage,
};

const DataPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(DataPane);

export default DataPaneContainer;