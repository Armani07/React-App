import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import { connect } from 'react-redux'
import RaisedButton from 'material-ui/RaisedButton';
import electron from 'electron';
import { closeDefaultSettings, settingsReset } from '../redux/actions/appActions.jsx';

var ipcRenderer = electron.ipcRenderer;
export class DefaultSettings extends React.Component {
   constructor(props) {
    super(props);
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
  }

  handleYes = () => {
    this.props.closeDefaultSettings()
    this.props.settingsReset()
    ipcRenderer.send('saveSettings',this.props.appState.defaultSetting);
  }
  handleNo = () => {
    this.props.closeDefaultSettings()
  }
  handleClose = () => {
    this.props.closeDefaultSettings()
  };
  handleReset(){
    this.props.settingsReset()
  }

  render() {
    const actions = [
      <FlatButton
      id = 'yes'
        label="Yes"
        primary={true}
        keyboardFocused={true}
        onClick={this.handleYes.bind(this)}
      />,
      <FlatButton
        label='No'
        primary={true}
        keyboardFocused={false}
        onClick={this.handleNo}
        />
    ];
    return (
      <div>
        <Dialog
          title="Reset To Default"
          actions={actions}
          modal={false}
          open={this.props.appState.defaultPrompt}
          onRequestClose={this.handleReset}
        >
          Are you sure you want to restore all settings to default?
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  closeDefaultSettings,
  settingsReset
};

const DefaultSettingsContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (DefaultSettings);

export default DefaultSettingsContainer;