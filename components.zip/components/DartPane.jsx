import React from 'react';
import { connect } from 'react-redux';
import electron from 'electron';
import RaisedButton from 'material-ui/RaisedButton';
import { openDartPane } from '../redux/actions/appActions.jsx'
import { List, ListItem } from 'material-ui/List';
import ArrowBack from 'material-ui-icons/ArrowBack';
import Add from 'material-ui-icons/Add';
import Remove from 'material-ui-icons/Remove';
import Save from 'material-ui-icons/Save';
import Checkbox from 'material-ui/Checkbox';
import Folder from 'material-ui-icons/Folder';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import Settings from 'material-ui-icons/Settings';
import MergeType from 'material-ui-icons/MergeType';
import Subheader from 'material-ui/Subheader';
import Toggle from 'material-ui/Toggle';
import { Card, CardActions, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
import TextField from 'material-ui/TextField';
import { goToColumn, goBack, closeDialogNewFile, storeCUID, storeMirrorId, storeDatabaseName, appView, newTrelloCard, openDialogNewFile, getTrelloKey, chooseCards, getBoards, getLists, getCards, getMove, getMakeCard, cardDropDownRefreshed, moveCard, makeCard, storeSupportType, snackBarTrello, popPane } from '../redux/actions/appActions.jsx';
import MenuItem from 'material-ui/MenuItem';
import SelectField from 'material-ui/SelectField';
import HelpPane from './HelpPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import DarRequestPane from './DarRequestPane.jsx';


const styles = {
    checkbox: {
        marginTop: 16,
    },
}
var ipcRenderer = electron.ipcRenderer;
var t;
export class DartPane extends React.Component {
    constructor(props) {
        super(props);
        this.state = { textValue: '', idProvided: false }
        this.handleRequest = this.handleRequest.bind(this);
    }
    handleRequest() {
        this.props.appView(DarRequestPane, "DarRequestPane")
    };

    static paneProps() {
        return {
            backDisabled: false,
            settingsDisabled: false,
            helpDisabled: false
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        return (null)
    }
    static clickRemove(props) {
        return (null)
    }
    static clickAddNewFile(props) {
        return (null)
    }
    static clickOpen(props) {
        return (null)
    }
    static clickSave(props) {
        return (null)
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    handleIdProvided() {
        if (this.state.idProvided) {
            this.setState({ idProvided: false })
        }
        else if (!this.state.idProvided) {
            this.setState({ idProvided: true })
        }
    }
    handleDatabaseNameChange(event, databaseName){
        this.props.storeDatabaseName(databaseName);
    }
    handleCUIDChange(event, cuid) {
        this.props.storeCUID(cuid);
    }
    handleMirrorIdChange(event, mirrorId) {
        this.props.storeMirrorId(mirrorId);
    }
    render() {
        return (
            <div id='wrapper'>
                <ul className='list3'>
                    <div>
                        <li>
                            <h2>DAR Generator </h2>
                        </li>
                        <br />
                        <div className='dartText'>
                            <li>
                                <TextField id='txtCUID'
                                    floatingLabelText={"CUID"}
                                    hintText={"What is your CUID?"}
                                    multiLine={true} 
                                    onChange={this.handleCUIDChange.bind(this)}
                                    value={this.props.appState.cuid ? this.props.appState.cuid : ''}
                                    />
                            </li>
                            <br />
                            <li> 
                                <Checkbox
                                    id='chkMirrorId'
                                    label='Was there a model ID or mirror ID provided?'
                                    checked={this.state.idProvided}
                                    onCheck={this.handleIdProvided.bind(this)}
                                    style={styles.checkbox}
                                />
                            </li>
                            <br />
                            <li>
                                <TextField id='txtMirrorId'
                                    floatingLabelText={this.state.idProvided ? "ID#" : null}
                                    disabled={this.state.idProvided ? false : true}
                                    multiLine={true} 
                                    onChange={this.handleMirrorIdChange.bind(this)}
                                    value={this.props.appState.mirrorId}
                                    />
                            </li>
                            <br />
                            <li>
                                <TextField id='txtDatabaseName'
                                    floatingLabelText={"Database Name"}
                                    hintText={"What is the name of the database?"}
                                    multiLine={true} 
                                    onChange={this.handleDatabaseNameChange.bind(this)}
                                    value={this.props.appState.databaseName ? this.props.appState.databaseName : ''}/>
                            </li>
                        </div>
                        <br />
                        <li>
                            <RaisedButton
                                id='btnGenerate'
                                label='Generate'
                                backgroundColor="#147aff"
                                labelColor='#FFFFFF'
                                onTouchTap={this.handleRequest.bind(this)}
                            />
                        </li>
                    </div>
                </ul>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState
});

const mapDispatchToProps = {
    openDartPane,
    openDialogNewFile,
    closeDialogNewFile,
    storeSupportType,
    popPane,
    appView,
    storeDatabaseName,
    storeCUID,
    storeMirrorId
}
const DartPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(DartPane);

export default DartPaneContainer;