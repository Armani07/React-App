
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Checkbox from 'material-ui/Checkbox';
import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import { addToColumnList } from '../redux/actions/columnActions.jsx'
import { goToColumn, saved, disablePage, goBack, closeDialog, openDialog, openDialogSave, closeDialogSave, storeWarningModal } from '../redux/actions/appActions.jsx';

/**
 * Dialog with action buttons. The actions are passed in as an array of React objects,
 * in this example [FlatButtons](/#/components/flat-button).
 *
 * You can also close this dialog by clicking outside the dialog, or with the 'Esc' key.
 */

var ipcRenderer = electron.ipcRenderer;
class DialogSave extends React.Component {

  constructor(props) {
    super(props);
    this.state = { textValue: '' }; 
    this.state = { open: true };
    this.handleClose = this.handleClose.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleOpen = () => {
    this.props.openDialogSave();
  };

  handleClose = () => {
    this.props.closeDialogSave();
    this.setState({ open: false });
    ipcRenderer.send('saveSettings', this.props.appState.newSetting);
  };

  handleClick = () => {
    this.props.closeDialogSave();
    this.props.saved();
    this.props.disablePage();
    ipcRenderer.send('sync', this.props.columnReducer.columnList, this.props.columnReducer.tableName, this.props.appState.currentSetting.savePath, this.props.appState.currentSetting.saveName)
    ipcRenderer.send('saveSettings', this.props.appState.newSetting);
  }
  updateWarningModal = (event, newValue) => {
    this.props.storeWarningModal(newValue === undefined ? true : newValue);
  }

  render() {

    const actions = [
      <FlatButton
        label="YES"
        primary={true}
        keyboardFocused={true}
        onTouchTap={this.handleClick}
      />,
      <FlatButton
        label="NO"
        primary={true}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />,
    ]

    return (
      <div>
        <Dialog
          ref='dia'
          title="Save Columns"
          actions={actions}
          modal={true}
          open={this.props.appState.dialogSave}
          onRequestClose={this.handleClose}>

          NOTICE: There are still columns that need to be completed. Are you sure you want to continue? <br />
          <br />
          <Checkbox
            label='Do not show again'
            checked={this.props.appState.currentSetting.disableWarning}
            onCheck={this.updateWarningModal.bind(this)}
          />
        </Dialog>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  openDialog,
  closeDialog,
  addToColumnList,
  closeDialogSave,
  openDialogSave,
  disablePage,
  saved,
  storeWarningModal
};

const DialogSaveContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)
  (DialogSave);

export default DialogSaveContainer;
  