
import React from 'react';
import MenuComp from './MenuComp.jsx';
import MainCont from './MainContent.jsx';
import Logo from'./Logo.jsx';
import Support from './SupportButton.jsx'
import DisableComp from './DisableComp.jsx';
import Snackbar from 'material-ui/Snackbar';
import { connect } from 'react-redux'
import { addToColumnList, removeFromColumnList, alterColumnName, alterVersion } from '../redux/actions/columnActions.jsx';
import { goToColumn, goBack, hideSaveNotice, appView } from '../redux/actions/appActions.jsx';

class PaneWrapper extends React.Component {
  constructor(props) {
    super(props);
    this.handleRequestClose = this.handleRequestClose.bind(this)
  }

  handleRequestClose() {
    this.props.hideSaveNotice()
  }
  render() {
        return (
          <div id='parent'>
            <div className="center">{this.props.children}</div>
            <Snackbar
            className= "snackBar"
            open={this.props.appState.showSaveNotice}
            message={this.props.appState.snackBarMessage}
            autoHideDuration={4000}     
            onRequestClose={this.handleRequestClose}
            />
           </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => ({
  columnReducer: state.columnReducer,
  appState: state.appState,
  metricReducer: state.metricReducer
});

const mapDispatchToProps = {
  addToColumnList,
  alterColumnName,
  alterVersion,
  removeFromColumnList,
  goToColumn,
  hideSaveNotice,
  appView
};

const paneWrapperContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)
  (PaneWrapper);

export default paneWrapperContainer
 