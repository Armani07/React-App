import { connect } from 'react-redux'
import electron from 'electron';
import React, { Component } from 'react';
import DataTables from 'material-ui-datatables';
import { addToColumnList, removeFromColumnList, alterColumnName, alterVersion, columnHasUpdated } from '../redux/actions/columnActions.jsx';
import { goToColumn, goBack, updateRemoveList, appView, closeDialog, openDialog, currentColumn, updateTable, completedSort } from '../redux/actions/appActions.jsx';
import RightPane from './RightPane.jsx';
import MetricsPane from './MetricsPane.jsx';
import SettingsPane from './SettingsPane.jsx';
import HelpPane from './HelpPane.jsx';

const TABLE_COLUMNS = [
    {
        key: 'columnName',
        label: 'Name',
        sortable: true
    },
    {
        key: 'completedCheck',
        label: 'Completed',
        sortable: true
    }
];

var ipcRenderer = electron.ipcRenderer;
class LeftPane extends React.Component {
    constructor(prop) {
        super(prop);
        this.state = { page: 1, rowSize: this.props.appState.currentSetting.perPageSetting, rowSizeList: [10, 25, 50, 100, 200], sort: 'asc', filterText: '', removeColumnList: [], removeList: [], sortColumn: 'columnName' }
        this.handleCellDoubleClick = this.handleCellDoubleClick.bind(this)
        this.handleSelectedEvents = this.handleSelectedEvents.bind(this)
        this.handleRowSizeChange = this.handleRowSizeChange.bind(this)
        this.handleNextPageClick = this.handleNextPageClick.bind(this)
        this.handlePreviousPageClick = this.handlePreviousPageClick.bind(this)
        this.handleOnSortOrderChange = this.handleOnSortOrderChange.bind(this)
        this.handleOnFilterValueChange = this.handleOnFilterValueChange.bind(this)
    }
    static paneProps(props) {

        return {
            newTableDisabled: false,
            openDisabled: false,
            mergeDisabled: false,
            dartDisabled: false,
            sqlDisabled: false,
            settingsDisabled: false,
            helpDisabled: false,
            removeDisabled: (props.columnReducer.tableName !== '') ? false : true,
            addDisabled: (props.columnReducer.tableName !== '') ? false : true,
            saveDisabled: (props.columnReducer.tableName !== '') ? false : true,
        }
    }
    static clickBack(props) {
        props.popPane()
    }
    static clickAdd(props) {
        props.openDialog();
    }
    static clickRemove(props) {
        if (props.appState.listOfRemovals.length >= 1) {
            props.openRemoveDialog()
        }
    }
    static clickAddNewFile(props) {
        props.trelloRefresh();
        props.openDialogNewFile();
    }
    static clickOpen(props) {
        props.disablePage();
        props.saved();
        ipcRenderer.send('fetchFile', props.appState.currentSetting.savePath);
    }
    static clickSave(props) {
        if (props.appState.completedCount !== props.columnReducer.columnList.length && !props.appState.currentSetting.disableWarning) {
            props.openDialogSave();
        } else {
            props.disablePage();
            props.saved();
            ipcRenderer.send('sync', props.columnReducer.columnList, props.columnReducer.tableName, props.appState.currentSetting.savePath, props.appState.currentSetting.saveName);
        }
    }
    static clickMerge(props) {
        return (null)
    }
    static clickDart(props) {
        return (null)
    }
    static clickSQL(props){
        return (null)
      }  
    static clickSettings(props) {
        return (null)
    }
    static clickHelp(props) {
        return (null)
    }
    componentWillMount() {
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSize, 1, (this.props.appState.sortOrder === 1) ? 'asc' : 'desc', this.state.filterText, this.props.appState.sortColumn);
    }
    componentWillReceiveProps(nextProps) {

        if (nextProps.columnReducer.columnUpdated) {
            nextProps.columnHasUpdated();
            nextProps.updateTable(nextProps.columnReducer.columnList, this.state.rowSize, (nextProps.appState.index) ? ((Math.ceil(nextProps.appState.index / this.state.rowSize) === 0) ? 1 : Math.ceil(nextProps.appState.index / this.state.rowSize)) : nextProps.appState.page, (nextProps.appState.sortOrder === 1) ? 'asc' : 'desc', nextProps.appState.filterText, nextProps.appState.sortColumn);
            this.setState({ page: (nextProps.appState.index) ? Math.ceil(nextProps.appState.index / this.state.rowSize) : nextProps.appState.page });
        }
    }

    handleCellDoubleClick(row, column, event) {
        this.props.currentColumn(event);
        this.props.goToColumn(event.columnName);
        this.props.appView(RightPane, 'RightPane')
    }
    handleSelectedEvents(event) {
        var updatedColumns = [];
        var pageColumnList = this.props.appState.pagingColumnList;
        event.forEach(function (item, index) {
            updatedColumns.push(pageColumnList[item]);
        })
        this.props.updateRemoveList(event, updatedColumns);
        this.setState({ removeList: event, removeColumnList: updatedColumns });
    }
    handleRowSizeChange(newSize) {
        this.setState({ rowSize: this.state.rowSizeList[newSize] });
        this.setState({ page: 1 });
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSizeList[newSize], 1, (this.props.appState.sortOrder === 1) ? 'asc' : 'desc', this.props.appState.filterText, this.props.appState.sortColumn);
    }
    handleNextPageClick() {
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSize, this.state.page + 1, (this.props.appState.sortOrder === 1) ? 'asc' : 'desc', this.props.appState.filterText, this.props.appState.sortColumn);
        this.setState({ page: this.state.page + 1, removeList: [], removeColumnList: [] })
        this.props.updateRemoveList([], []);
    }
    handlePreviousPageClick(event) {
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSize, this.state.page - 1, (this.props.appState.sortOrder === 1) ? 'asc' : 'desc', this.props.appState.filterText, this.props.appState.sortColumn);
        this.setState({ page: this.state.page - 1, removeList: [], removeColumnList: [] })
        this.props.updateRemoveList([], []);
    }
    handleOnSortOrderChange(event, sort) {
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSize, 1, sort, this.props.appState.filterText, event); //here
        this.setState({ sort: sort, page: 1, sortColumn: event });
    }
    handleOnFilterValueChange(filterText, sort) {
        this.props.updateTable(this.props.columnReducer.columnList, this.state.rowSize, 1, (this.props.appState.sortOrder === 1) ? 'asc' : 'desc', filterText, this.props.appState.sortColumn)
        this.setState({ filterText: filterText })
    }
    render() {
        if (this.props.columnReducer.tableName === "") {
            return (null)
        } else {
            return (
                <div>           
                <DataTables
                    height={'auto'}
                    selectable={true}
                    showRowHover={true}
                    columns={TABLE_COLUMNS}
                    data={this.props.appState.pagingColumnList}
                    showCheckboxes={true}
                    onCellClick={this.handleCellClick}
                    onCellDoubleClick={this.handleCellDoubleClick}
                    onSortOrderChange={this.handleOnSortOrderChange}
                    page={this.state.page}
                    count={this.props.appState.storedColumnList.length}
                    onRowSelection={this.handleSelectedEvents}
                    multiSelectable={true}
                    selectedRows={this.props.appState.listOfRemovals}
                    rowSize={this.state.rowSize}
                    rowSizeList={this.state.rowSizeList}
                    onRowSizeChange={this.handleRowSizeChange}
                    onNextPageClick={this.handleNextPageClick}
                    onPreviousPageClick={this.handlePreviousPageClick}
                    nextButtonDisabled={false}
                    initialSort={{ column: this.props.appState.sortColumn, order: (this.props.appState.sortOrder === 1) ? 'asc' : 'desc' }}
                    showHeaderToolbar={true}
                    title={this.props.columnReducer.tableName}
                    onFilterValueChange={this.handleOnFilterValueChange}
                    stripedRows={this.props.appState.currentSetting.stripedColUser}
                    headerToolbarMode={this.props.appState.currentSetting.searchFilterUser ? 'filter' : 'default'}
                    showHeaderToolbarFilterIcon={true}
                    filterValue={this.props.appState.filterText}
                />
                <f2>{this.state.page}</f2>
                </div>            
            );
        }
    }
}

const mapStateToProps = (state, ownProps) => ({
    columnReducer: state.columnReducer,
    appState: state.appState,
    metricReducer: state.metricReducer
});

const mapDispatchToProps = {
    addToColumnList,
    alterColumnName,
    alterVersion,
    removeFromColumnList,
    goToColumn,
    updateRemoveList,
    currentColumn,
    updateTable,
    columnHasUpdated,
    completedSort,
    appView
};

const LeftPaneContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(LeftPane);

export default LeftPaneContainer; 
