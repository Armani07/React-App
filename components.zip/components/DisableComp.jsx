import React from 'react';
import { connect } from 'react-redux';
import { disablePage } from '../redux/actions/appActions.jsx';
import combinedReducers from '../redux/combinedReducers.jsx';

class DisableComp extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    if (this.props.appState.disablePage) {
      return (
        <div className='overlay' style={{
          position: 'fixed',
          bottom: '0',
          left: '0',
          background: 'lightgray',
          width: '100%'
        }}>
        <div className="load">
            <div className="gear one">
              <svg id="green" viewBox="0 0 100 100" fill="#28B463">
                <path d="M97.6,55.7V44.3l-13.6-2.9c-0.8-3.3-2.1-6.4-3.9-9.3l7.6-11.7l-8-8L67.9,20c-2.9-1.7-6-3.1-9.3-3.9L55.7,2.4H44.3l-2.9,13.6      
                c-3.3,0.8-6.4,2.1-9.3,3.9l-11.7-7.6l-8,8L20,32.1c-1.7,2.9-3.1,6-3.9,9.3L2.4,44.3v11.4l13.6,2.9c0.8,3.3,2.1,6.4,3.9,9.3      
                l-7.6,11.7l8,8L32.1,80c2.9,1.7,6,3.1,9.3,3.9l2.9,13.6h11.4l2.9-13.6c3.3-0.8,6.4-2.1,9.3-3.9l11.7,7.6l8-8L80,67.9      
                c1.7-2.9,3.1-6,3.9-9.3L97.6,55.7z M50,65.6c-8.7,0-15.6-7-15.6-15.6s7-15.6,15.6-15.6s15.6,7,15.6,15.6S58.7,65.6,50,65.6z">
                </path>
              </svg>
            </div>
            <div className="gear two">
              <svg id="blue" viewBox="0 0 100 100" fill="#21618C">
                <path d="M97.6,55.7V44.3l-13.6-2.9c-0.8-3.3-2.1-6.4-3.9-9.3l7.6-11.7l-8-8L67.9,20c-2.9-1.7-6-3.1-9.3-3.9L55.7,2.4H44.3l-2.9,13.6      
                c-3.3,0.8-6.4,2.1-9.3,3.9l-11.7-7.6l-8,8L20,32.1c-1.7,2.9-3.1,6-3.9,9.3L2.4,44.3v11.4l13.6,2.9c0.8,3.3,2.1,6.4,3.9,9.3      
                l-7.6,11.7l8,8L32.1,80c2.9,1.7,6,3.1,9.3,3.9l2.9,13.6h11.4l2.9-13.6c3.3-0.8,6.4-2.1,9.3-3.9l11.7,7.6l8-8L80,67.9      
                c1.7-2.9,3.1-6,3.9-9.3L97.6,55.7z M50,65.6c-8.7,0-15.6-7-15.6-15.6s7-15.6,15.6-15.6s15.6,7,15.6,15.6S58.7,65.6,50,65.6z">
                </path>
              </svg>
            </div>
            <div className="gear three">
              <svg id="red" viewBox="0 0 100 100" fill="#CB4335">
                <path d="M97.6,55.7V44.3l-13.6-2.9c-0.8-3.3-2.1-6.4-3.9-9.3l7.6-11.7l-8-8L67.9,20c-2.9-1.7-6-3.1-9.3-3.9L55.7,2.4H44.3l-2.9,13.6      
                c-3.3,0.8-6.4,2.1-9.3,3.9l-11.7-7.6l-8,8L20,32.1c-1.7,2.9-3.1,6-3.9,9.3L2.4,44.3v11.4l13.6,2.9c0.8,3.3,2.1,6.4,3.9,9.3      
                l-7.6,11.7l8,8L32.1,80c2.9,1.7,6,3.1,9.3,3.9l2.9,13.6h11.4l2.9-13.6c3.3-0.8,6.4-2.1,9.3-3.9l11.7,7.6l8-8L80,67.9      
                c1.7-2.9,3.1-6,3.9-9.3L97.6,55.7z M50,65.6c-8.7,0-15.6-7-15.6-15.6s7-15.6,15.6-15.6s15.6,7,15.6,15.6S58.7,65.6,50,65.6z">
                </path>
              </svg>
            </div>
            <div className="lil-circle"></div>
            <svg className="blur-circle">
              <filter id="blur">
                <fegaussianblur in="SourceGraphic" stdDeviation="13"></fegaussianblur>
              </filter>
              <circle cx="70" cy="70" r="66" fill="transparent" stroke="white" strokeWidth="40" filter="url(#blur)"></circle>
            </svg>
          </div>
          <div className="text">Processing, Please Wait...</div>
        </div>
      );
    }
    else {
      return (
        <div style={{
          position: 'fixed',
          bottom: '0',
          left: '0',
          background: 'lightgray',
          width: '100%'
        }}></div>
      );
    }
  }
}

const mapStateToProps = (state, ownProps) => ({
  appState: state.appState
});

const mapDispatchToProps = {
};

const DisableCompContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(DisableComp);

export default DisableCompContainer;