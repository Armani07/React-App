const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');

var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});

global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});

describe('Test Help Pane functionality', function () {
    this.timeout(100000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('opens a window', function () {
        return app.client.waitUntilWindowLoaded().pause(500)
            .getWindowCount().should.eventually.equal(1);
    });
    it('tests the title', function () {
        return app.browserWindow.getTitle().should
            .eventually.equal('Visual Database Assurer');
    });
    it('Going Help Pane', function () {
        return app.client
            .element('//*[contains(@title,"Help")]').click();
    })
    it('Test Menu Help dropdown', function () {
        return app.client
            .element('//*[contains(@id,"menuHelp")]').click()
            .element('//*[contains(@id,"menuHelpText")]').getText()
            .element('//*[contains(@id,"menuHelp")]').click();
    });
    it('Test create Table dropdown', function () {
        return app.client
            .element('//*[contains(@id,"createTableHelp")]').click()
            .element('//*[contains(@id,"createTableHelpText")]').getText()
            .element('//*[contains(@id,"createTableHelp")]').click();
    });
    it('Test column workspace dropdown', function () {
        return app.client
            .element('//*[contains(@id,"columnWorkSpaceHelp")]').click()
            .element('//*[contains(@id,"columnWorkSpaceHelpText")]').getText()
            .element('//*[contains(@id,"columnWorkSpaceHelp")]').click();
    });
    it('Test Merge Help dropdown', function () {
        return app.client
            .element('//*[contains(@id,"mergeHelp")]').click()
            .element('//*[contains(@id,"mergeHelpText")]').getText()
            .element('//*[contains(@id,"mergeHelp")]').click();
    });
    it('Test settings help dropdown', function () {
        return app.client
            .element('//*[contains(@id,"settingsHelp")]').click()
            .element('//*[contains(@id,"settingsHelpText")]').getText()
            .element('//*[contains(@id,"settingsHelp")]').click();
    });
    it('Test Back Button', function () {
        return app.client
            .element('//*[contains(@id,"backButton")]').click();
    });
    it('Test Back Button', function () {
        return browser.url('http://webdriver.io');
    });
});