const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');

var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});

global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});


describe('Test Adding Column functionality', function () {
    this.timeout(100000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500)
            .element('//*[contains(@id,"saveButton")]').click().pause(1000)
            .element('//*[contains(@title,"Go Back")]').click();
    });
    it('Test DartPane Button', function () {
        return app.client
            .element('//*[contains(@title,"Open DART")]').click().pause(100)
    });
    it('Test CUID text box', function () {
        return app.client
            .element('//*[contains(@id,"txtCUID")]').click()
            .element('//*[contains(@id,"txtCUID")]').addValue(123)
    });
    it('Test Mirror ID checkbox', function () {
        return app.client
            .element('//*[contains(@id,"chkMirrorId")]').click().pause(100)
    });
    it('Mirror ID text box', function () {
        return app.client
            .element('//*[contains(@id,"txtMirrorId")]').click()
            .element('//*[contains(@id,"txtMirrorId")]').addValue(123)
    });
    it('Test database name text box', function () {
        return app.client
            .element('//*[contains(@id,"txtDatabaseName")]').click()
            .element('//*[contains(@id,"txtDatabaseName")]').addValue(123)
    });
    it('Test Generate Button', function () {
        return app.client
            .element('//*[contains(@id,"btnGenerate")]').click().pause(100)
    });
        it('Test back Button', function () {
        return app.client
            .element('//*[contains(@title,"Go Back")]').click().pause(100)
    });
});