const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');

var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});

global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});


describe('Test Adding Column functionality', function () {
    this.timeout(100000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
    it('Turn on AutoSave', function () {
        return app.client
            .element('//*[contains(@title,"Settings")]').click().pause(100)
            .element('//*[contains(@id,"columnSettings")]').click().pause(100)
            .element('//*[contains(@id,"autoSave")]').click().pause(100)
            .element('//*[contains(@id,"disableIncomplete")]').click().pause(100)
            .element('//*[contains(@id,"saveButton")]').click().pause(1000)
            .element('//*[contains(@title,"Go Back")]').click();
    });
        it('Create New Table', function () {
        return app.client
            .element('//*[contains(@title,"Create New Table")]').click()
            .element('//*[contains(@name,"Table Name")]').addValue(123)
            .element('//*[contains(@id,"submit")]').click().pause(500);
    });
    it('Add Column', function () {
        return app.client
            .element('//*[contains(@title,"Add Column(s)")]').click()
            .element('//*[contains(@id,"single")]').click()
            .waitForVisible('//*[contains(@name,"Column Name")]', 10000)
            .waitForVisible('//*[contains(@id,"submitName")]', 10000)
            .element('//*[contains(@name,"Column Name")]').addValue("Caleb")
            .element('//*[contains(@id,"submitName")]').click().pause(5000);
    });
    it('AutoSave', function () {
        return app.client
            .element('//*[contains(@title,"Save Table")]').click().pause(5000)
            .element('//*[contains(text(),"Yes")]').click().pause(20000)
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
});