const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');
var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});
global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});
describe('Test Settings functionality', function () {
    this.timeout(100000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('opens a window', function () {
        return app.client.waitUntilWindowLoaded(20000).pause(10000)
            .getWindowCount().should.eventually.equal(1);
    });
        it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
    it('tests the title', function () {
        return app.browserWindow.getTitle().should
            .eventually.equal('Visual Database Assurer');
    });
    it('Going Settings Pane', function () {
        return app.client
            .element('//*[contains(@title,"Settings")]').click();
    });
    it('Test Trello dropdown ', function () {
        return app.client
            .element('//*[contains(@id,"trelloDropdown")]').click()
    });
    it('Test Column Table Settings Dropdown and functions', function () {
        return app.client
            .element('//*[contains(@id,"columnSettings")]').click()
            .element('//*[contains(@id,"disableMetric")]').click().pause(100)
            .element('//*[contains(@id,"disableIncomplete")]').click().pause(100)
            .element('//*[contains(@id,"autoSave")]').click().pause(100)
            .element('//*[contains(@id,"autoUppercase")]').click().pause(100)
            .element('//*[contains(@id,"stripedColumnRows")]').click().pause(100)
            .element('//*[contains(@id,"searchFilter")]').click().pause(100)
            .element('//*[contains(@id,"completeReturn")]').click().pause(100);
    });
    it('Test File Settings', function () {
        return app.client
            .element('//*[contains(@id,"fileSettings")]').click()
            .element('//*[contains(@id,"fileSettings")]').click();
    });
    it('Test Phrases', function () {
        return app.client
            .element('//*[contains(@id,"phrases")]').click()
            .element('//*[contains(@id,"phrasesInsert")]').addValue('red fire')
            .element('//*[contains(@id,"phrasesSubmit")]').click()
            .element('//*[contains(@name,"0-cb")]').click().pause(1000)
            .element('//*[contains(@id,"phrasesRemove")]').click();
    });
    it('Select Work Space', function () {
        return app.client
            .element('//*[contains(@id,"appSettings")]').click()
            .element('//*[contains(@id,"workspaceType")]').click()
            .element('//*[contains(text(),"Visual Oracle Data Scrubbing")]').click().pause(1000);
    });
    it('Test Save Button', function () {
        return app.client
            .element('//*[contains(@id,"saveButton")]').click().pause(1000)
    });
    it('Test Back Button', function () {
        return app.client
            .element('//*[contains(@title,"Go Back")]').click();
    });
        it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
});