const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');
var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});
global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});
describe('Test Trello functionality', function () {
    this.timeout(1000000000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Application Running')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });

    it('Opening a window', function () {
        return app.client.waitUntilWindowLoaded().pause(500)
            .getWindowCount().should.eventually.equal(1);
    });
    it('Testing the title', function () {
        return app.browserWindow.getTitle().should
            .eventually.equal('Visual Database Assurer');
    });
    it('Going to Settings Pane', function () {
        return app.client
            .element('//*[contains(@title,"Settings")]').click();
    });
    it('Testing Trello Dropdown ', function () {
        return app.client
            .element('//*[contains(@id,"trelloDropdown")]').click()
            .element('//*[contains(@id,"trelloLogin")]').click().pause(20000);
    });
    it('Loging in to Trello', function () {
        return app.client.windowByIndex(1)
            .element('//*[contains(@value, "Allow")]').click().pause(5000);
    });
    it('Selecting a Board', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@id, "trelloBoardSelect")]').click().pause(2000)
            .element('//*[contains(text(), "Fenway App Development")]').click().pause(2000);
    });
    it('Selecting a List', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@id, "trelloListSelect")]').click().pause(2000)
            .element('//*[contains(text(), "Mocha Tests 1")]').click().pause(2000);
    });
    it('Selecting a "Move To" List', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@id, "trelloMoveToSelect")]').click().pause(2000)
            .element('//*[contains(text(), "Mocha Tests 2")]').click().pause(3000);
    });
    it('Test Trello Blank Fill ', function () {
        return app.client
            .element('//*[contains(@id, "trelloBoardSelect")]').click()
            .element('//*[contains(text(), "Welcome Board")]').click().pause(1000)
            .element('//*[contains(text(), "Save")]').click().pause(2000);
    });
    it('Testing Back Button', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Go Back")]').click().pause(2000);
    });
    it('Making Table from Trello Card, Check Trello to ensure Card Moved', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Create New Table")]').click().pause(1000)
            .element('//*[contains(@id, "selectTrelloCards")]').click().pause(3000)
            .element('//*[contains(text(), "Some Day Love")]').click().pause(2000)
            .element('//*[contains(@id,"submit")]').click().pause(1000);
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(1000)
            .element('//*[contains(text(), "Yes")]').click().pause(1000);
    });
});