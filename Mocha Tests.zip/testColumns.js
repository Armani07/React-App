const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');

var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});

global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});


describe('Test Adding Column functionality', function () {
    this.timeout(100000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
    it('opens a window', function () {
        return app.client.waitUntilWindowLoaded().pause(500)
            .getWindowCount().should.eventually.equal(1);
    });
    it('tests the title', function () {
        return app.browserWindow.getTitle().should
            .eventually.equal('Visual Database Assurer');
    });
    it('Create New Table', function () {
        return app.client
            .element('//*[contains(@title,"Create New Table")]').click()
            .element('//*[contains(@name,"Table Name")]').addValue(123)
            .element('//*[contains(@id,"submit")]').click().pause(500);
    });
    it('Add Column', function () {
        return app.client
            .element('//*[contains(@title,"Add Column(s)")]').click()
            .waitForVisible('//*[contains(@name,"Column Name")]', 10000)
            .waitForVisible('//*[contains(@id,"submitName")]', 10000)
            .element('//*[contains(@name,"Column Name")]').addValue("Caleb")
            .element('//*[contains(@id,"submitName")]').click().pause(5000);
    });
    it('Add Complex Column', function () {
        return app.client
            .waitForVisible('//*[contains(@title,"Add Column(s)")]', 10000)
            .element('//*[contains(@title,"Add Column(s)")]').click()
            .waitForVisible('//*[contains(@name,"Column Name")]', 10000)
            .element('//*[contains(@name,"Column Name")]').addValue("Alicia CHAR(20) Yes")
            .waitForVisible('//*[contains(@id,"submitName")]', 10000)
            .element('//*[contains(@id,"submitName")]').click();
    });
    it('Going into a Column', function () {
        return app.client
            .waitForVisible('//*[contains(text(),"Caleb")]', 10000)
            .element('//*[contains(text(),"Caleb")]').click()
            .element('//*[contains(text(),"Caleb")]').click().pause(10000)
            .waitForVisible('//*[contains(@title,"Go Back")]', 10000)
            .element('//*[contains(@title,"Go Back")]').click()
            .waitForVisible('//*[contains(text(),"Alicia")]', 10000)
            .element('//*[contains(text(),"Alicia")]').click()
            .element('//*[contains(text(),"Alicia")]').click().pause(10000)          
            .element('//*[contains(@id,"completeButton")]').click().pause(1000)  
            .waitForVisible('//*[contains(@title,"Go Back")]', 10000)
            .element('//*[contains(@title,"Go Back")]').click()
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
});