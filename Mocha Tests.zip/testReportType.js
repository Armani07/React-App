const Application = require('spectron').Application;
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const assert = require('assert');
var electronPath = require('electron');
var appPath = path.join(__dirname, '../');
var app = new Application({
    path: electronPath,
    args: [appPath],
    startTimeout: 20000
});
global.before(function () {
    chai.should();
    chai.use(chaiAsPromised);
});
describe('Testing Report Type Functionality', function () {
    this.timeout(1000000000);
    before(function () {
        console.log('Starting Application...')
        return app.start().then(function () {
            console.log('Started Application')
            assert.equal(app.isRunning(), true);
            chaiAsPromised.transferPromiseness = app.transferPromiseness;
            return app;
        });
    });
    after(function () {
        console.log('Closing Application...')
        return app.stop();
    });
    it('Opening a Window', function () {
        return app.client.waitUntilWindowLoaded().pause(500)
            .getWindowCount().should.eventually.equal(1);
    });
    it('Testing the Title', function () {
        return app.browserWindow.getTitle().should
            .eventually.equal('Visual Database Assurer');
    });
    it('Resetting for this Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
    it('Changing the Report Type', function () {
        return app.client
        .element('//*[contains(@title,"Settings")]').click().pause(500)
        .element('//*[contains(text(),"Reports")]').click().pause(500)
        .element('//*[contains(@id, "workspaceType")]').click().pause(2000)
        .element('//*[contains(text(),"Oracle Automation")]').click().pause(2000)
        .element('//*[contains(text(), "Save")]').click().pause(500)
        .element('//*[contains(@title,"Go Back")]').click().pause(1000);
    });
    it('Create New Table', function () {
        return app.client
            .element('//*[contains(@title,"Create New Table")]').click()
            .element('//*[contains(@name,"Table Name")]').addValue(123)
            .element('//*[contains(@id,"submit")]').click().pause(10000);
    });
    it('Resetting for the Next Test', function () {
        return app.client.windowByIndex(0)
            .element('//*[contains(@title,"Settings")]').click()
            .element('//*[contains(text(), "Reset to Default")]').click().pause(500)
            .element('//*[contains(text(), "Yes")]').click().pause(500);
    });
});