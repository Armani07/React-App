import {combineReducers} from 'redux';
import columnReducer from "./reducers/columnReducer.jsx";
import appState from "./reducers/appReducer.jsx";
import metricReducer from "./reducers/metricReducer.jsx";
import oracleState from "./reducers/oracleReducer.jsx";
import qaState from "./reducers/qaReducer.jsx";
export default combineReducers({
    columnReducer,
    appState,
    metricReducer,
    oracleState,
    qaState
})