const initialState = {
  metricsList: [],
  metricsRemoveList: [],
  updatedMetricList: [],
  metricUpdated: false,
  metricError: false,
  duplicate: []
}

function metricsList(state = initialState, action) {
  switch (action.type) {
    case 'ADD_METRIC':
      //for loop for making it work here
      var array = state.metricsList 
      var variable = false

      var lucario =false
      var storeDuplicate = []
      
      for (var i = 0; i < action.metricName.length; i++) {
        for (var j = 0; j < state.metricsList.length; j++) {
         
          if (action.metricName[i].metricName === state.metricsList[j].metricName) {

            variable = true 
            lucario = true
             storeDuplicate.push( action.metricName[i].metricName)
          }
        }
      if(!lucario){ array.push(action.metricName[i])
      }
      lucario = false         
      }
      
      return {
        ...state,
        metricsList: array,
        metricUpdated: true,
        metricError:variable,
        duplicate:storeDuplicate 
      }
    case 'METRIC_HAS_UPDATED':
      return {
        ...state,
        metricUpdated: false
      }
    default:
      return state
    case 'UPDATE_METRIC_REMOVE_LIST':
      return { 
        ...state,
        metricsRemoveList: action.removeMetrics,
        updatedMetricList: action.metricsList
      }
    case 'METRICS_RESET':
      return {
        metricsList: [],
        metricsRemoveList: [],
        updatedMetricList: [],
        metricUpdated: false
      }
    case 'REMOVE_METRICS':
      return {
        ...state,
        metricsRemoveList: [],
        updatedMetricList: [],
        metricUpdated: true,
        metricsList: state.metricsList.filter((metric, index) => {
          var removeIt = true;
          state.updatedMetricList.forEach(function (removeMetric, index) {
            if (metric.metricName === removeMetric.metricName) {
              removeIt = false
            }
          })
          return removeIt
        })
      }
  }
};
export default metricsList;