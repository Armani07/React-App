const initialState = {
    columnList: [],
    columnUpdated: false,
    workingSet: '',
    page: 1,
    sortingColumnList: [],
};

function qaState(state = initialState, action) {
    switch (action.type) {

        case 'NEW_QA_TABLE':
            return {
                columnList: [],
                columnUpdated: true,
                workingSet: action.workingSet
            }
        case 'ADD_QA_COLUMN':
            return {
                ...state,
                columnList: [
                    ...state.columnList,
                    {
                        appName: action.column.appName,
                        acronym: action.column.acronym,
                        q1: action.column.q1,
                        q2:action.column.q2,
                        q3: action.column.q3,
                        q4: action.column.q4,
                        q5: action.column.q5,
                        q6: action.column.q6,
                        q7: action.column.q7,
                        q8: action.column.q8,
                        question: action.column.question,
                        comments: action.column.comments,
                        loadDate: action.column.loadDate,
                        completed: action.column.completed,
                        id: action.id
                    }],
                columnUpdated: true
            }
        case 'QA_COLUMN_NEEDS_UPDATED':
            return {
                ...state,
                columnUpdated: true
            }
        case 'QA_ALTER_COLUMN_NAME':
            return {
                ...state,
                columnList: state.columnList.map((columns) => {
                    if (columns.id === action.id) {
                        return Object.assign({}, columns, {
                            columnName: action.columnName
                        })
                    }
                    return columns
                })
            }
        case 'QA_REMOVE_COLUMN':
            var filtering = state.columnList.filter((column, index) => {
                var removeIt = true;
                action.columnPositions.forEach(function (removeColumn, index) {
                    if (column.id === removeColumn.id) {
                        removeIt = false
                    }
                })
                return removeIt
            })
            return {
                ...state,
                columnUpdated: true,
                columnList: filtering
            }
        case 'QA_IS_COMPLETED':
            return {
                ...state,
                completed: !state.completed //switch the state of object to completed:true, Column in the left pane table should contain a checkmark
            }
        case 'QA_IS_UNCOMPLETED':
            return {
                ...state,
                completed: false //switch the state of object to completed:false, no checkmark should appear in Left pane table
            }
        case 'QA_COLUMNS_LOAD':
            return {
                ...state,
                columnList: action.columns,
                columnUpdated: true,
                workingSet: action.workingSet
            }
        case 'QA_SAVE_COLUMN':
            return {
                ...state,
                columnUpdated: true,
                columnList: state.columnList.map((column) => {
                    if (column.id === action.column.id) {
                        return action.column
                    }
                    return column
                })
            }
        case 'UPDATE_QA_TABLE':
            var page = action.pageNumber;
            var list = action.columns;
            var perPage = action.perPage;
            var end = perPage * page;
            var start = end - perPage;
            var sort = (action.sort === 'asc') ? 1 : -1;
            list = list.filter((column) => {
                if (action.filterText === '' || action.filterText === null) {
                    return true;
                }
                return column.appName.toLowerCase().includes(action.filterText.toLowerCase());
            }).sort((a, b) => {
                var aSort, bSort;
                switch (action.sortColumn) {
                    case 'appName':
                        aSort = a.appName.toLowerCase();
                        bSort = b.appName.toLowerCase();
                        break;
                    case 'completedCheck':
                        aSort = a.completed;
                        bSort = b.completed;
                        break;
                }
                if (aSort < bSort) {
                    return -1 * sort;
                } else if (aSort > bSort) {
                    return 1 * sort;
                }
                return 0;
            })
            return {
                ...state,
                sortOrder: sort,
                sortColumn: action.sortColumn,
                storedColumnList: list,
                filterText: action.filterText,
                sortingColumnList: list.slice(start, end),
                page: action.pageNumber,

            }
        case 'QA_COLUMN_HAS_UPDATED':
            return {
                ...state,
                columnUpdated: false
            }
        default:
            return state
    }
};
export default qaState;