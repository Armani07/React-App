const initialState = {
    paneArray: [],
    version: 1,
    view: 'home',
    previousView: 'home',
    backDisabled: true,
    addDisabled: true,
    saveDisabled: true,
    removeDisabled: false,
    fileDisabled: false,
    mergeDisabled: false,
    columnName: null,
    addDialog: false,
    removeDialog: false,
    removeOracleDialog: false,
    metricDialog: false,
    removeList: [],
    updatedColumnsPhrases: [],
    listOfRemovalsPhrases: [],
    completed: false,
    storedColumn: null,
    storedColumnList: [],
    pagingColumnList: [],
    listOfRemovals: [],
    completedCheck: false,
    updatedColumns: [],
    multiDialog: false,
    showSaveNotice: false,
    newFileDialog: false,
    dialogSave: false,
    okaySave: false,
    newMetricDialog: false,
    dialogColumn: false,
    sortOrder: 1,
    token: '',
    completedOrder: null,
    filterText: '',
    sortColumn: 'columnName',
    completedCount: 0,
    setting: false,
    metricsPane: false,
    HelpPane: false,
    SupportPane: false,
    page: 1,
    index: null,
    boards: null,
    cardDropDownRefresh: false,
    disablePage: false,
    saved: false,
    loadMainContent: null,
    settingsDialog: false,
    defaultPrompt: false,
    needsFileUpdate: false,
    snackBarMessage: "",
    trelloRefresh: false,
    validationPane: false,
    sameNameDialog: false,
    errorModal: false,
    errorMessage: '',
    removeQADialog: false,
    oracleDialogOpen: false,
    currentSetting: { completeReturn: false, searchFilterUser: false, perPageSetting: 10, stripedColUser: false, screenSizeSetting: 'Full Screen', savePath: null, uppercase: false, saveName: false, openPath: null, disableWarning: false, disableWarning2: false, commonPhrases: [], commonPhrasesTheArray: [], board: 'blank', list: 'blank', card: 'blank', cardMove: 'blank', workspace: '' },
    newSetting: { completeReturn: false, searchFilterUser: false, perPageSetting: 10, stripedColUser: false, screenSizeSetting: 'Full Screen', savePath: null, uppercase: false, saveName: false, openPath: null, disableWarning: false, disableWarning2: false, commonPhrases: [], commonPhrasesTheArray: [], board: 'blank', list: 'blank', card: 'blank', cardMove: 'blank', workspace: '' },
    defaultSetting: { completeReturn: false, searchFilterUser: false, perPageSetting: 10, stripedColUser: false, screenSizeSetting: 'Full Screen', savePath: null, uppercase: false, saveName: false, openPath: null, disableWarning: false, disableWarning2: false, commonPhrases: [], commonPhrasesTheArray: [], board: 'blank', list: 'blank', card: 'blank', cardMove: 'blank', workspace: 'Visual Oracle Data Scrubbing' },
    sameFileDialog: false,
    oraclePane: false,
    SQLGeneratorPane: false,
    addValidationOpen: false,
    databaseName: '',
    cuid: '',
    mirrorId: '',
    dialogCopy: false,
    event: '',
    copyText: ''
};

function appState(state = initialState, action) {
    switch (action.type) {
        case 'TEXT_CHANGE':
            return {
                ...state,
                event: action.text
            }
        case 'OPEN_DIALOG_COPY':
            return {
                ...state,
                dialogCopy: (state.dialogCopy) ? false : true,
                event: action.event
            }
        case 'OPEN_ADD_VALDIATION':
            return {
                ...state,
                addValidationOpen: true
            }
        case 'CLOSE_ADD_VALDIATION':
            return {
                ...state,
                addValidationOpen: false
            }

        case 'ORACLE_OPEN_ADD':
            return {
                ...state,
                oracleDialogOpen: true
            }
        case 'LOAD_WORK_SPACE':
            return {
                ...state,
                newSetting: { ...state.newSetting, workspace: action.object },
            }
        case 'ORACLE_CLOSE_ADD':
            return {
                ...state,
                oracleDialogOpen: false

            }
        case 'CLOSE_NEW_ORACLE':
            return {
                ...state,
                oraclePane: false
            }

        case 'OPEN_NEW_ORACLE':
            return {
                ...state,
                oraclePane: true
            }
        case 'CLOSE_NEW_APP':
            return {
                ...state,
                validationPane: false
            }

        case 'OPEN_NEW_APP':
            return {
                ...state,
                validationPane: true
            }

        case 'ERROR_MODAL_TRUE':
            return {
                ...state,
                errorModal: true,
                errorMessage: action.error

            }
        case 'ERROR_MODAL_FALSE':
            return {
                ...state,
                errorModal: false
            }
        case 'STORE_PANE':
            array = state.paneArray

            array.push({ pane: action.pane, paneName: action.paneName })

            return {
                ...state,
                paneArray: array,
                refreshProps: true,
            }
        case 'PROPS_REFRESHED':
            return {
                ...state,
                refreshProps: false
            }

        case "POP_PANE":
            array = state.paneArray
            array.pop()

            return {
                ...state,
                paneArray: array,
                refreshProps: true
            }
        case "POP_SETTINGS_PANE":
            var array = action.paneArray
            array.pop()
            return {
                ...state,
                paneArray: array,
                refreshProps: true
            }
        case "CLEAR_DAR":
            return {
                ...state,
                databaseName: '',
                cuid: '',
                mirrorId: ''
            }
        case 'SAVED':
            return {
                ...state,
                addDisabled: false,
                saved: (state.saved) ? false : true
            }
        case 'STORE_BOARDS':
            return {
                ...state,
                boards: action.boards
            }
        case 'FILES_HAVE_UPDATED':
            return {
                ...state,
                needsFileUpdate: false
            }
        case 'BOARD_ID':
            return {
                ...state,
                newSetting: { ...state.newSetting, board: action.id, move: 'blank' },
            }
        case 'STORE_LISTS':
            return {
                ...state,
                lists: action.lists
            }
        case 'STORE_MOVE':
            return {
                ...state,
                move: action.move
            }
        case 'MOVE_ID':
            return {
                ...state,
                newSetting: { ...state.newSetting, move: action.id },
            }
        case 'STORE_MAKE_CARD':
            return {
                ...state,
                makeCard: action.makeCard
            }
        case 'MAKE_CARD_ID':
            return {
                ...state,
                newSetting: { ...state.newSetting, makeCard: action.id },
            }
        case 'CLEAR_CARD':
            return {
                ...state,
                card: null
            }
        case 'LIST_ID':
            return {
                ...state,
                newSetting: { ...state.newSetting, list: action.id },
            }
        case 'CARD_REFRESHED':
            return {
                ...state,
                cardDropDownRefresh: true
            }
        case 'STORE_CARDS':
            return {
                ...state,
                cards: action.cards
            }
        case 'CARD_ID':
            return {
                ...state,
                card: action.id
            }
        case 'STORE_TRELLO_KEY':
            return {
                ...state,
                token: action.trelloKey
            }
        case 'TRELLO_REFRESH':
            return {
                ...state,
                trelloRefresh: true
            }
        case 'FALSE_TRELLO_REFRESH':
            return {
                ...state,
                trelloRefresh: false
            }
        case 'ADD_COMMON_PHRASE':
            if (state.newSetting.commonPhrases === null) {
            }
            var array = state.newSetting.commonPhrases
            var array2 = state.newSetting.commonPhrasesTheArray
            array.push({ commonPhrase: action.input })
            array2.push(action.input)
            return {
                ...state,
                newSetting: { ...state.newSetting, commonPhrases: array, commonPhrasesTheArray: array2 }
            }
        case 'LOAD_USER_SETTINGS':
            return {
                ...state,
                currentSetting: action.input
            }
        case 'REMOVE_PHRASES':
            return {
                ...state,
                newSetting: {
                    ...state.newSetting, commonPhrases: state.newSetting.commonPhrases.filter((phrase, index) => {
                        var removeIt = true;

                        action.phrasePosition.forEach(function (removePhrase, index) {
                            if (phrase.commonPhrase === removePhrase.commonPhrase) {
                                removeIt = false
                            }
                        })
                        return removeIt
                    }), commonPhrasesTheArray: state.newSetting.commonPhrasesTheArray.filter((phrase, index) => {
                        var removeIt = true;
                        action.phrasePosition.forEach(function (removePhrase, index) {

                            if (phrase === removePhrase.commonPhrase) {
                                removeIt = false
                            }
                        })
                        return removeIt
                    })
                }
            }
        case 'goToColumn':
            return {
                ...state,
                version: 1,
                view: 'column',
                disabled: true,
                backDisabled: false,
                addDisabled: true,
                saveDisabled: true,
                removeDisabled: true,
                fileDisabled: true,
                columnName: action.selected,
                index: null,
                previousView: state.view,
            }
        case 'DISABLE_DIALOG':
            return {
                ...state,
                currentSetting: { ...state.currentSetting, disableWarning: action.input },
                newSetting: { ...state.newSetting, disableWarning: action.input }
            }
        case 'OPEN_DIALOG_SAVE':
            return {
                ...state,
                dialogSave: true,
            }
        case 'OPEN_DIALOG_COLUMN':
            return {
                ...state,
                dialogColumn: true,
            }
        case 'IMPORT_PHRASES':
            return {
                ...state,
                newSetting: { ...state.newSetting, commonPhrasesTheArray: action.importPhrasesArray, commonPhrases: action.importPhrases }
            }
        case 'METRIC_DIALOG':
            return {
                ...state,
                metricDialog: true
            }
        case 'METRIC_CLOSE':
            return {
                ...state,
                metricDialog: false
            }
        case 'OPEN_NEW_METRIC_DIALOG':
            return {
                ...state,
                newMetricDialog: true
            }
        case 'CLOSE_NEW_METRIC_DIALOG':
            return {
                ...state,
                newMetricDialog: false
            }
        case 'OPEN_SAME_FILE_DIALOG':
            return {
                ...state,
                sameFileDialog: true
            }
        case 'CLOSE_SAME_FILE_DIALOG':
            return {
                ...state,
                sameFileDialog: false
            }
        case 'SAVE_PATH':
            return {
                ...state,
                newSetting: { ...state.newSetting, savePath: action.path }
            }
        case 'STORE_SAVE_SETTING':
            return {
                ...state,
                newSetting: { ...state.newSetting, saveName: action.saveSetting }
            }
        case 'COMPLETE_RETURN':
            return {
                ...state,
                newSetting: { ...state.newSetting, completeReturn: action.completeReturn }
            }
        case 'STORE_WARNING_SETTING':
            return {
                ...state,
                newSetting: { ...state.newSetting, disableWarning: action.disableWarning }
            }
        case 'STORE_WARNING_SETTING2':
            return {
                ...state,
                newSetting: { ...state.newSetting, disableWarning2: action.disableWarning2 }
            }
        case 'STORE_WARNING_MODAL':
            return {
                ...state,
                currentSetting: { ...state.currentSetting, disableWarning: action.disableWarning }
            }
        case 'STORE_WARNING_MODAL2':
            return {
                ...state,
                currentSetting: { ...state.currentSetting, disableWarning2: action.disableWarning2 }
            }
        case 'OPEN_PATH':
            return {
                ...state,
                newSetting: { ...state.newSetting, openPath: action.path },
            }
        case 'OPEN_SETTINGS_PANE':
            return {
                ...state,
                setting: true,
                HelpPane: false,
                SupportPane: false,
                metricsPane: false
            }
        case 'OPEN_HELP_PANE':
            return {
                ...state,
                HelpPane: true,
                backDisabled: false,
                addDisabled: true,
                removeDisabled: true,
                fileDisabled: true,
                saveDisabled: true,
                mergeDisabled: true,
                metricsPane: false,
                setting: false,
                SupportPane: false
            }
        case 'OPEN_SQL_GENERATOR_PANE':
            return {
                ...state,
                SQLGeneratorPane: true,
                HelpPane: false,
                SupportPane: false,
                metricsPane: false,
                setting: false
            }

        case 'STORE_DATABASE_NAME':
            return {
                ...state,
                databaseName: action.databaseName
            }
        case 'OPEN_SUPPORT_PANE':
            return {
                ...state,
                SupportPane: true,
                dartPane: false,
                HelpPane: false,
                backDisabled: false,
                addDisabled: true,
                removeDisabled: true,
                fileDisabled: true,
                saveDisabled: true,
                mergeDisabled: true,
                metricsPane: false,
                setting: false,
                SQLGeneratorPane: false
            }
        case 'OPEN_DART_PANE':
            return {
                ...state,
                dartPane: true,
                SupportPane: false,
                HelpPane: false,
                backDisabled: false,
                addDisabled: true,
                removeDisabled: true,
                fileDisabled: true,
                saveDisabled: true,
                mergeDisabled: true,
                metricsPane: false,
                SQLGeneratorPane: false,
                setting: false
            }
        case 'CLOSE_SETTINGS_PROMPT':
            return {
                ...state,
                settingsDialog: false
            }
        case 'CLOSE_SAME_NAME_DIALOG':
            return {
                ...state,
                sameNameDialog: false
            }
        case 'OPEN_METRICS_PANE':
            return {
                ...state,
                metricsPane: true,
                backDisabled: false,
                addDisabled: false,
                removeDisabled: false,
                fileDisabled: true,
                saveDisabled: false,
                mergeDisabled: true,
                setting: false,
                HelpPane: false,
                SupportPane: false,
                SQLGeneratorPane: false,
                view: 'metrics',
                previousView: state.view
            }
        case 'CLOSE_DIALOG_SAVE':
            return {
                ...state,
                dialogSave: false,
            }
        case 'OKAY_DIALOG':
            return {
                ...state,
                okaySave: true,
            }
        case 'goBack':
            return {
                ...state,
                version: 1,
                view: (state.setting) ? state.view : state.previousView,
                backDisabled: true,
                addDisabled: false,
                saveDisabled: false,
                removeDisabled: false,
                fileDisabled: false,
                columnName: null,
                showSaveNotice: true,
                setting: false,
                metricsPane: false,
                SupportPane: false,
                SQLGeneratorPane: false
            }
        case 'goBackMetrics':
            return {
                ...state,
                version: 1,
                view: state.previousView,
                backDisabled: true,
                addDisabled: false,
                saveDisabled: false,
                removeDisabled: false,
                fileDisabled: false,
                columnName: null,
                showSaveNotice: true,
                setting: false,
                metricsPane: false,
                HelpPane: false,
                SupportPane: false
            }
        case 'GO_BACK_NO_SAVE':
            return {
                ...state,
                version: 1,
                view: (state.setting) ? state.view : state.previousView,
                backDisabled: true,
                addDisabled: false,
                saveDisabled: false,
                removeDisabled: false,
                fileDisabled: false,
                columnName: null,
                showSaveNotice: false,
                setting: false,
                metricsPane: false,
                SupportPane: false
            }
        case 'GO_BACK_HELP':
            return {
                ...state,
                version: 1,
                view: (state.HelpPane) ? state.view : state.previousView,
                backDisabled: true,
                addDisabled: false,
                saveDisabled: false,
                removeDisabled: false,
                fileDisabled: false,
                columnName: null,
                showSaveNotice: false,
                setting: false,
                metricsPane: false,
                HelpPane: false,
                SupportPane: false
            }
        case 'GO_BACK_SUPPORT':
            return {
                ...state,
                version: 1,
                view: (state.SupportPane) ? state.view : state.previousView,
                backDisabled: true,
                addDisabled: false,
                saveDisabled: false,
                removeDisabled: false,
                fileDisabled: false,
                columnName: null,
                showSaveNotice: false,
                setting: false,
                metricsPane: false,
                SupportPane: false,
            }
        case 'OPEN_DIALOG':
            return {
                ...state,
                addDialog: true
            }
        case 'NEXT_COLUMN':
            var nextColumnIndex = 0;
            for (var i = 0; state.storedColumnList.length > i; i++) {
                if (state.storedColumn.id === state.storedColumnList[i].id) {
                    if (nextColumnIndex === state.storedColumnList.length - 1)
                        nextColumnIndex = 0;
                    else
                        nextColumnIndex += 1;
                    break;
                } else {
                    nextColumnIndex += 1;
                }
            }
            return {
                ...state,
                storedColumn: state.storedColumnList[nextColumnIndex],
                index: nextColumnIndex + 1,
                showSaveNotice: true,
                snackBarMessage: 'Column Saved'
            }
        case 'NEXT_QA_COLUMN':
            var nextColumnIndex = 0;
            for (var i = 0; state.storedColumnList.length > i; i++) {
                if (state.storedColumn.id === state.storedColumnList[i].id) {
                    if (nextColumnIndex === state.storedColumnList.length - 1)
                        nextColumnIndex = 0;
                    else
                        nextColumnIndex += 1;
                    break;
                } else {
                    nextColumnIndex += 1;
                }
            }
            return {
                ...state,
                storedColumn: state.storedColumnList[nextColumnIndex],
                index: nextColumnIndex + 1,
                showSaveNotice: true,
                snackBarMessage: 'Data Saved'
            }

        case 'PREVIOUS_QA_COLUMN':
            var previousColumnIndex = 0;
            for (var i = 0; state.storedColumnList.length > i; i++) {
                if (state.storedColumn.id === state.storedColumnList[i].id) {
                    if (previousColumnIndex === 0)
                        previousColumnIndex = state.storedColumnList.length - 1;
                    else
                        previousColumnIndex -= 1;
                    break;
                } else {
                    previousColumnIndex += 1;
                }
            }
            return {
                ...state,
                storedColumn: state.storedColumnList[previousColumnIndex],
                index: previousColumnIndex + 1,
                showSaveNotice: true,
                snackBarMessage: 'Data Saved'
            }
        case 'PREVIOUS_COLUMN':
            var previousColumnIndex = 0;
            for (var i = 0; state.storedColumnList.length > i; i++) {
                if (state.storedColumn.id === state.storedColumnList[i].id) {
                    if (previousColumnIndex === 0)
                        previousColumnIndex = state.storedColumnList.length - 1;
                    else
                        previousColumnIndex -= 1;
                    break;
                } else {
                    previousColumnIndex += 1;
                }
            }
            return {
                ...state,
                storedColumn: state.storedColumnList[previousColumnIndex],
                index: previousColumnIndex + 1,
                showSaveNotice: true,
                snackBarMessage: 'Data Saved'
            }
        case 'PREVIOUS_COLUMN':
            var previousColumnIndex = 0;
            for (var i = 0; state.storedColumnList.length > i; i++) {
                if (state.storedColumn.id === state.storedColumnList[i].id) {
                    if (previousColumnIndex === 0)
                        previousColumnIndex = state.storedColumnList.length - 1;
                    else
                        previousColumnIndex -= 1;
                    break;
                } else {
                    previousColumnIndex += 1;
                }
            }
            return {
                ...state,
                storedColumn: state.storedColumnList[previousColumnIndex],
                index: previousColumnIndex + 1,
                showSaveNotice: true,
                snackBarMessage: 'Data Saved'
            }
        case 'CLOSE_DEFALT_PROMPT':
            return {
                ...state,
                defaultPrompt: false
            }
        case 'OPEN_DEFAULT_PROMPT':
            return {
                ...state,
                defaultPrompt: true
            }
        case 'OPEN_REMOVE_DIALOG':
            return {
                ...state,
                removeDialog: true
            }
        case 'OPEN_REMOVE_ORACLE_DIALOG':
            return {
                ...state,
                removeOracleDialog: true
            }
        case 'CLOSE_REMOVE_DIALOG':
            return {
                ...state,
                removeDialog: false
            }
        case 'CLOSE_REMOVE_ORACLE_DIALOG':
            return {
                ...state,
                removeOracleDialog: false
            }
        case 'OPEN_REMOVE_QA_DIALOG':
            return {
                ...state,
                removeQADialog: true
            }
        case 'CLOSE_REMOVE_QA_DIALOG':
            return {
                ...state,
                removeQADialog: false
            }
        case 'OPEN_DIALOG':
            return {
                ...state,
                addDialog: true
            }
        case 'OPEN_DIALOG_NEW_FILE':
            return {
                ...state,
                newFileDialog: true

            }
        case 'CLOSE_DIALOG_NEW_FILE':
            return {
                ...state,
                newFileDialog: false,
                addDisabled: false,
                saveDisabled: false,
                fileDisabled: false
            }
        case 'OPEN_SETTINGS_DIALOG':
            return {
                ...state,
                settingsDialog: true
            }
        case 'OPEN_SAME_NAME_DIALOG':
            return {
                ...state,
                sameNameDialog: true
            }
        case 'UPDATE_REMOVE_LIST':
            return {
                ...state,
                listOfRemovals: action.removeList,
                updatedColumns: action.updatedColumns
            }
        case 'UPDATE_REMOVE_LIST_PHRASES':
            return {
                ...state,
                listOfRemovalsPhrases: action.removeListPhrases,
                updatedColumnsPhrases: action.updatedColumnsPhrases
            }
        case 'OPEN_DIALOG_COLUMN':
            return {
                ...state,
                dialogColumn: true
            }
        case 'CLOSE_DIALOG_COLUMN':
            return {
                ...state,
                dialogColumn: false
            }
        //CLOSE_DIALOG will close the add dialog and make sure no column was added.
        case 'CLOSE_DIALOG':
            return {
                ...state,
                view: 'home',
                backDisabled: true,
                columnName: null,
                addDialog: false
            }
        case 'REMOVE_DISABLE':
            return {
                ...state,
                removeDisabled: true
            }
        case 'REMOVE_ENABLE':
            return {
                ...state,
                removeDisabled: false
            }
        case 'UPDATE_REMOVELIST':
            return {
                ...state,
                listOfRemovals: action.removeList,
                addDialog: false
            }
        case 'STORED_COLUMN':
            return {
                ...state,
                storedColumn: action.storedColumn
            }
        case 'CLOSE_DIALOG':
            return {
                ...state,
                addDialog: false
            }
        //STORE_COMMENTS will update the altered comments in storedColumn
        case 'STORE_COMMENTS':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, comments: action.comments }
            }
        //NEW_COLUMN_NAME will update the altered column name in storedColumn 
        case 'NEW_COLUMN_NAME':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, columnName: action.columnName }
            }
        //STORE_QUESTIONS will update the altered question in storedColumn
        case 'STORE_QUESTIONS':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, questions: action.questions }
            }
        //STORE_CII will store whether cii is true or false within storedColumn 
        case 'STORE_CII':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, cii: action.cii }
            }
        case 'STORE_DATABASE_NAME':
            return {
                ...state,
                databaseName: action.databaseName
            }
        case 'STORE_CUID':
            return {
                ...state,
                cuid: action.cuid
            }
        case 'STORE_MIRROR_ID':
            return {
                ...state,
                mirrorId: action.mirrorId
            }
        //STORE_NULLABLE will store whether the nullable checkbox is true or false in storedColumn
        case 'STORE_NULLABLE':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, nullable: action.nullable }
            }
        case 'STORE_FILTER':
            return {
                ...state,
                newSetting: { ...state.newSetting, searchFilterUser: action.filter }
            }
        case 'STORE_STRIPED_USER':
            return {
                ...state,
                newSetting: { ...state.newSetting, stripedColUser: action.stripedUser }
            }
        case 'STORE_UPPERCASE':
            return {
                ...state,
                newSetting: { ...state.newSetting, uppercase: action.uppercase }
            }
        //STORE_DATATYPE will store the new dataType in the storedColumn Array
        case 'STORE_DATATYPE':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, dataType: action.dataType }
            }
        case 'STORE_SUPPORT_TYPE':
            return {
                ...state,
                supportType: action.supportType
            }
        case 'STORE_PER_PAGE_USER':
            return {
                ...state,
                newSetting: { ...state.newSetting, perPageSetting: action.perPageUser }
            }
        case 'WORK_TYPE':
            var array = [];
            if (action.pane != null) {
                var workspace = { pane: action.pane, paneName: action.workspace.paneName }
                array.push(workspace, state.paneArray[state.paneArray.length - 1])
            }
            else {
                array.push(action.workspace, state.paneArray[state.paneArray.length - 1])
            }
            return {

                ...state,
                paneArray: array
            }
        case 'STORE_SCREEN_SIZE':
            return {
                ...state,
                newSetting: { ...state.newSetting, screenSizeSetting: action.screenSizeUser }
            }
        case 'STORE_COMMENTS':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, comments: action.comments }
            }
        //STORE_DEFINITION will save the updated definition in storedColumn
        case 'STORE_DEFINITION':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, definition: action.definition }
            }
        //STORE_METRIC will save the new metric in storedColumn
        case 'STORE_METRIC':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, metric: action.metric }
            }
        //STORE_COMPLETED will save the state of completed in sotredColumn.  if true a checkmark should be present in the table next to the columnName
        case 'STORE_COMPLETED':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, completed: action.completed, completedCheck: (action.completed) ? String.fromCharCode(10004) : '' }
            }
        //STORE_DATA_SIZE will save the updated dataSize in storedColumn
        case 'STORE_DATA_SIZE':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, dataSize: action.dataSize }
            }
        case 'COMPLETED_SORT':
            return {
                ...state,
                completedSort: (completedSort === false) ? true : false
            }
        case 'SNACK_BAR_MESSAGE':
            return {
                ...state,
                showSaveNotice: true,
                snackBarMessage: action.message
            }
        case 'hideSave':
            return {
                ...state,
                showSaveNotice: false,
                snackBarMessage: ""
            }
        case 'DISABLE_PAGE':
            return {
                ...state,
                addDisabled: false,
                disablePage: (state.disablePage) ? false : true
            }
        case 'SETTINGS_RESET':
            return {
                ...state,
                currentSetting: state.defaultSetting,
                newSetting: state.defaultSetting
            }
        case 'UPDATE_SORT':
            var list = action.columns;
            var sort = state.sortOrder
            var comp = state.completedOrder
            list = list.filter((column) => {
                return column.columnName.toLowerCase();
            }).sort((a, b) => {
                var aSort, bSort;
                switch (state.sortColumn) {
                    case 'columnName':
                        aSort = a.columnName.toLowerCase();
                        bSort = b.columnName.toLowerCase();
                        break;
                    case 'completedCheck':
                        aSort = a.completed;
                        bSort = b.completed;
                        break;
                }
                if (aSort < bSort) {
                    return -1 * sort;
                } else if (aSort > bSort) {
                    return 1 * sort;
                }
                return 0;
            })
            return {
                ...state,
                sortOrder: sort,
                completedOrder: comp,
                storedColumnList: list,
            }
        case 'UPDATE_QA_SORT':
            var list = action.columns;
            var sort = state.sortOrder
            var comp = state.completedOrder
            list = list.filter((column) => {
                return column.appName.toLowerCase();
            }).sort((a, b) => {
                var aSort, bSort;
                switch (state.sortColumn) {
                    case 'appName':
                        aSort = a.appName.toLowerCase();
                        bSort = b.appName.toLowerCase();
                        break;
                    case 'completedCheck':
                        aSort = a.completed;
                        bSort = b.completed;
                        break;
                }
                if (aSort < bSort) {
                    return -1 * sort;
                } else if (aSort > bSort) {
                    return 1 * sort;
                }
                return 0;
            })
            return {
                ...state,
                sortOrder: sort,
                completedOrder: comp,
                storedColumnList: list,
            }
        case 'COMPLETED_PLUS':
            return {
                ...state,
                completedCount: state.completedCount += 1,
                completedBack: true
            }
        case 'COMPLETED_MINUS':
            return {
                ...state,
                completedCount: state.completedCount -= 1,
            }
        case 'CHANGE_COMPLETED_BACK':
            return {
                ...state,
                completedBack: false
            }
        case 'OVERWRITE_SAME_FILE':
            return {
                ...state,
            }
        case 'OVERWRITE_CURRENT_SETTINGS':
            return {
                ...state,
                currentSetting: state.newSetting,
                showSaveNotice: true,
                cardDropDownRefresh: false
            }
        case 'LOAD_CURRENT_SETTINGS':
            return {
                ...state,
                newSetting: state.currentSetting
            }
        case 'UPDATE_TABLE':
            var page = action.pageNumber;
            var perPage = action.perPage;
            var end = perPage * page;
            var start = end - perPage;
            var list = action.storedColumnList;
            var sort = (action.sort === 'asc') ? 1 : -1;
            var comp = action.completedSort;
            list = list.filter((column) => {
                if (action.filterText === '' || action.filterText === null) {
                    return true;
                }
                return column.columnName.toLowerCase().includes(action.filterText.toLowerCase());
            }).sort((a, b) => {
                var aSort, bSort;
                switch (action.sortColumn) {
                    case 'columnName':
                        aSort = a.columnName.toLowerCase();
                        bSort = b.columnName.toLowerCase();
                        break;
                    case 'completedCheck':
                        aSort = a.completed;
                        bSort = b.completed;
                        break;
                }

                if (aSort < bSort) {
                    return -1 * sort;
                } else if (aSort > bSort) {
                    return 1 * sort;
                }
                return 0;
            })
            return {
                ...state,
                listOfRemovals: [],
                sortOrder: sort,
                completedOrder: comp,
                storedColumnList: list,
                sortColumn: action.sortColumn,
                pagingColumnList: list.slice(start, end),
                page: action.pageNumber,
                filterText: action.filterText
            }
        case 'STORE_QA_ACRONYM':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, acronym: action.acronym }
            }
        case 'STORE_UPDATEQ1':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q1: action.q1 }
            }
        case 'STORE_HANDLE_Q2':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q2Answer: action.q2Answer }
            }
        case 'STORE_UPDATEQ3':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q3: action.q3 }
            }
        case 'STORE_UPDATEQ4':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q4: action.q4 }
            }
        case 'STORE_UPDATEQ5':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q5: action.q5 }
            }
        case 'STORE_UPDATEQ6':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q6: action.q6 }
            }
        case 'STORE_HANDLE_Q7':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q7Answer: action.q7Answer }
            }
        case 'STORE_UPDATEQ8':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, q8: action.q8 }
            }
        case 'STORE_QA_COMMENTS':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, comments: action.comments }
            }
        case 'STORE_QA_QUESTION':
            return {
                ...state,
                storedColumn: { ...state.storedColumn, question: action.question }
            }

        default:
            return state
    }
}
export default appState