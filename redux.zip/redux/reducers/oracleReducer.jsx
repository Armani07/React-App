import moment from 'moment';
const initialState = {
    columnList: [],
    columnUpdated: false,
    schemaName: '',
    pagingColumnList: [],
    sortOrder: 1,
    sortColumn: 'tableName',
    sortingColumnList: [],
    page: 1
};
function oracleState(state = initialState, action) {
    switch (action.type) {

        case 'NEW_ORACLE_TABLE':
            return {
                columnList: [],
                columnUpdated: true,
                schemaName: action.schemaName
            }
        case "UPDATE_TABLE_ORACLE":
            var page = action.pageNumber;
            var perPage = action.perPage;
            var end = perPage * page;
            var start = end - perPage;
            var list = action.columns;
            var sort = (action.sort === 'asc') ? 1 : -1;
            list = list.filter((column) => {
                if (column.columnName != null && column.columnName.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (column.tableName != null && column.tableName.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (column.dataType != null && column.dataType.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (column.objectType != null && column.objectType.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (column.status != null && column.status.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (column.compliant != null && column.compliant.toLowerCase().includes(action.filterText.toLowerCase()))
                    return true;
                if (action.filterText === '' || action.filterText === null) {
                    return true;
                }
            }).sort((a, b) => {
                var aSort, bSort;
                switch (action.sortColumn) {
                    case 'tableName':
                        aSort = a.tableName.toLowerCase();
                        bSort = b.tableName.toLowerCase();
                        break;
                    case 'columnName':
                        aSort = a.columnName.toLowerCase();
                        bSort = b.columnName.toLowerCase();
                        break;
                    case 'dataType':
                        aSort = a.dataType.toLowerCase();
                        bSort = b.dataType.toLowerCase();
                        break;
                    case 'objectType':
                        aSort = a.objectType.toLowerCase();
                        bSort = b.objectType.toLowerCase();
                        break;
                    case 'status':
                        aSort = (a.status.toLowerCase() === 'invalid') ? false : true
                        bSort = (b.status.toLowerCase() === 'invalid') ? false : true
                        break;
                    case 'compliant':
                        aSort = (a.compliant.toLowerCase() === 'n') ? false : true
                        bSort = (b.compliant.toLowerCase() === 'n') ? false : true
                        break;
                    case 'loadDate':
                        aSort = (a.loadDate === null) ? moment('10/05/1901'):moment(a.loadDate)
                        bSort = (b.loadDate === null) ? moment('10/05/1901'):moment(b.loadDate)
                        break;
                }
                if (action.sortColumn != 'loadDate') {
                    if (aSort < bSort) {
                        return -1 * sort;
                    } else if (aSort > bSort) {
                        return 1 * sort;
                    }
                    return 0;
                } else {
                    if (aSort.isBefore(bSort)) {
                        return -1 * sort;
                    } else if (bSort.isBefore(aSort)) {
                        return 1 * sort;
                    }
                    return 0;
                }
            })
            return {
                ...state,
                sortOrder: sort,
                sortColumn: action.sortColumn,
                sortingColumnList: list.slice(start, end),
                page: action.pageNumber
            }
        case 'ADD_ORACLE_COLUMN':
            return {
                ...state,
                columnList: [
                    ...state.columnList,
                    {
                        tableName: action.column.tableName,
                        columnName: action.column.columnName,
                        dataType: action.column.dataType,
                        objectType: action.column.objectType,
                        status: action.column.status,
                        compliant: action.column.compliant,
                        loadDate: action.column.loadDate,
                        id: action.id
                    }],
                columnUpdated: true
            }
        case 'ORACLE_COLUMN_HAS_UPDATED':
            return {
                ...state,
                columnUpdated: false
            }
        case 'ORACLE_COLUMN_NEEDS_UPDATED':
            return {
                ...state,
                columnUpdated: true
            }
        case 'ORACLE_ALTER_COLUMN_NAME':
            return {
                ...state,
                columnList: state.columnList.map((columns) => {
                    if (columns.id === action.id) {
                        return Object.assign({}, columns, {
                            columnName: action.columnName
                        })
                    }
                    return columns
                })
            }
        case 'ORACLE_REMOVE_COLUMN':
            var filtering = state.columnList.filter((column, index) => {
                var removeIt = true;
                action.columnPositions.forEach(function (removeColumn, index) {
                    if (column.id === removeColumn.id) {
                        removeIt = false
                    }
                })
                return removeIt
            })
            return {
                ...state,
                columnUpdated: true,
                columnList: filtering
            }
        case 'ORACLE_IS_COMPLETED':
            return {
                ...state,
                completed: !state.completed //switch the state of ovject to completed:true, Column in the left pane table should contain a checkmark
            }
        case 'ORACLE_IS_UNCOMPLETED':
            return {
                ...state,
                completed: false //switch the state of object to completed:false, no checkmark should appear in Left pane table
            }
        case 'ORACLE_COLUMNS_LOAD':
            return {
                ...state,
                columnList: action.columns,
                columnUpdated: true,
                tableName: action.name,
                schemaName: action.schemaName
            }
        case 'ORACLE_SAVE_COLUMN':
            return {
                ...state,
                columnUpdated: true,
                schemaName: action.schemaName,
                columnList: state.columnList.map((column) => {
                    if (column.id === action.column.id) {
                        return action.column
                    }
                    return column
                })
            }
        default:
            return state
    }
};

export default oracleState;