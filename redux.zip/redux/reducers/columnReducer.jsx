const initialState = {
  columnList: [],
  columnUpdated: false,
  tableName: '',
};
 
 function columnList(state = initialState, action) {
  switch (action.type) {
  
    case 'NEW_TABLE':
      return {
        columnList: [],
        columnUpdated: true,
        tableName: action.name
      }
    case 'ADD_COLUMN': 
      return {
        ...state,
        columnList: [
          ...state.columnList,
          {
            id: action.id,
            columnName: action.columnName,
            dataType: (action.dataType) ? action.dataType[0] : null,
            dataSize: (action.dataType) ? action.dataType[1] : null,
            nullable: action.nullability,
            columnData: [],
            cii: null,
            metric: null,
            comments: null,
            questions: null,
            completed: false,
            definition: null,
          }],
        columnUpdated: true
      }
    case 'COLUMN_HAS_UPDATED':
      return {
        ...state,
        columnUpdated: false
      }
    case 'COLUMN_NEEDS_UPDATED':
      return {
        ...state,
        columnUpdated: true
      }
    case 'ALTER_COLUMN_NAME':
      return {
        ...state,
        columnList: state.columnList.map((columns) => {
          if (columns.id === action.id) {
            return Object.assign({}, columns, {
              columnName: action.columnName
            })
          }
          return columns
        })
      }

    case 'REMOVE_COLUMN':
      return {
        ...state,
        columnUpdated: true,

        columnList: state.columnList.filter((column, index) => {
          var removeIt = true;
          action.columnPositions.forEach(function (removeColumn, index) {
            if (column.id === removeColumn.id) {
              removeIt = false
            }
          })
          return removeIt
        })
      }
    case 'IS_COMPLETED':
      return {
        ...state,
        completed: !state.completed //switch the state of ovject to completed:true, Column in the left pane table should contain a checkmark
      }
    case 'IS_UNCOMPLETED':
      return {
        ...state,
        completed: false //switch the state of object to completed:false, no checkmark should appear in Left pane table
      }
    case 'COLUMNS_LOAD':
      return {
        ...state,
        columnList: action.columns,
        columnUpdated: true,
        tableName: action.name
      }
    case 'save_Column':
      return {
        ...state,
        columnUpdated: true,
        columnList: state.columnList.map((column) => {

          if (column.id === action.column.id) {

            return action.column

          }
          return column
        })
      }
    default:
      return state
  }
};

export default columnList;