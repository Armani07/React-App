let columnListId = 1

export const addToColumnList = (columnName,dataType,nullability) => {
  return {
    type: 'ADD_COLUMN',
    id: columnListId++, 
    nullability,
    dataType,
    columnName
  }
}
export const removeFromColumnList = (columnPositions) => {
  return {
    type: 'REMOVE_COLUMN',
   columnPositions
  }
}

export const alterColumnName = (columnId, newName) => {
  return {
    type: 'ALTER_COLUMN_NAME',
    id: columnId,
    columnName: newName
  }
}

export const alterVersion = (version) => {
  return {
    type: 'ALTER_VERSION',
    version
  }
}
export const completed = (column) => {
  return{
    column,
    type: 'IS_COMPLETED' //switch the state of column to completed:true
  }
}
export const uncompleted = (column) => {
  return{
    column,
    type: 'IS_UNCOMPLETED' //switch state of column to completed:false
  }
}
export const saveColumn = (column) => {
  return {
    type: 'save_Column',
    column
  }
}
export const columnHasUpdated = () => {
  return {
    type: 'COLUMN_HAS_UPDATED',
  }
}
export const columnNeedsUpdated = () => {
  return {
    type: 'COLUMN_NEEDS_UPDATED',
  }
}
export const newTableName = (name) => {
  return{
    type: 'NEW_TABLE',
    name
  }
}
export const columnsLoad = (columns,name,id) => {
  columnListId=id+1
  return {
    type: 'COLUMNS_LOAD',
    columns,
    name
  }
}
