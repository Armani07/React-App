export function appView(pane, paneName) {
  return {
    type: 'STORE_PANE',
    pane,
    paneName
  }
}

export function clearDar() {
  return {
    type: 'CLEAR_DAR'
  }
}

export function openAddValidation() {
  return {
    type: 'OPEN_ADD_VALDIATION',

  }
}
export function closeAddValidation() {
  return {
    type: 'CLOSE_ADD_VALDIATION',

  }
}
export function loadWorkSpace(object) {
  return {
    type: 'LOAD_WORK_SPACE',
    object
  }
}
export function addOracleDialogOpen() {
  return {
    type: 'ORACLE_OPEN_ADD'
  }
}

export function addOracleDialogRemove() {
  return {
    type: 'ORACLE_CLOSE_ADD'
  }
}
export function removeOracleDialogOpen() {
  return {
    type: 'ORACLE_OPEN_REMOVE'
  }
}
export function popPane() {
  return {
    type: 'POP_PANE'
  }
}
export function popSettingPane(pane, paneArray) {
  return {
    type: 'POP_SETTINGS_PANE',
    pane,
    paneArray
  }
}
export function closeDialogNewOracle() {
  return {
    type: 'CLOSE_NEW_ORACLE'
  }
}
export function openDialogNewOracle() {
  return {
    type: 'OPEN_NEW_ORACLE'
  }
}
export function closeDialogNewApp() {
  return {
    type: 'CLOSE_NEW_APP'
  }
}
export function openDialogNewApp() {
  return {
    type: 'OPEN_NEW_APP'
  }
}
export function propsRefreshed() {
  return {
    type: 'PROPS_REFRESHED'
  }
}
export function goToColumn(columnName) {
  return {
    type: 'goToColumn',
    selected: columnName
  }
}
export function goBack() {
  return {
    type: 'goBack'
  }
}
export function reduxPhrasesImport(importPhrasesArray, importPhrases) {
  return {
    type: "IMPORT_PHRASES",
    importPhrasesArray,
    importPhrases
  }
}
export function trelloRefresh() {
  return {
    type: 'TRELLO_REFRESH'
  }
}
export function falseTrelloRefresh() {
  return {
    type: 'FALSE_TRELLO_REFRESH'
  }
}
export function goBackMetrics() {
  return {
    type: 'goBackMetrics'
  }
}
export function chooseBoard(id) {
  return {
    type: 'BOARD_ID',
    id
  }
}
export function chooseList(id) {
  return {
    type: 'LIST_ID',
    id
  }
}
export function moveCard(id) {
  return {
    type: 'MOVE_ID',
    id
  }
}
export function moveTrelloCard(id) {
  return {
    type: 'MOVE_TRELLO_ID',
    id
  }
}
export function chooseCards(id) {
  return {
    type: 'CARD_ID',
    id
  }
}
export function clearCard() {
  return {
    type: 'CLEAR_CARD'
  }
}
export function cardDropDownRefreshed() {
  return {
    type: 'CARD_REFRESHED'
  }
}
export function goBackNoSave() {
  return {
    type: 'GO_BACK_NO_SAVE'
  }
}
export function copytextchange(text) {
  return {
    type: 'TEXT_CHANGE',
    text
  }
}
export function copyDialog(event) {
  return {
    type: 'OPEN_DIALOG_COPY',
    event
  }
}
export function goBackHelp() {
  return {
    type: 'GO_BACK_HELP'
  }
}
export function hideSaveNotice() {
  return {
    type: 'hideSave'
  }
}
export function updateRemoveList(removeList, updatedColumns) {
  return {
    type: 'UPDATE_REMOVE_LIST',
    removeList,
    updatedColumns
  }
}
export function updateRemoveListPhrases(removeListPhrases, updatedColumnsPhrases) {
  return {
    type: 'UPDATE_REMOVE_LIST_PHRASES',
    removeListPhrases,
    updatedColumnsPhrases,
  }
}
export function openDialog() {
  return {
    type: 'OPEN_DIALOG'
  }
}
export const removeFromPhrasesList = (phrasePosition) => {
  return {
    type: 'REMOVE_PHRASES',
    phrasePosition
  }
}
//closeDialog is called when the user exits the dialog box in Dialog_Box.jsx
export function closeDialog() {
  return {
    type: 'CLOSE_DIALOG'
  }
}
export function closeRemoveDialog() {
  return {
    type: 'CLOSE_REMOVE_DIALOG'
  }
}
export function closeRemoveOracleDialog() {
  return {
    type: 'CLOSE_REMOVE_ORACLE_DIALOG'
  }
}
export function openRemoveDialog() {
  return {
    type: 'OPEN_REMOVE_DIALOG'
  }
}
export function openRemoveOracleDialog() {
  return {
    type: 'OPEN_REMOVE_ORACLE_DIALOG'
  }
}
export function closeRemoveQADialog() {
  return {
    type: 'CLOSE_REMOVE_QA_DIALOG'
  }
}
export function openRemoveQADialog() {
  return {
    type: 'OPEN_REMOVE_QA_DIALOG'
  }
}
export function openDialogNewFile() {
  return {
    type: 'OPEN_DIALOG_NEW_FILE'
  }
}
export function closeDialogNewFile() {
  return {
    type: 'CLOSE_DIALOG_NEW_FILE'
  }
}
export function openDialogHelp() {
  return {
    type: 'OPEN_DIALOG_HELP'
  }
}
export function openSettingsDialog() {
  return {
    type: 'OPEN_SETTINGS_DIALOG'
  }
}
export function closeDialogHelp() {
  return {
    type: 'CLOSE_DIALOG_HELP'
  }
}
export function enableRemove() {
  return {
    type: 'REMOVE_ENABLE'
  }
}
export function disableRemove() {
  return {
    type: 'DISABLE_REMOVE'
  }
}
export function currentColumn(column) {
  return {
    type: 'STORED_COLUMN',
    storedColumn: column
  }
}
//storeComments is called when the comments text box is altered in RightPane.jsx
export function storeComments(input) {
  return {
    type: 'STORE_COMMENTS',
    comments: input
  }
}
//storeCII is called when cii is chaned in RightPane.jsx
export function storeCii(input) {
  return {
    type: 'STORE_CII',
    cii: input
  }
}
//storeNullable is called when the nullable checkbox is toggled in RightPane
export function storeNullable(input) {
  return {
    type: 'STORE_NULLABLE',
    nullable: input
  }
}
export function storeDatabaseName(input) {
  return {
    type: 'STORE_DATABASE_NAME',
    databaseName: input
  }
}
export function storeCUID(input) {
  return {
    type: 'STORE_CUID',
    cuid: input
  }
}
export function storeMirrorId(input) {
  return {
    type: 'STORE_MIRROR_ID',
    mirrorId: input
  }
}
export function storeFilterUser(input) {
  return {
    type: 'STORE_FILTER',
    filter: input
  }
}
export function storeStripedUser(input) {
  return {
    type: 'STORE_STRIPED_USER',
    stripedUser: input
  }
}
//storeQuestions is called when the question is chaned in RightPane.jsx
export function storeQuestions(input) {
  return {
    type: 'STORE_QUESTIONS',
    questions: input
  }
}
//storeDefinition is called when the definition is changed in RightPane.jsx
export function storeDefinition(input) {
  return {
    type: 'STORE_DEFINITION',
    definition: input
  }
}
//storeMetric is called on when the Metric is changed by the user in RightPane.jsx
export function storeMetric(input) {
  return {
    type: 'STORE_METRIC',
    metric: input
  }
}
export function getTrelloKey(input) {
  return {
    type: 'STORE_TRELLO_KEY',
    trelloKey: input
  }
}
export function getBoards(input) {
  return {
    type: 'STORE_BOARDS',
    boards: input
  }
}
export function getLists(input) {
  return {
    type: 'STORE_LISTS',
    boards: input
  }
}
export function getMove(input) {
  return {
    type: 'STORE_MOVE',
    boards: input
  }
}
export function getMakeCard(input) {
  return {
    type: 'STORE_MAKE_CARD',
    boards: input
  }
}
export function getCards(input) {
  return {
    type: 'STORE_CARDS',
    boards: input
  }
}
export const newTrelloCard = (name) => {
  return {
    type: 'NEW_TRELLO_CARD',
    name
  }
}
//storeDataType iscalled on when the dataType is changed by the user in RightPane.jsx
export function storeDataType(input) {
  return {
    type: 'STORE_DATATYPE',
    dataType: input
  }
}
export function storeSupportType(input) {
  return {
    type: 'STORE_SUPPORT_TYPE',
    supportType: input
  }
}
export function storePerPageUser(input) {
  return {
    type: 'STORE_PER_PAGE_USER',
    perPageUser: input
  }
}
export function workspaceType(workspace, pane) {
  return {
    type: 'WORK_TYPE',
    workspace,
    pane
  }
}
export function storeScreenSize(input) {
  return {
    type: 'STORE_SCREEN_SIZE',
    screenSizeUser: input
  }
}
//storeCompleted is called on when the completedButton is pressed by the user in RightPane.jsx
export function storeCompleted(input) {
  return {
    type: 'STORE_COMPLETED',
    completed: input
  }
}
//storeDataSize is called on when the dataSize is changed in RightPane.jsx
export function storeDataSize(input) {
  return {
    type: 'STORE_DATA_SIZE',
    dataSize: input
  }
}
//storeNewColumnName is called when a columnName is changed in RightPane.jsx
export function storeNewColumnName(input) {
  return {
    type: 'NEW_COLUMN_NAME',
    columnName: input
  }
}
export function updateTable(columnList, perPage, pageNumber, sort, filterText, sortColumn) {
  return {
    type: 'UPDATE_TABLE',
    storedColumnList: columnList,
    perPage,
    pageNumber,
    sort,
    filterText,
    sortColumn
  }
}
export function completedSort() {
  return {
    type: 'COMPLETED_SORT'
  }
}
export function openDialogSave() {
  return {
    type: 'OPEN_DIALOG_SAVE'
  }
}
export function openDialogColumn() {
  return {
    type: 'OPEN_DIALOG_COLUMN'
  }
}
export function changeCompletedBack() {
  return {
    type: 'CHANGE_COMPLETED_BACK'
  }
}
export function closeDialogColumn() {
  return {
    type: 'CLOSE_DIALOG_COLUMN'
  }
}
export function openMetricsPane() {
  return {
    type: 'OPEN_METRICS_PANE'
  }
}
export function openSettingsPane() {
  return {
    type: 'OPEN_SETTINGS_PANE'
  }
}
export function openHelpPane() {
  return {
    type: 'OPEN_HELP_PANE'
  }
}
export function openSQLGeneratorPane() {
  return {
    type: 'OPEN_SQL_GENERATOR_PANE'
  }
}
export function openErrorModal(error) {
  return {
    type: 'ERROR_MODAL_TRUE',
    error
  }
}
export function closeErrorModal() {
  return {
    type: 'ERROR_MODAL_FALSE'
  }
}
export function openSupportPane() {
  return {
    type: 'OPEN_SUPPORT_PANE'
  }
}
export function openDartPane() {
  return {
    type: 'OPEN_DART_PANE'
  }
}
export function goBackSupport() {
  return {
    type: 'GO_BACK_SUPPORT'
  }
}
export function closeDialogSave() {
  return {
    type: 'CLOSE_DIALOG_SAVE'
  }
}
export function okayDialog() {
  return {
    type: 'OKAY_DIALOG'
  }
}
export function nextColumn() {
  return {
    type: 'NEXT_COLUMN'
  }
}
export function previousColumn() {
  return {
    type: 'PREVIOUS_COLUMN'
  }
}
export function nextQAColumn() {
  return {
    type: 'NEXT_QA_COLUMN'
  }
}
export function previousQAColumn() {
  return {
    type: 'PREVIOUS_QA_COLUMN'
  }
}
export function updateSort(columns) {
  return {
    type: 'UPDATE_SORT',
    columns
  }
}
export function updateQASort(columns) {
  return {
    type: 'UPDATE_QA_SORT',
    columns
  }
}
export function completedPlus() {
  return {
    type: 'COMPLETED_PLUS'
  }
}
export function completedMinus() {
  return {
    type: 'COMPLETED_MINUS',
  }
}
export function disablePage() {
  return {
    type: 'DISABLE_PAGE'
  }
}
export function changeOpen(path) {
  return {
    type: 'OPEN_PATH',
    path
  }
}
export function changeSave(path) {
  return {
    type: 'SAVE_PATH',
    path
  }
}
export function saved() {
  return {
    type: 'SAVED'
  }
}
export function overwriteSameFIle(input) {
  return {
    type: 'OVERWRITE_SAME_FILE'
  }
}
export function overwriteNewSettings(input) {
  return {
    type: 'OVERWRITE_CURRENT_SETTINGS',
    newCurrentSettings: input
  }
}
export function loadDefault(input) {
  return {
    type: 'LOAD_DEFAULT_SETTINGS',
    input
  }
}
export function addPhrase(input) {
  return {
    type: 'ADD_COMMON_PHRASE',
    input
  }
}
export const loadUser = (input) => {
  return {
    type: 'LOAD_USER_SETTINGS',
    input,
  }
}
export const filesHaveUpdated = () => {
  return {
    type: 'FILES_HAVE_UPDATED',
  }
}
export function settingsLoad() {
  return {
    type: 'LOAD_CURRENT_SETTINGS'
  }
}
export function storeUppercase(input) {
  return {
    type: 'STORE_UPPERCASE',
    uppercase: input
  }
}
export function completeReturn(input) {
  return {
    type: 'COMPLETE_RETURN',
    completeReturn: input
  }
}
export function storeSaveSetting(input) {
  return {
    type: 'STORE_SAVE_SETTING',
    saveSetting: input
  }
}
export function storeWarningSetting(input) {
  return {
    type: 'STORE_WARNING_SETTING',
    disableWarning: input
  }
}
export function storeWarningSetting2(input) {
  return {
    type: 'STORE_WARNING_SETTING2',
    disableWarning2: input
  }
}
export function storeWarningModal(input) {
  return {
    type: 'STORE_WARNING_MODAL',
    disableWarning: input
  }
}
export function storeWarningModal2(input) {
  return {
    type: 'STORE_WARNING_MODAL2',
    disableWarning2: input
  }
}
export function settingsReset() {
  return {
    type: 'SETTINGS_RESET'
  }
}
export function closeSettingsPrompt() {
  return {
    type: 'CLOSE_SETTINGS_PROMPT'
  }
}
export function closeDefaultSettings() {
  return {
    type: 'CLOSE_DEFALT_PROMPT'
  }
}
export function openDefaultDialog() {
  return {
    type: 'OPEN_DEFAULT_PROMPT'
  }
}
export function snackBarMessage(message) {
  return {
    type: 'SNACK_BAR_MESSAGE',
    message
  }
}
export function metricDialog() {
  return {
    type: 'METRIC_DIALOG'
  }
}
export function metricClose() {
  return {
    type: 'METRIC_CLOSE'
  }
}
export function openSameFileDialog() {
  return {
    type: 'OPEN_SAME_FILE_DIALOG'
  }
}
export function closeSameFileDialog() {
  return {
    type: 'CLOSE_SAME_FILE_DIALOG'
  }
}
export function openNewMetricDialog() {
  return {
    type: 'OPEN_NEW_METRIC_DIALOG'
  }
}
export function closeNewMetricDialog() {
  return {
    type: 'CLOSE_NEW_METRIC_DIALOG'
  }
}
export function storeQaAcronym(input) {
  return {
    type: 'STORE_QA_ACRONYM',
    acronym: input
  }
}
export function storeUpdateQ1(input) {
  return {
    type: 'STORE_UPDATEQ1',
    q1: input
  }
}
export function storehandleq2(input) {
  return {
    type: 'STORE_HANDLE_Q2',
    q2Answer: input
  }
}
export function storeUpdateQ3(input) {
  return {
    type: 'STORE_UPDATEQ3',
    q3: input
  }
}
export function storeUpdateQ4(input) {
  return {
    type: 'STORE_UPDATEQ4',
    q4: input
  }
}
export function storeUpdateQ5(input) {
  return {
    type: 'STORE_UPDATEQ5',
    q5: input
  }
}
export function storeUpdateQ6(input) {
  return {
    type: 'STORE_UPDATEQ6',
    q6: input
  }
}
export function storehandleq7(input) {
  return {
    type: 'STORE_HANDLE_Q7',
    q7Answer: input
  }
}
export function storeUpdateQ8(input) {
  return {
    type: 'STORE_UPDATEQ8',
    q8: input
  }
}
export function storeQAComments(input) {
  return {
    type: 'STORE_QA_COMMENTS',
    comments: input
  }
}
export function storeQAQuestion(input) {
  return {
    type: 'STORE_QA_QUESTION',
    question: input
  }
}

