let columnListId = 1


export const addToQaList = (column) => {
  return {
    type: 'ADD_QA_COLUMN',
    id: columnListId++,
    column
  }
}
export const removeFromQaList = (columnPositions) => {
  return {
    type: 'QA_REMOVE_COLUMN',
    columnPositions
  }
}
export const alterQaName = (columnId, newName) => {
  return {
    type: 'QA_ALTER_COLUMN_NAME',
    id: columnId,
    columnName: newName
  }
}
export const alterVersionQa = (version) => {
  return {
    type: 'ALTER_VERSION',
    version
  }
}
export const completedQa = (column) => {
  return {
    column,
    type: 'QA_IS_COMPLETED' //switch the state of column to completed:true
  }
}
export const uncompletedQa = (column) => {
  return {
    column,
    type: 'QA_IS_UNCOMPLETED' //switch state of column to completed:false
  }
}
export const saveQa = (column) => {
  return {
    type: 'QA_SAVE_COLUMN',
    column
  }
}
export const qaNeedsUpdated = () => {
  return {
    type: 'QA_COLUMN_NEEDS_UPDATED',
  }
}
export const newTableQa = (workingSet) => {
  return{
    type: 'NEW_QA_TABLE',
    workingSet
  }
}
export const qaLoad = (columns, workingSet, id, ) => {
  columnListId = id + 1
  return {
    type: 'QA_COLUMNS_LOAD',
    columns,
    workingSet
  }
}
export const updateQATable = (sort, sortColumn, columns, filterText, perPage, pageNumber) => {
  return {
    type: 'UPDATE_QA_TABLE',
    sort,
    sortColumn,
    columns,
    filterText,
    perPage,
    pageNumber
  }
}
export const qaHasUpdated = () => {
  return {
    type: 'QA_COLUMN_HAS_UPDATED',
  }
}