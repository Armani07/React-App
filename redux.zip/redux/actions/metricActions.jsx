let columnListId = 1

export const addToMetricsList = (metricName) => {
    return{
        type: 'ADD_METRIC',
        id: columnListId++,
        metricName
    }
}
export const metricHasUpdated = () => {
  return {
    type: 'METRIC_HAS_UPDATED',
  }
}
export const updateMetricRemoveList = (removeMetrics, metricsList) => {
  return {
    type: 'UPDATE_METRIC_REMOVE_LIST',
    removeMetrics,
    metricsList
  }
}
export const metricsReset = () => {
  return {
    type: 'METRICS_RESET'
  }
}
export const removeFromMetricsList = (metricsPositions) => {
  return {
    type: 'REMOVE_METRICS',
    metricsPositions
  }
}