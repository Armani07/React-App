let columnListId = 1


export const addToOracleList = (column) => {
  return {
    type: 'ADD_ORACLE_COLUMN',
    id: columnListId++,
    column
  }
}
export const removeFromOracleList = (columnPositions) => {
  return {
    type: 'ORACLE_REMOVE_COLUMN',
    columnPositions

  }
}
export const updateOracleTable = (sort, sortColumn, columns, filterText, perPage, pageNumber) => {
  return {
    type: 'UPDATE_TABLE_ORACLE',
    sort,
    sortColumn,
    columns,
    filterText,
    pageNumber,
    perPage
  }
}
export const alterOracleName = (columnId, newName) => {
  return {
    type: 'ORACLE_ALTER_COLUMN_NAME',
    id: columnId,
    columnName: newName
  }
}
export const alterVersionOracle = (version) => {
  return {
    type: 'ALTER_VERSION',
    version
  }
}
export const completedOracle = (column) => {
  return {
    column,
    type: 'ORACLE_IS_COMPLETED' //switch the state of column to completed:true
  }
}
export const uncompletedOracle = (column) => {
  return {
    column,
    type: 'ORACLE_IS_UNCOMPLETED' //switch state of column to completed:false
  }
}
export const saveOracle = (column) => {
  return {
    type: 'ORACLE_SAVE_COLUMN',
    column
  }
}
export const oracleHasUpdated = () => {
  return {
    type: 'ORACLE_COLUMN_HAS_UPDATED',
  }
}
export const oracleNeedsUpdated = () => {
  return {
    type: 'ORACLE_COLUMN_NEEDS_UPDATED',
  }
}
export const newTableOracle = (schemaName) => {
  return {
    type: 'NEW_ORACLE_TABLE',
    schemaName
  }
}
export const oracleLoad = (columns, schemaName, id) => {
  columnListId = id + 1
  return {
    type: 'ORACLE_COLUMNS_LOAD',
    columns,
    schemaName
  }
}
